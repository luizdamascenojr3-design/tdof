# FlowTerminal — terminal de order flow na web (estilo ATAS)

Terminal de trading web com **footprint/clusters**, **heatmap de liquidez com profundidade e
bolhas de trades**, **DOM com click trading**, **Smart Tape**, **CVD**, **VWAP ±σ**, **barras
não-temporais** e **Quant Dashboard**. Dados 100% sintéticos (motor de simulação de
microestrutura em tempo real) — sem corretoras, sem chaves de API, sem banco de dados.

## Rodar localmente

Requisitos: [Bun](https://bun.sh) (ou Node 20+ com npm).

```bash
bun install
```

Dois processos:

```bash
# Terminal 1 — motor de mercado (simulação de fluxo, porta 3003)
cd mini-services/market-data
bun run dev

# Terminal 2 — app web (Next.js, porta 3000)
bun run dev
```

Abra **http://localhost:3000**. O terminal conecta sozinho ao motor: primeiro tenta o gateway
(`/?XTransformPort=3003`) e, se não houver gateway, cai automaticamente para a conexão direta
na porta 3003 (watchdog de 4,5 s).

## O que tem dentro

| Área | Recursos |
|---|---|
| Gráfico | Footprint bid×ask (células divididas), imbalances diagonais, max levels, Volume Profile (POC/VAH/VAL), painel de Delta + CVD, faixa bid\|ask, VWAP da sessão, Candles/Linha |
| Heatmap | Liquidez do book ao longo do tempo (bids teal / asks vermelhos, paredes esquentam), **bolhas de trades** (raio ∝ volume, rajadas no mesmo nível viram uma bolha, contorno âmbar = trade grande) e **ladder de profundidade** com o book atual |
| DOM | Escada com heat de profundidade, volume/delta da sessão por nível, click trading (armar ordens, LMT/flatten simulados) |
| Smart Tape | Filtros Todos/Compras/Vendas/Grandes, destaque de trades grandes |
| Símbolos | WINFUT, ES, BTCUSDT, PETR4 (ticks e escala próprios) · TFs 5s/15s/1m/5m |
| Quant | GEX por strike e option skew (overlay no gráfico) |

## Arquitetura

```
mini-services/market-data   Bun + socket.io (porta 3003)
  engine.ts                 Simulação de microestrutura: trades, book, DOM, regimes
  pregen.ts                 Histórico inicial (600 velas/tf com clusters)
  index.ts                  Eventos terminal:* (snapshot/trade/candle/dom/session/heatmap)

src/                        Next.js 16 (App Router) + React + Zustand + Canvas 2D
  lib/market/socket.ts      Cliente socket.io com fallback de transporte
  store/terminal.ts         Estado do terminal (dados + settings)
  components/terminal/      TopBar, gráfico canvas, DOM, tape, diálogos
```

Comunicação: `terminal:subscribe` → `terminal:snapshot` + streams
`trade/candle/dom/session/heatmap`. Preço interno em tick index (sem erro de float).

## Empacotar uma rodada

```bash
bash scripts/package-repo.sh 2   # gera public/downloads/FlowTerminal-rodada-2.zip + latest.json
```

O zip fica disponível no app em **Código .zip** (topbar) e em
`/api/repo/download?round=2` (gera on-demand se o arquivo estático não existir).
