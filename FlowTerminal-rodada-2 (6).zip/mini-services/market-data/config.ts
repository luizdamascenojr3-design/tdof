// ─────────────────────────────────────────────────────────────────────────────
// Configuração de microestrutura por símbolo.
// Preço é mantido internamente como TICK INDEX (inteiro) — preço = idx * tick.
// ─────────────────────────────────────────────────────────────────────────────

export const STEP_MS = 120; // passo do loop de simulação

export interface SymbolCfg {
  symbol: string;
  tick: number;
  priceDecimals: number;
  sizeDecimals: number;
  startPrice: number;
  /** tamanho médio do negócio */
  avgSize: number;
  minSize: number;
  maxSize: number;
  /** tamanho a partir do qual o trade é marcado como big */
  bigThreshold: number;
  /** negócios/segundo no regime normal */
  baseRate: number;
  /** desvio-padrão do movimento de 1 minuto, em ticks (coerente com a pré-geração) */
  volPerMinTicks: number;
  /** quantidade base de um nível do DOM */
  lvlQty: number;
  /** reabastecimento por step: U(0.3..2.7) × refillUnit (WIN ≈ U(1..8)) */
  refillUnit: number;
  /** cancelamento ocasional: U(5..30) × cancelUnit (WIN ≈ U(5..30)) */
  cancelUnit: number;
  /** tamanho de uma parede (escala por símbolo) */
  wallMin: number;
  wallMax: number;
  /** inovação do momentum AR(1) por step (ticks) */
  sigM: number;
  /** ruído branco do preço por step (ticks) */
  sigW: number;
  /** clamp do momentum (ticks/step) */
  maxMom: number;
  /** push no momentum por contrato negociado (pressão agressora) */
  pushTrade: number;
  /** push no momentum pela pressão agressora (buyProb − 0.5), por step */
  pushProb: number;
  /** kick de momentum por nível consumido em sweep */
  kick: number;
}

export const SYMBOL_CONFIGS: SymbolCfg[] = [
  {
    symbol: 'WINFUT', tick: 5, priceDecimals: 0, sizeDecimals: 0, startPrice: 132450,
    avgSize: 3, minSize: 1, maxSize: 25, bigThreshold: 40,
    baseRate: 9, volPerMinTicks: 60,
    lvlQty: 70, refillUnit: 3, cancelUnit: 1, wallMin: 150, wallMax: 500,
    sigM: 0.182, sigW: 0.4, maxMom: 2.2, pushTrade: 0.004, pushProb: 0.06, kick: 1,
  },
  {
    symbol: 'ES', tick: 0.25, priceDecimals: 2, sizeDecimals: 0, startPrice: 6432.25,
    avgSize: 2.5, minSize: 1, maxSize: 15, bigThreshold: 20,
    baseRate: 7, volPerMinTicks: 12,
    lvlQty: 55, refillUnit: 2.5, cancelUnit: 1, wallMin: 150, wallMax: 500,
    sigM: 0.0365, sigW: 0.08, maxMom: 0.55, pushTrade: 0.004, pushProb: 0.03, kick: 0.3,
  },
  {
    symbol: 'BTCUSDT', tick: 0.5, priceDecimals: 1, sizeDecimals: 2, startPrice: 97240,
    avgSize: 0.08, minSize: 0.01, maxSize: 1.5, bigThreshold: 1.0,
    baseRate: 6, volPerMinTicks: 240,
    lvlQty: 2.5, refillUnit: 0.08, cancelUnit: 0.012, wallMin: 2, wallMax: 10,
    sigM: 0.73, sigW: 1.6, maxMom: 8, pushTrade: 0.02, pushProb: 0.12, kick: 3,
  },
  {
    symbol: 'PETR4', tick: 0.01, priceDecimals: 2, sizeDecimals: 0, startPrice: 38.72,
    avgSize: 200, minSize: 50, maxSize: 1500, bigThreshold: 400,
    baseRate: 6, volPerMinTicks: 15,
    lvlQty: 5000, refillUnit: 200, cancelUnit: 20, wallMin: 2000, wallMax: 8000,
    sigM: 0.0456, sigW: 0.1, maxMom: 0.6, pushTrade: 0.0006, pushProb: 0.03, kick: 0.15,
  },
];

// ── Regimes de atividade (Markov simples) ────────────────────────────────────
export const REGIMES = ['calm', 'normal', 'active', 'burst'] as const;
export type Regime = (typeof REGIMES)[number];

export const RATE_MULT: Record<Regime, number> = { calm: 0.4, normal: 1, active: 2.2, burst: 5 };
export const VOL_MULT: Record<Regime, number> = { calm: 0.7, normal: 1, active: 1.3, burst: 1.8 };

export const REGIME_TRANSITIONS: Record<Regime, [Regime, number][]> = {
  calm: [['calm', 0.35], ['normal', 0.55], ['active', 0.1]],
  normal: [['calm', 0.2], ['normal', 0.5], ['active', 0.24], ['burst', 0.06]],
  active: [['calm', 0.05], ['normal', 0.4], ['active', 0.4], ['burst', 0.15]],
  burst: [['calm', 0.1], ['normal', 0.45], ['active', 0.35], ['burst', 0.1]],
};
