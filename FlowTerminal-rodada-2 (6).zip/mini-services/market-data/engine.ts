// ─────────────────────────────────────────────────────────────────────────────
// Motor de simulação de mercado — um engine por símbolo.
//
// Microestrutura:
// - Preço mantido como TICK INDEX interno (float apenas no `fair`, que decide
//   quando bid/ask deslizam 1 tick); preço = idx * tick.
// - Momentum AR(1): mom = 0.92*mom + ruído; pressão agressora empurra o
//   momentum (compras no ask empurram para cima).
// - Probabilidade do agressor AR(1) em torno de 0.5 + rajadas (streaks) de
//   5–15 negócios do mesmo lado.
// - Regimes de atividade Markov (calm/normal/active/burst ~0.4/1/2.2/5),
//   trocando a cada 8–25s.
// - Negócios: nº por step ~ Poisson(baseRate × regime × dt); 70% no best,
//   30% variam (1–3 níveis); sweeps (1–4 níveis, 1 trade por nível) com
//   probabilidade crescente da pressão; big trades ~0.4% (4–12× o normal).
// - DOM: 12 níveis/lado com random walk (reabastecimento + cancelamentos),
//   walls ocasionais (se consumidas → preço acelera) e icebergs raros.
// - Sessão: volume, delta, nº de trades, vwap, high/low/open/last e mapas por
//   tick index desde o start; POC = tick de maior volume.
// ─────────────────────────────────────────────────────────────────────────────

import type { Server } from 'socket.io';
import {
  EV_CANDLE, EV_DOM, EV_HEATMAP, EV_MBO, EV_SESSION, EV_TRADE,
  TF_MS, TIMEFRAMES,
  type Aggressor, type Candle, type CaptureEvent, type DomLevel, type DomSnapshot,
  type HeatmapBucket, type HeatmapMsg, type SessionStats,
  type SnapshotPayload, type Timeframe, type Trade,
} from './types';
import {
  RATE_MULT, REGIME_TRANSITIONS, STEP_MS, VOL_MULT, SYMBOL_CONFIGS,
  type Regime, type SymbolCfg,
} from './config';
import { encodeMboFrame, type MboDeltaInput } from './flatbuf';
import { pregenSymbol } from './pregen';
import { clamp, gauss, poisson, priceOf, roundSize, U } from './util';

interface BookLevel {
  q: number;
  /** quantidade base do nível (reversão à média do random walk) */
  base?: number;
  /** parede: expira neste timestamp */
  wallUntil?: number;
  /** recargas restantes do iceberg */
  ice?: number;
  /** quantidade restaurada a cada recarga do iceberg */
  iceQty?: number;
}

const HISTORY_CAP = 800;
const TAPE_CAP = 300;
const DOM_LEVELS = 12;
/** janela (± ticks) de vol/delta de sessão enviada no DOM (limita payload) */
const DOM_WINDOW = 400;
const CANDLE_THROTTLE = 250;
const DOM_THROTTLE = 200;
const SESSION_THROTTLE = 1000;
/** profundidade (± ticks) registrada no heatmap de liquidez */
const HEAT_DEPTH = 56;
/** nº máximo de buckets de heatmap mantidos por timeframe */
const HEATMAP_CAP = 360;
/** buckets enviados no snapshot inicial */
const HEAT_SNAPSHOT = 300;
const HEAT_THROTTLE = 500;
/** profundidade do stream MBO binário (± ticks em torno do mid) */
const MBO_DEPTH = HEAT_DEPTH;
/** tradesRecentes embutidos no frame full de subscrição */
const MBO_FULL_TRADES = 60;
/** acima disso, o delta vira full frame (evita frame gigante em rajada) */
const MBO_MAX_DELTAS = 420;

export class SymbolEngine {
  /** id do símbolo no vetor SYMBOL_CONFIGS (vai no cabeçalho do frame MBO) */
  readonly symbolId: number;
  private fair: number; // índice fracionário: bid = floor(fair), ask = bid + 1
  private mom = 0;
  private buyProb = 0.5;
  private bidIdx: number;
  private askIdx: number;
  private regime: Regime = 'normal';
  private regimeUntil = 0;
  private streak: { side: Aggressor; left: number } | null = null;

  private book = new Map<number, BookLevel>();
  private hist: Record<Timeframe, Candle[]>;
  private cur: Record<Timeframe, Candle>;
  private lastCandleEmit: Record<Timeframe, number>;

  private sessionVol: Record<number, number>;
  private sessionDelta: Record<number, number>;
  private pocIdx: number;
  private sess: { open: number; high: number; low: number; volume: number; delta: number; trades: number; vwapNum: number };

  private tape: Trade[] = [];
  private tradeId: number;
  private lastPrice: number;
  private lastDomEmit = 0;
  private lastSessionEmit = 0;
  private stepPress = 0;
  private timer: ReturnType<typeof setInterval> | null = null;

  // ── sink do journal (gravação de sessão) ──────────────────────────────────
  private capSink: ((ev: CaptureEvent) => void) | null = null;
  private capCandle: Record<Timeframe, number> = {} as Record<Timeframe, number>;
  private capHeat: Record<Timeframe, number> = {} as Record<Timeframe, number>;
  private capDomT = 0;
  private capSessT = 0;

  // ── stream MBO binário (FlatBuffers-style) ───────────────────────────────
  /** negócios gerados no step corrente (viram payload do frame MBO) */
  private pendingTrades: Trade[] = [];
  /** último estado enviado por nível (idx → q arredondada); null = próximo frame é full */
  private lastSentBook: Map<number, number> | null = null;
  /** sequência monotônica de frames por símbolo */
  private mboSeq = 0;
  /** frames delta desde o último full (full periódico = resincronização) */
  private framesSinceFull = 0;

  /** heatmap de liquidez: tf → bucket t → tick idx → [bidMax, askMax] */
  private heat: Record<Timeframe, Map<number, Map<number, [number, number]>>>;
  private lastHeatEmit: Record<Timeframe, number>;

  constructor(
    private io: Server,
    readonly cfg: SymbolCfg,
  ) {
    this.symbolId = Math.max(0, SYMBOL_CONFIGS.findIndex((c) => c.symbol === cfg.symbol));
    const now = Date.now();
    const pre = pregenSymbol(cfg, now);

    this.hist = {} as Record<Timeframe, Candle[]>;
    this.cur = {} as Record<Timeframe, Candle>;
    this.lastCandleEmit = {} as Record<Timeframe, number>;
    for (const tf of TIMEFRAMES) {
      const arr = pre.candles[tf]!;
      this.cur[tf] = arr[arr.length - 1]!;
      this.hist[tf] = arr.slice(0, -1);
      this.lastCandleEmit[tf] = 0;
    }
    this.tape = pre.tape;
    this.tradeId = pre.nextTradeId;
    this.sessionVol = pre.sessionVol;
    this.sessionDelta = pre.sessionDelta;
    const s = pre.sessionSeed;
    this.sess = {
      open: s.open, high: s.high, low: s.low,
      volume: s.volume, delta: s.delta, trades: s.trades, vwapNum: s.vwapNum,
    };
    this.pocIdx = s.pocIdx;
    this.lastPrice = s.last;

    this.heat = {} as Record<Timeframe, Map<number, Map<number, [number, number]>>>;
    this.lastHeatEmit = {} as Record<Timeframe, number>;
    for (const tf of TIMEFRAMES) {
      this.heat[tf] = new Map();
      this.lastHeatEmit[tf] = 0;
      this.capCandle[tf] = 0;
      this.capHeat[tf] = 0;
    }
    this.backfillHeatmap();

    const startIdx = Math.round(cfg.startPrice / cfg.tick);
    this.fair = startIdx + 0.5;
    this.bidIdx = startIdx;
    this.askIdx = startIdx + 1;
    for (let i = -16; i <= 16; i++) this.ensureLevel(startIdx + i);
    this.regimeUntil = now + U(8000, 25000);

    console.log(
      `[pregen] ${cfg.symbol}: 600 velas x 4 TFs, tape ${pre.tape.length}, sessão vol ${s.volume} (${Date.now() - now}ms)`,
    );
  }

  start(): void {
    if (!this.timer) this.timer = setInterval(() => this.step(), STEP_MS);
  }

  stop(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  /** Registra o sink do journal (1 capture() por evento relevante). */
  setCaptureSink(sink: ((ev: CaptureEvent) => void) | null): void {
    this.capSink = sink;
  }

  private cap(k: CaptureEvent['k'], t: number, d: unknown, tf?: Timeframe): void {
    if (!this.capSink) return;
    try {
      this.capSink({ sym: this.cfg.symbol, k, tf, t, d });
    } catch {
      // journal nunca derruba o engine
    }
  }

  /** Captura (throttled) de velas em formação, DOM, sessão e heatmap — sem depender de sala. */
  private captureCommon(now: number): void {
    if (!this.capSink) return;
    for (const tf of TIMEFRAMES) {
      if (now - this.capCandle[tf]! >= 1000) {
        this.capCandle[tf] = now;
        this.cap('candle', now, { tf, candle: this.cur[tf] }, tf);
      }
    }
    if (now - this.capDomT >= 1000) {
      this.capDomT = now;
      this.cap('dom', now, this.buildDom());
    }
    if (now - this.capSessT >= 1000) {
      this.capSessT = now;
      this.cap('session', now, this.sessionStats());
    }
    for (const tf of TIMEFRAMES) {
      if (now - this.capHeat[tf]! < 1000) continue;
      this.capHeat[tf] = now;
      const tfMs = TF_MS[tf];
      const t = Math.floor(now / tfMs) * tfMs;
      const m = this.heat[tf]!.get(t);
      if (!m) continue;
      const lv: Record<number, [number, number]> = {};
      for (const [idx, pair] of m) {
        if (pair[0] <= 0 && pair[1] <= 0) continue;
        lv[idx] = pair;
      }
      this.cap('heat', now, { tf, bucket: { t, lv } }, tf);
    }
  }

  // ── loop de simulação ──────────────────────────────────────────────────────

  private step(): void {
    const now = Date.now();
    if (now >= this.regimeUntil) {
      this.regime = this.nextRegime(this.regime);
      this.regimeUntil = now + U(8000, 25000);
    }
    this.updatePrice();
    this.walkBook(now);
    this.genTrades(now);
    for (const tf of TIMEFRAMES) this.rollIfNeeded(tf, now);
    this.recordHeat(now);
    this.emitMbo(now);
    this.emitDom(now);
    this.emitSession(now);
    this.emitCandles(now);
    this.emitHeat(now);
    this.captureCommon(now);
  }

  private nextRegime(r: Regime): Regime {
    const table = REGIME_TRANSITIONS[r]!;
    let x = Math.random();
    for (const [state, p] of table) {
      x -= p;
      if (x <= 0) return state;
    }
    return table[table.length - 1]![0];
  }

  /** Evolução do preço: momentum AR(1) + pressão; bid/ask deslizam quando o mid atravessa um tick. */
  private updatePrice(): void {
    const cfg = this.cfg;
    const vm = VOL_MULT[this.regime];
    this.mom = this.mom * 0.92 + gauss() * cfg.sigM * vm;
    this.mom += (this.buyProb - 0.5) * cfg.pushProb;
    this.mom += this.stepPress;
    this.stepPress = 0;
    this.mom = clamp(this.mom, -cfg.maxMom, cfg.maxMom);
    this.buyProb = clamp(0.5 + (this.buyProb - 0.5) * 0.94 + gauss() * 0.02, 0.22, 0.78);
    this.fair += this.mom + gauss() * cfg.sigW * vm;
    const b = Math.floor(this.fair);
    if (b !== this.bidIdx) {
      this.bidIdx = b;
      this.askIdx = b + 1;
      this.ensureLevel(this.bidIdx);
      this.ensureLevel(this.askIdx);
    }
  }

  /** Random walk das quantidades do book + walls e icebergs. */
  private walkBook(now: number): void {
    const cfg = this.cfg;
    const sd = cfg.sizeDecimals;
    const center = this.bidIdx;
    for (const [idx, lvl] of this.book) {
      // mantém profundidade suficiente para alimentar o heatmap (± HEAT_DEPTH)
      if (idx < center - (HEAT_DEPTH + 10) || idx > center + (HEAT_DEPTH + 10)) {
        this.book.delete(idx);
        continue;
      }
      if (lvl.wallUntil !== undefined && lvl.wallUntil <= now) lvl.wallUntil = undefined;
      if (lvl.wallUntil === undefined && lvl.ice === undefined) {
        // reversão à média: cada nível orbita sua quantidade base (estrutura
        // heterogênea e estável — essencial p/ um heatmap com textura)
        if (lvl.base === undefined) lvl.base = roundSize(cfg.lvlQty * U(0.3, 1.7), sd);
        if (Math.random() < 0.3) {
          lvl.q += (lvl.base - lvl.q) * U(0.04, 0.22) + gauss() * cfg.lvlQty * 0.05;
          if (lvl.q < cfg.lvlQty * 0.05) lvl.q = cfg.lvlQty * U(0.1, 0.4);
          lvl.q = roundSize(Math.max(lvl.q, 0), sd);
        }
      }
    }
    // semeia níveis ausentes em toda a profundidade (liquidez esparsa longe do mid)
    if (Math.random() < 0.6) {
      const k = center + Math.round(U(-HEAT_DEPTH, HEAT_DEPTH + 1));
      this.ensureLevel(k);
    }
    // parede ocasional (mais frequente em burst)
    if (Math.random() < 0.0035 * (this.regime === 'burst' ? 3 : 1)) {
      const idx = center + Math.round(U(2, 12)) * (Math.random() < 0.5 ? 1 : -1);
      const lvl = this.ensureLevel(idx);
      lvl.q = roundSize(U(cfg.wallMin, cfg.wallMax), sd);
      lvl.wallUntil = now + U(15000, 60000);
      lvl.ice = undefined;
    }
    // iceberg raro: nível que se auto-reabastece ao ser atingido
    if (Math.random() < 0.0008) {
      const idx = center + Math.round(U(1, 8)) * (Math.random() < 0.5 ? 1 : -1);
      const lvl = this.ensureLevel(idx);
      lvl.ice = Math.round(U(4, 8));
      lvl.iceQty = Math.max(lvl.q, roundSize(cfg.lvlQty * U(0.8, 1.5), sd));
    }
  }

  private ensureLevel(idx: number): BookLevel {
    let lvl = this.book.get(idx);
    if (!lvl || lvl.q <= 0) {
      lvl = { q: roundSize(this.cfg.lvlQty * U(0.4, 1.7), this.cfg.sizeDecimals) };
      lvl.base = roundSize(this.cfg.lvlQty * U(0.3, 1.7), this.cfg.sizeDecimals);
      this.book.set(idx, lvl);
    }
    return lvl;
  }

  // ── geração de negócios ────────────────────────────────────────────────────

  private genTrades(now: number): void {
    const dt = STEP_MS / 1000;
    const lambda = this.cfg.baseRate * RATE_MULT[this.regime] * dt * U(0.6, 1.5);
    if (!this.streak && Math.random() < 0.012) {
      this.streak = {
        side: Math.random() < this.buyProb ? 'buy' : 'sell',
        left: 5 + Math.floor(Math.random() * 11), // 5–15 negócios do mesmo lado
      };
    }
    const count = poisson(lambda);
    for (let i = 0; i < count; i++) {
      let side: Aggressor;
      if (this.streak) {
        side = this.streak.side;
        if (--this.streak.left <= 0) this.streak = null;
      } else {
        side = Math.random() < this.buyProb ? 'buy' : 'sell';
      }
      const pressure = Math.abs(this.buyProb - 0.5) / 0.28; // 0..1
      const sweepP = 0.02 + 0.1 * pressure + (this.regime === 'burst' ? 0.06 : this.regime === 'active' ? 0.02 : 0);
      if (Math.random() < sweepP) {
        // sweep: consome 1–4 níveis (1 trade por nível), volume maior por nível
        const depth = 1 + Math.floor(Math.pow(Math.random(), 1.4) * 4);
        this.emitSequence(side, depth, U(0.9, 2.2), now);
        this.mom += (side === 'buy' ? 1 : -1) * this.cfg.kick * U(0.5, 1.2);
      } else {
        // 70% no best, 30% variam (atravessam 1–2 níveis extras)
        const depth = Math.random() < 0.7 ? 1 : Math.random() < 0.8 ? 2 : 3;
        this.emitSequence(side, depth, 1, now);
      }
    }
  }

  private emitSequence(side: Aggressor, depth: number, sizeMult: number, now: number): void {
    for (let j = 0; j < depth; j++) {
      const s = this.sizeSample(sizeMult);
      const k = side === 'buy' ? this.consumeAsk(s, now) : this.consumeBid(s, now);
      const trade: Trade = { id: ++this.tradeId, t: now, p: priceOf(this.cfg, k), s, side };
      if (s >= this.cfg.bigThreshold) trade.big = true;
      this.tape.push(trade);
      if (this.tape.length > TAPE_CAP) this.tape.splice(0, this.tape.length - TAPE_CAP);
      this.pendingTrades.push(trade);
      this.applyTrade(trade, k);
      this.stepPress += (side === 'buy' ? 1 : -1) * (s / this.cfg.avgSize) * this.cfg.pushTrade;
      this.cap('trade', trade.t, trade);
      const room = `sym:${this.cfg.symbol}`;
      if (this.roomSize(room) > 0) this.io.to(room).emit(EV_TRADE, trade);
    }
  }

  private sizeSample(mult: number): number {
    const cfg = this.cfg;
    let s: number;
    const bigP = this.regime === 'burst' ? 0.012 : this.regime === 'active' ? 0.006 : 0.004;
    if (Math.random() < bigP) s = Math.max(cfg.bigThreshold * U(1, 2.5), cfg.avgSize * U(4, 12)) * mult;
    else s = Math.exp(gauss() * 0.85) * cfg.avgSize * mult;
    s = clamp(s, cfg.minSize, cfg.maxSize * 2);
    return roundSize(s, cfg.sizeDecimals);
  }

  /** Agressor de compra consome o nível do ask; se esgotar, o book desliza 1 tick. */
  private consumeAsk(s: number, now: number): number {
    const lvl = this.ensureLevel(this.askIdx);
    lvl.q -= s;
    const px = this.askIdx;
    if (lvl.q <= 0) {
      const hadWall = lvl.wallUntil !== undefined && lvl.wallUntil > now;
      if (lvl.ice && lvl.ice > 0) {
        lvl.ice -= 1;
        lvl.q = Math.max(lvl.iceQty ?? this.cfg.lvlQty, s);
      } else {
        this.book.delete(this.askIdx);
        this.bidIdx += 1;
        this.askIdx += 1;
        this.fair = this.bidIdx + 0.5;
        this.ensureLevel(this.bidIdx);
        this.ensureLevel(this.askIdx);
        if (hadWall) this.mom += this.cfg.kick * U(2, 4); // parede consumida no ask → acelera p/ cima
      }
    }
    return px;
  }

  /** Agressor de venda consome o nível do bid; se esgotar, o book desliza 1 tick. */
  private consumeBid(s: number, now: number): number {
    const lvl = this.ensureLevel(this.bidIdx);
    lvl.q -= s;
    const px = this.bidIdx;
    if (lvl.q <= 0) {
      const hadWall = lvl.wallUntil !== undefined && lvl.wallUntil > now;
      if (lvl.ice && lvl.ice > 0) {
        lvl.ice -= 1;
        lvl.q = Math.max(lvl.iceQty ?? this.cfg.lvlQty, s);
      } else {
        this.book.delete(this.bidIdx);
        this.bidIdx -= 1;
        this.askIdx -= 1;
        this.fair = this.bidIdx + 0.5;
        this.ensureLevel(this.bidIdx);
        this.ensureLevel(this.askIdx);
        if (hadWall) this.mom -= this.cfg.kick * U(2, 4); // parede consumida no bid → acelera p/ baixo
      }
    }
    return px;
  }

  // ── candles, sessão, tape ──────────────────────────────────────────────────

  private applyTrade(trade: Trade, k: number): void {
    const sd = this.cfg.sizeDecimals;
    const signed = trade.side === 'buy' ? trade.s : -trade.s;
    for (const tf of TIMEFRAMES) {
      this.rollIfNeeded(tf, trade.t);
      const cur = this.cur[tf]!;
      if (trade.p > cur.h) cur.h = trade.p;
      if (trade.p < cur.l) cur.l = trade.p;
      cur.c = trade.p;
      cur.v = roundSize(cur.v + trade.s, sd);
      cur.d = roundSize(cur.d + signed, sd);
      cur.n += 1;
      let cl = cur.lv[k];
      if (!cl) {
        cl = { b: 0, a: 0 };
        cur.lv[k] = cl;
      }
      if (trade.side === 'buy') cl.a = roundSize(cl.a + trade.s, sd);
      else cl.b = roundSize(cl.b + trade.s, sd);
    }
    // sessão (desde o start do servidor + seed do histórico pré-gerado)
    this.sessionVol[k] = roundSize((this.sessionVol[k] ?? 0) + trade.s, sd);
    this.sessionDelta[k] = roundSize((this.sessionDelta[k] ?? 0) + signed, sd);
    if (this.sessionVol[k]! > (this.sessionVol[this.pocIdx] ?? 0)) this.pocIdx = k;
    const sess = this.sess;
    sess.volume = roundSize(sess.volume + trade.s, sd);
    sess.delta = roundSize(sess.delta + signed, sd);
    sess.trades += 1;
    sess.vwapNum += trade.p * trade.s;
    if (trade.p > sess.high) sess.high = trade.p;
    if (trade.p < sess.low) sess.low = trade.p;
    this.lastPrice = trade.p;
  }

  /** Fecha o bucket do tf se mudou: move a vela para o histórico e cria a nova. */
  private rollIfNeeded(tf: Timeframe, t: number): void {
    const tfMs = TF_MS[tf];
    const b = Math.floor(t / tfMs) * tfMs;
    const cur = this.cur[tf]!;
    if (cur.t === b) return;
    this.hist[tf]!.push(cur);
    if (this.hist[tf]!.length > HISTORY_CAP) this.hist[tf]!.splice(0, this.hist[tf]!.length - HISTORY_CAP);
    const next: Candle = { t: b, o: cur.c, h: cur.c, l: cur.c, c: cur.c, v: 0, d: 0, n: 0, lv: {} };
    this.cur[tf] = next;
    this.lastCandleEmit[tf] = t;
    this.emitCandleObj(tf, cur); // vela fechada
    this.emitCandleObj(tf, next); // nova em formação, em sequência
    this.cap('candle', cur.t, { tf, candle: cur }, tf); // vela fechada p/ o journal
  }

  // ── emissões ───────────────────────────────────────────────────────────────

  private roomSize(room: string): number {
    return this.io.of('/').adapter.rooms.get(room)?.size ?? 0;
  }

  private emitCandleObj(tf: Timeframe, candle: Candle): void {
    const room = `tf:${this.cfg.symbol}|${tf}`;
    if (this.roomSize(room) === 0) return;
    this.io.to(room).emit(EV_CANDLE, { tf, candle });
  }

  private emitCandles(now: number): void {
    for (const tf of TIMEFRAMES) {
      const room = `tf:${this.cfg.symbol}|${tf}`;
      if (this.roomSize(room) === 0) continue;
      if (now - this.lastCandleEmit[tf]! < CANDLE_THROTTLE) continue;
      this.lastCandleEmit[tf] = now;
      this.io.to(room).emit(EV_CANDLE, { tf, candle: this.cur[tf] });
    }
  }

  private emitDom(now: number): void {
    const room = `sym:${this.cfg.symbol}`;
    if (this.roomSize(room) === 0) return;
    if (now - this.lastDomEmit < DOM_THROTTLE) return;
    this.lastDomEmit = now;
    this.io.to(room).emit(EV_DOM, this.buildDom());
  }

  private emitSession(now: number): void {
    const room = `sym:${this.cfg.symbol}`;
    if (this.roomSize(room) === 0) return;
    if (now - this.lastSessionEmit < SESSION_THROTTLE) return;
    this.lastSessionEmit = now;
    this.io.to(room).emit(EV_SESSION, this.sessionStats());
  }

  // ── stream MBO binário (delta do order book, FlatBuffers-style) ────────────

  /**
   * Difunde o frame MBO do step: trades do step + DELTA do book (somente
   * níveis alterados desde o último frame enviado). Se o delta estourar o
   * limite, ou se nunca houve frame enviado, cai para full snapshot.
   */
  private emitMbo(now: number): void {
    const room = `sym:${this.cfg.symbol}`;
    const hasRoom = this.roomSize(room) > 0;
    if (!hasRoom) {
      // sem espectadores: zera o baseline p/ que o próximo frame seja full
      this.lastSentBook = null;
      this.pendingTrades.length = 0;
      return;
    }

    const trades = this.pendingTrades;
    this.pendingTrades = [];

    // ── delta do book ────────────────────────────────────────────────────────
    const deltas: MboDeltaInput[] = [];
    const cur = new Map<number, number>();
    const center = this.bidIdx;
    for (const [idx, lvl] of this.book) {
      if (idx < center - MBO_DEPTH || idx > center + MBO_DEPTH) continue;
      const q = roundSize(Math.max(lvl.q, 0), this.cfg.sizeDecimals);
      cur.set(idx, q);
      const prev = this.lastSentBook?.get(idx);
      if (prev === undefined || Math.abs(prev - q) > 1e-9) {
        deltas.push({ idx, side: idx <= this.bidIdx ? 0 : 1, op: 0, qty: q });
      }
    }
    if (this.lastSentBook) {
      for (const [idx] of this.lastSentBook) {
        if (!cur.has(idx)) deltas.push({ idx, side: 0, op: 1, qty: 0 });
      }
    }

    const full =
      !this.lastSentBook || deltas.length > MBO_MAX_DELTAS || ++this.framesSinceFull > 250;
    const payload = full
      ? this.buildMboDeltas(now, trades, cur)
      : deltas;
    if (full) {
      this.framesSinceFull = 0;
    } else {
      // mantém baseline coerente: níveis apagados saem do mapa enviado
      this.lastSentBook = cur;
    }

    const buf = encodeMboFrame(
      {
        full,
        symbolId: this.symbolId,
        seq: ++this.mboSeq,
        serverTime: now,
        bestBidIdx: this.bidIdx,
        bestAskIdx: this.askIdx,
        cvd: this.sess.delta,
        lastPriceIdx: Math.round(this.lastPrice / this.cfg.tick),
      },
      trades.map((t) => ({
        t: t.t,
        p: Math.round(t.p / this.cfg.tick),
        s: t.s,
        side: t.side,
        big: t.big,
      })),
      payload,
    );
    this.io.to(room).emit(EV_MBO, buf);
    this.cap('mbo', now, buf);
  }

  /**
   * Delta para um frame FULL: todos os níveis vivos na janela ±MBO_DEPTH
   * (upsert) — o cliente reseta a janela dele antes de aplicar.
   */
  private buildMboDeltas(now: number, _trades: Trade[], cur: Map<number, number>): MboDeltaInput[] {
    void now;
    void _trades;
    const out: MboDeltaInput[] = [];
    for (const [idx, q] of cur) {
      out.push({ idx, side: idx <= this.bidIdx ? 0 : 1, op: 0, qty: q });
    }
    this.lastSentBook = cur;
    return out;
  }

  /** Frame FULL para o recém-subscrito: book completo + últimos trades do tape. */
  mboFullFrame(): ArrayBuffer {
    const now = Date.now();
    const sd = this.cfg.sizeDecimals;
    const trades = this.tape.slice(-MBO_FULL_TRADES);
    const deltas: MboDeltaInput[] = [];
    const cur = new Map<number, number>();
    for (const [idx, lvl] of this.book) {
      if (idx < this.bidIdx - MBO_DEPTH || idx > this.askIdx + MBO_DEPTH) continue;
      const q = roundSize(Math.max(lvl.q, 0), sd);
      if (q <= 0) continue;
      cur.set(idx, q);
      deltas.push({ idx, side: idx <= this.bidIdx ? 0 : 1, op: 0, qty: q });
    }
    this.lastSentBook = cur;
    const buf = encodeMboFrame(
      {
        full: true,
        symbolId: this.symbolId,
        seq: ++this.mboSeq,
        serverTime: now,
        bestBidIdx: this.bidIdx,
        bestAskIdx: this.askIdx,
        cvd: this.sess.delta,
        lastPriceIdx: Math.round(this.lastPrice / this.cfg.tick),
      },
      trades.map((t) => ({
        t: t.t,
        p: Math.round(t.p / this.cfg.tick),
        s: t.s,
        side: t.side,
        big: t.big,
      })),
      deltas,
    );
    return buf;
  }

  // ── heatmap de liquidez (book restante por bucket) ───────────────────────

  /** Registra o estado atual do book em todos os timeframes (máximo por nível). */
  private recordHeat(now: number): void {
    const sd = this.cfg.sizeDecimals;
    for (const tf of TIMEFRAMES) {
      const tfMs = TF_MS[tf];
      const t = Math.floor(now / tfMs) * tfMs;
      let m = this.heat[tf]!.get(t);
      if (!m) {
        m = new Map();
        this.heat[tf]!.set(t, m);
        if (this.heat[tf]!.size > HEATMAP_CAP) {
          const oldest = this.heat[tf]!.keys().next().value;
          if (oldest !== undefined) this.heat[tf]!.delete(oldest);
        }
      }
      for (const [idx, lvl] of this.book) {
        if (lvl.q <= 0) continue;
        if (idx < this.bidIdx - HEAT_DEPTH || idx > this.askIdx + HEAT_DEPTH) continue;
        const side = idx <= this.bidIdx ? 0 : 1; // 0 = bid, 1 = ask
        const q = roundSize(lvl.q, sd);
        const cur = m.get(idx);
        if (!cur) m.set(idx, side === 0 ? [q, 0] : [0, q]);
        else if (q > cur[side]) cur[side] = q;
      }
    }
  }

  /** Envia (throttled) o bucket atual do heatmap para a sala do tf. */
  private emitHeat(now: number): void {
    for (const tf of TIMEFRAMES) {
      const room = `tf:${this.cfg.symbol}|${tf}`;
      if (this.roomSize(room) === 0) continue;
      if (now - this.lastHeatEmit[tf]! < HEAT_THROTTLE) continue;
      this.lastHeatEmit[tf] = now;
      const tfMs = TF_MS[tf];
      const t = Math.floor(now / tfMs) * tfMs;
      const m = this.heat[tf]!.get(t);
      if (!m) continue;
      const lv: Record<number, [number, number]> = {};
      for (const [idx, pair] of m) {
        if (pair[0] <= 0 && pair[1] <= 0) continue;
        lv[idx] = pair;
      }
      this.io.to(room).emit(EV_HEATMAP, { tf, bucket: { t, lv } } satisfies HeatmapMsg);
    }
  }

  /**
   * Backfill sintético: gera buckets plausíveis de liquidez a partir das velas
   * pré-geradas (sino de liquidez ao redor do preço + paredes ocasionais),
   * para que o heatmap não nasça vazio após um restart do serviço.
   */
  private backfillHeatmap(): void {
    const cfg = this.cfg;
    const sd = cfg.sizeDecimals;
    for (const tf of TIMEFRAMES) {
      const candles = this.hist[tf]!.slice(-(HEATMAP_CAP - 1));
      for (const c of candles) {
        const lo = Math.round(c.l / cfg.tick);
        const hi = Math.round(c.h / cfg.tick);
        const mid = (lo + hi) / 2;
        const sigma = Math.max(4, (hi - lo) / 4);
        const m = new Map<number, [number, number]>();
        const kLo = Math.max(lo - HEAT_DEPTH + 8, lo - 24);
        const kHi = Math.min(hi + HEAT_DEPTH - 8, hi + 24);
        for (let k = kLo; k <= kHi; k++) {
          const base = cfg.lvlQty * Math.exp(-((k - mid) * (k - mid)) / (2 * sigma * sigma));
          const q = roundSize(base * U(0.4, 1.6), sd);
          if (q <= 0) continue;
          m.set(k, k <= Math.floor(mid) ? [q, 0] : [0, q]);
        }
        // paredes ocasionais perto das extremidades da vela
        if (Math.random() < 0.3) {
          const k = Math.round(U(lo - 10, lo - 1));
          m.set(k, [roundSize(U(cfg.wallMin, cfg.wallMax) * U(0.5, 1.1), sd), 0]);
        }
        if (Math.random() < 0.3) {
          const k = Math.round(U(hi + 1, hi + 10));
          m.set(k, [0, roundSize(U(cfg.wallMin, cfg.wallMax) * U(0.5, 1.1), sd)]);
        }
        this.heat[tf]!.set(c.t, m);
      }
    }
  }

  // ── payloads ───────────────────────────────────────────────────────────────

  buildDom(): DomSnapshot {
    const cfg = this.cfg;
    const sd = cfg.sizeDecimals;
    const bids: DomLevel[] = [];
    const asks: DomLevel[] = [];
    for (let i = 0; i < DOM_LEVELS; i++) {
      const bi = this.bidIdx - i;
      const bl = this.ensureLevel(bi);
      bids.push({ p: priceOf(cfg, bi), s: roundSize(Math.max(bl.q, 0), sd) });
    }
    for (let i = DOM_LEVELS - 1; i >= 0; i--) {
      const ai = this.askIdx + i;
      const al = this.ensureLevel(ai);
      asks.push({ p: priceOf(cfg, ai), s: roundSize(Math.max(al.q, 0), sd) });
    }
    const vol: Record<number, number> = {};
    const delta: Record<number, number> = {};
    for (const key of Object.keys(this.sessionVol)) {
      const k = Number(key);
      if (k < this.bidIdx - DOM_WINDOW || k > this.askIdx + DOM_WINDOW) continue;
      vol[k] = this.sessionVol[k]!;
      const d = this.sessionDelta[k];
      if (d !== undefined) delta[k] = d;
    }
    return { bids, asks, vol, delta };
  }

  sessionStats(): SessionStats {
    const s = this.sess;
    return {
      symbol: this.cfg.symbol,
      open: s.open,
      high: s.high,
      low: s.low,
      last: this.lastPrice,
      volume: s.volume,
      delta: s.delta,
      trades: s.trades,
      vwap: s.volume > 0 ? +(s.vwapNum / s.volume).toFixed(this.cfg.priceDecimals) : this.lastPrice,
      poc: priceOf(this.cfg, this.pocIdx),
    };
  }

  snapshot(symbol: string, tf: Timeframe): SnapshotPayload {
    return {
      symbol,
      tf,
      serverTime: Date.now(),
      candles: [...this.hist[tf]!.slice(-399), this.cur[tf]!],
      dom: this.buildDom(),
      tape: this.tape.slice(-200),
      session: this.sessionStats(),
      heatmap: this.heatSnapshot(tf),
    };
  }

  /** Últimos HEAT_SNAPSHOT buckets do heatmap do tf (ordem crescente de tempo). */
  private heatSnapshot(tf: Timeframe): HeatmapBucket[] {
    const keys = Array.from(this.heat[tf]!.keys());
    const out: HeatmapBucket[] = [];
    for (const t of keys.slice(-HEAT_SNAPSHOT)) {
      const m = this.heat[tf]!.get(t)!;
      const lv: Record<number, [number, number]> = {};
      for (const [idx, pair] of m) {
        if (pair[0] <= 0 && pair[1] <= 0) continue;
        lv[idx] = pair;
      }
      out.push({ t, lv });
    }
    return out;
  }
}
