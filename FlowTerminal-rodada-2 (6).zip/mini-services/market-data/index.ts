// ─────────────────────────────────────────────────────────────────────────────
// Mini-serviço de simulação de mercado (order flow sintético realista).
// Bun + socket.io · porta fixa 3003 · path '/' (usado pelo gateway Caddy).
// Rodada 6: JOURNAL de mercado — gravação de sessões (bun:sqlite) + replay
// transmitido com playhead/velocidade/seek + REST /journal/*.
// ─────────────────────────────────────────────────────────────────────────────

import { createServer, type IncomingMessage, type ServerResponse } from 'node:http';
import { Server } from 'socket.io';
import { SYMBOL_CONFIGS } from './config';
import { SymbolEngine } from './engine';
import { Journal } from './journal';
import {
  EV_J_EVENT, EV_J_LOAD, EV_J_PLAY, EV_J_SEEK,
  EV_J_SNAPSHOT, EV_J_SPEED, EV_J_STATUS, EV_J_STOP,
  EV_MBO, EV_SNAPSHOT, EV_SUBSCRIBE, EV_UNSUBSCRIBE, TIMEFRAMES,
  type CaptureEvent, type SnapshotPayload,
  type SubscribeMsg, type Timeframe,
} from './types';

// ── journal (gravação + replay de sessões) ───────────────────────────────────
const journal = new Journal();

// ── HTTP: REST do journal (rotas /journal/*; o resto fica c/ o socket.io) ────
function readBody(req: IncomingMessage): Promise<string> {
  return new Promise((resolve) => {
    let s = '';
    req.on('data', (c: Buffer) => {
      s += c.toString();
      if (s.length > 1e6) req.destroy();
    });
    req.on('end', () => resolve(s));
    req.on('error', () => resolve(s));
  });
}

function sendJson(res: ServerResponse, code: number, body: unknown): void {
  const payload = JSON.stringify(body);
  res.writeHead(code, {
    'content-type': 'application/json; charset=utf-8',
    'access-control-allow-origin': '*',
    'access-control-allow-methods': 'GET,POST,DELETE,OPTIONS',
    'access-control-allow-headers': 'content-type',
  });
  res.end(payload);
}

async function handleHttp(req: IncomingMessage, res: ServerResponse): Promise<void> {
  const url = new URL(req.url ?? '/', 'http://local');
  if (!url.pathname.startsWith('/journal/')) return; // não é rota nossa
  if (req.method === 'OPTIONS') {
    sendJson(res, 204, {});
    return;
  }
  try {
    // GET /journal/sessions — lista sessões gravadas
    if (req.method === 'GET' && url.pathname === '/journal/sessions') {
      sendJson(res, 200, { sessions: journal.list(), recording: journal.recording });
      return;
    }
    // POST /journal/rec — liga/desliga a gravação
    if (req.method === 'POST' && url.pathname === '/journal/rec') {
      const body = JSON.parse((await readBody(req)) || '{}') as {
        on?: boolean; symbol?: string; tf?: Timeframe;
      };
      if (body.on === false) {
        journal.stop();
        sendJson(res, 200, { ok: true });
        return;
      }
      const symbol = String(body.symbol ?? '');
      const tf = String(body.tf ?? '') as Timeframe;
      const engine = engines.get(symbol);
      if (!engine || !TIMEFRAMES.includes(tf)) {
        sendJson(res, 400, { ok: false, error: 'symbol/tf inválido' });
        return;
      }
      const base = engine.snapshot(symbol, tf);
      const sessionId = journal.start(symbol, tf, base);
      sendJson(res, 200, { ok: true, sessionId });
      return;
    }
    // DELETE /journal/sessions/:id
    const delMatch = url.pathname.match(/^\/journal\/sessions\/(\d+)$/);
    if (req.method === 'DELETE' && delMatch) {
      journal.delete(Number(delMatch[1]));
      sendJson(res, 200, { ok: true });
      return;
    }
    sendJson(res, 404, { ok: false, error: 'rota desconhecida' });
  } catch (err) {
    console.error('journal http error:', err);
    sendJson(res, 500, { ok: false, error: 'erro interno' });
  }
}

// server HTTP puro; as rotas /journal/* são religadas após o attach do socket.io
const httpServer = createServer();

const io = new Server(httpServer, {
  // DO NOT change the path, it is used by Caddy to forward the request to the correct port
  path: '/',
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
  pingTimeout: 60000,
  pingInterval: 25000,
});

// socket.io (path '/') intercepta TODAS as requisições HTTP do server.
// Reembalamos os listeners: /journal/* → REST próprio; resto → engine.io.
const eioHandlers = httpServer.listeners('request');
httpServer.removeAllListeners('request');
httpServer.on('request', (req, res) => {
  const url = req.url ?? '';
  if (url.startsWith('/journal/') || url === '/journal') {
    void handleHttp(req, res);
    return;
  }
  for (const h of eioHandlers) h.call(httpServer, req, res);
});

// ── motores de simulação (um por símbolo, com pré-geração de histórico) ──────
const t0 = Date.now();
const engines = new Map<string, SymbolEngine>();
for (const cfg of SYMBOL_CONFIGS) {
  engines.set(cfg.symbol, new SymbolEngine(io, cfg));
}
console.log(`Engines prontos em ${Date.now() - t0}ms`);

// sink único: todo engine captura p/ o journal (journal filtra por sessão)
for (const engine of engines.values()) {
  engine.setCaptureSink((ev: CaptureEvent) => journal.capture(ev));
}

// ── replay do journal: pacer por socket ──────────────────────────────────────

interface JEvent {
  ts: number;
  k: string;
  tf?: Timeframe;
  /** payload decodificado (objeto p/ JSON, Buffer p/ frames MBO) */
  d: unknown;
}

interface ReplayState {
  sid: number;
  tf: Timeframe;
  events: JEvent[];
  pos: number;
  playing: boolean;
  speed: number;
  /** playhead em ms (tempo do mercado) */
  playhead: number;
  start: number;
  end: number;
  timer: ReturnType<typeof setInterval>;
  lastStatus: number;
}

const PACER_TICK = 80;
const PACER_SPEEDS = [0.25, 0.5, 1, 2, 4, 8, 16, 32];

type ReplaySocket = {
  data: { replay?: ReplayState };
  emit: (ev: string, p?: unknown) => void;
};

function stopReplay(socket: ReplaySocket): void {
  const r = socket.data.replay;
  if (!r) return;
  clearInterval(r.timer);
  socket.data.replay = undefined;
}

function loadJournalReplay(socket: ReplaySocket, sessionId: number, tf: Timeframe): void {
  stopReplay(socket);
  const rows = journal.allEvents(sessionId);
  if (rows.length === 0) {
    socket.emit(EV_J_STATUS, {
      sessionId, playing: false, speed: 1, ts: 0, start: 0, end: 0, pct: 0, ended: true,
    });
    return;
  }
  const events: JEvent[] = rows.map((r) => ({
    ts: r.ts,
    k: r.k,
    tf: r.tf ?? undefined,
    d: r.k === 'mbo' ? r.data : JSON.parse(String(r.data)),
  }));
  const start = events[0]!.ts;
  const end = events[events.length - 1]!.ts;
  const snap = journal.buildSnapshot(sessionId, tf, start);
  if (!snap) return;
  socket.emit(EV_J_SNAPSHOT, {
    sessionId,
    snapshot: snap satisfies SnapshotPayload,
    range: { start, end },
    ts: start,
  });

  const state: ReplayState = {
    sid: sessionId,
    tf,
    events,
    pos: 0,
    playing: true,
    speed: 1,
    playhead: start,
    start,
    end,
    timer: null as unknown as ReturnType<typeof setInterval>,
    lastStatus: 0,
  };
  state.timer = setInterval(() => tickReplay(socket, state), PACER_TICK);
  socket.data.replay = state;
  pushStatus(socket, state);
}

function tickReplay(socket: ReplaySocket, r: ReplayState): void {
  if (r.playing) {
    r.playhead += PACER_TICK * r.speed;
    for (;;) {
      const ev = r.events[r.pos];
      if (!ev || ev.ts > r.playhead) break;
      r.pos++;
      socket.emit(EV_J_EVENT, { k: ev.k, tf: ev.tf, t: ev.ts, d: ev.d });
    }
    if (r.pos >= r.events.length) {
      r.playing = false;
      pushStatus(socket, r);
      return;
    }
  }
  const now = Date.now();
  if (now - r.lastStatus >= 500) pushStatus(socket, r);
}

function pushStatus(socket: ReplaySocket, r: ReplayState): void {
  r.lastStatus = Date.now();
  const span = Math.max(1, r.end - r.start);
  socket.emit(EV_J_STATUS, {
    sessionId: r.sid,
    playing: r.playing,
    speed: r.speed,
    ts: Math.min(r.playhead, r.end),
    start: r.start,
    end: r.end,
    pct: Math.min(100, Math.max(0, ((r.playhead - r.start) / span) * 100)),
    ended: r.pos >= r.events.length,
  });
}

// ── subscrição e salas ───────────────────────────────────────────────────────
io.on('connection', (socket) => {
  socket.on(EV_SUBSCRIBE, (msg: SubscribeMsg) => {
    try {
      if (!msg || typeof msg !== 'object') return;
      const symbol = String(msg.symbol ?? '');
      const tf = String(msg.tf ?? '') as Timeframe;
      const engine = engines.get(symbol);
      if (!engine || !TIMEFRAMES.includes(tf)) return;

      stopReplay(socket); // volta ao vivo = replay encerrado

      // re-subscrição: sai das salas antigas para não receber dados do símbolo anterior
      const prev = socket.data.sub as { symbol: string; tf: Timeframe } | undefined;
      if (prev) {
        socket.leave(`sym:${prev.symbol}`);
        socket.leave(`tf:${prev.symbol}|${prev.tf}`);
      }

      const sub = { symbol, tf };
      socket.data.sub = sub;
      socket.join(`sym:${symbol}`);
      socket.join(`tf:${symbol}|${tf}`);

      // snapshot imediato para este socket (JSON) + frame MBO full (binário)
      socket.emit(EV_SNAPSHOT, engine.snapshot(symbol, tf));
      try {
        socket.emit(EV_MBO, engine.mboFullFrame());
      } catch (err) {
        console.error('mbo full frame error:', err);
      }
    } catch (err) {
      console.error('subscribe error:', err);
    }
  });

  socket.on(EV_UNSUBSCRIBE, () => {
    const prev = socket.data.sub as { symbol: string; tf: Timeframe } | undefined;
    if (prev) {
      socket.leave(`sym:${prev.symbol}`);
      socket.leave(`tf:${prev.symbol}|${prev.tf}`);
      socket.data.sub = undefined;
    }
  });

  // ── controle do replay do journal ──────────────────────────────────────────
  socket.on(EV_J_LOAD, (msg: { sessionId?: number; tf?: string }) => {
    try {
      const sessionId = Number(msg?.sessionId ?? 0);
      const tf = String(msg?.tf ?? '') as Timeframe;
      if (!sessionId || !TIMEFRAMES.includes(tf)) return;
      loadJournalReplay(socket, sessionId, tf);
    } catch (err) {
      console.error('journal load error:', err);
    }
  });

  socket.on(EV_J_PLAY, (msg: { playing?: boolean }) => {
    const r = socket.data.replay;
    if (!r) return;
    r.playing = !!msg?.playing && r.pos < r.events.length;
    pushStatus(socket, r);
  });

  socket.on(EV_J_SPEED, (msg: { speed?: number }) => {
    const r = socket.data.replay;
    if (!r) return;
    const x = Number(msg?.speed ?? 1);
    r.speed = PACER_SPEEDS.includes(x) ? x : 1;
    pushStatus(socket, r);
  });

  socket.on(EV_J_SEEK, (msg: { ts?: number }) => {
    try {
      const r = socket.data.replay;
      if (!r) return;
      const ts = Math.min(r.end, Math.max(r.start, Number(msg?.ts ?? r.start)));
      const snap = journal.buildSnapshot(r.sid, r.tf, ts);
      if (!snap) return;
      // primeiro evento com ts > alvo (os ≤ alvo já estão no snapshot)
      let lo = 0;
      let hi = r.events.length;
      while (lo < hi) {
        const mid = (lo + hi) >> 1;
        if (r.events[mid].ts <= ts) lo = mid + 1;
        else hi = mid;
      }
      r.pos = lo;
      r.playhead = ts;
      socket.emit(EV_J_SNAPSHOT, {
        sessionId: r.sid,
        snapshot: snap,
        range: { start: r.start, end: r.end },
        ts,
      });
      pushStatus(socket, r);
    } catch (err) {
      console.error('journal seek error:', err);
    }
  });

  socket.on(EV_J_STOP, () => stopReplay(socket));

  socket.on('disconnect', () => stopReplay(socket));
});

// ── start ────────────────────────────────────────────────────────────────────
for (const engine of engines.values()) engine.start();

const PORT = 3003;
httpServer.listen(PORT, () => {
  console.log(`Market data service running on port ${PORT}`);
});

// Graceful shutdown
function shutdown(signal: string): void {
  console.log(`Received ${signal}, shutting down...`);
  journal.dispose();
  for (const engine of engines.values()) engine.stop();
  httpServer.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 1500);
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
