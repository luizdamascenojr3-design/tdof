// ─────────────────────────────────────────────────────────────────────────────
// JOURNAL de mercado — gravação e replay de sessões (bun:sqlite).
//
// O engine entrega eventos via sink (setCaptureSink): trades, velas (fechadas
// + em formação throttled), DOM, sessão, buckets de heatmap e frames MBO
// binários. Tudo é gravado em SQLite (WAL) com flush em lote; o replay
// reconstrói o estado (buildSnapshot) em qualquer ts e o index.ts transmite
// os eventos com playhead/velocidade/seek.
// ─────────────────────────────────────────────────────────────────────────────

import { Database } from 'bun:sqlite';
import { mkdirSync } from 'node:fs';
import { join } from 'node:path';
import {
  TF_MS,
  type Candle,
  type DomSnapshot,
  type HeatmapBucket,
  type JournalSessionMeta,
  type SessionStats,
  type SnapshotPayload,
  type Timeframe,
  type Trade,
  type CaptureEvent,
  type JKind,
} from './types';

const DATA_DIR = join(import.meta.dir, 'data');
const DB_PATH = join(DATA_DIR, 'journal.db');
/** nº máximo de sessões retidas (as mais novas) */
const RETAIN_SESSIONS = 6;
/** duração máxima de uma gravação (auto-stop) */
const MAX_SESSION_MS = 15 * 60_000;
/** flush do buffer: nº de eventos ou intervalo */
const FLUSH_N = 256;
const FLUSH_MS = 600;
/** limites de reconstrução (espelham o cliente) */
const SNAP_CANDLES = 800;
const SNAP_TAPE = 400;
const SNAP_HEAT = 420;

interface EvRow {
  seq: number;
  ts: number;
  k: JKind;
  tf: Timeframe | undefined;
  /** Buffer p/ 'mbo' (frame binário) ou string JSON */
  data: Buffer | string;
}

interface CurSession {
  id: number;
  symbol: string;
  tf: Timeframe;
  start: number;
  seq: number;
  buf: CaptureEvent[];
  lastFlush: number;
  stopTimer: ReturnType<typeof setTimeout>;
}

export class Journal {
  private db: Database;
  private cur: CurSession | null = null;
  private insEvent!: ReturnType<Database['prepare']>;
  private touchTimer: ReturnType<typeof setInterval> | null = null;

  constructor() {
    mkdirSync(DATA_DIR, { recursive: true });
    this.db = new Database(DB_PATH, { create: true });
    this.db.exec('PRAGMA journal_mode = WAL;');
    this.db.exec('PRAGMA synchronous = NORMAL;');
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        symbol TEXT NOT NULL,
        tf TEXT NOT NULL,
        start INTEGER NOT NULL,
        end INTEGER,
        events INTEGER NOT NULL DEFAULT 0
      );
      CREATE TABLE IF NOT EXISTS events (
        sid INTEGER NOT NULL,
        seq INTEGER NOT NULL,
        ts INTEGER NOT NULL,
        k TEXT NOT NULL,
        tf TEXT,
        data BLOB NOT NULL,
        PRIMARY KEY (sid, seq)
      );
    `);
    this.insEvent = this.db.prepare(
      'INSERT INTO events (sid, seq, ts, k, tf, data) VALUES (?, ?, ?, ?, ?, ?)',
    );
    // sessões órfãs (restart no meio da gravação): encerra com o último ts
    this.db.exec(
      `UPDATE sessions SET end = COALESCE(
         (SELECT MAX(ts) FROM events WHERE events.sid = sessions.id), start)
       WHERE end IS NULL`,
    );
    // flush periódico de segurança (buffer parcial)
    this.touchTimer = setInterval(() => {
      if (this.cur && Date.now() - this.cur.lastFlush >= FLUSH_MS) this.flush();
    }, 300);
  }

  get recording(): boolean {
    return this.cur !== null;
  }

  get currentId(): number | null {
    return this.cur?.id ?? null;
  }

  /** Inicia uma sessão: grava o snapshot completo (base) como primeiro evento. */
  start(symbol: string, tf: Timeframe, base: SnapshotPayload): number {
    this.stop();
    // retenção: mantém as N sessões mais novas (eventos juntos)
    const old = this.db
      .query('SELECT id FROM sessions ORDER BY id DESC LIMIT -1 OFFSET ?')
      .all(RETAIN_SESSIONS - 1) as { id: number }[];
    for (const r of old) this.delete(r.id);

    const start = Date.now();
    const info = this.db
      .prepare('INSERT INTO sessions (symbol, tf, start) VALUES (?, ?, ?)')
      .run(symbol, tf, start);
    const id = Number(info.lastInsertRowid);
    const stopTimer = setTimeout(() => this.stop(), MAX_SESSION_MS);
    this.cur = { id, symbol, tf, start, seq: 0, buf: [], lastFlush: Date.now(), stopTimer };
    this.capture({ sym: symbol, k: 'base', tf, t: start, d: base });
    this.flush();
    console.log(`[journal] REC #${id} ${symbol} ${tf}`);
    return id;
  }

  stop(): void {
    const cur = this.cur;
    if (!cur) return;
    this.cur = null;
    clearTimeout(cur.stopTimer);
    this.flush();
    this.db
      .prepare('UPDATE sessions SET end = ?, events = ? WHERE id = ?')
      .run(Date.now(), cur.seq, cur.id);
    console.log(`[journal] STOP #${cur.id} (${cur.seq} eventos)`);
  }

  /** Sink do engine: enfileira e descarrega em lote. */
  capture(ev: CaptureEvent): void {
    const cur = this.cur;
    if (!cur || ev.sym !== cur.symbol) return;
    cur.buf.push(ev);
    if (cur.buf.length >= FLUSH_N) this.flush();
  }

  private flush(): void {
    const cur = this.cur;
    if (!cur || cur.buf.length === 0) return;
    const rows = cur.buf;
    cur.buf = [];
    cur.lastFlush = Date.now();
    const tx = this.db.transaction(() => {
      for (const ev of rows) {
        cur.seq += 1;
        const isBlob = ev.k === 'mbo' && ev.d instanceof ArrayBuffer;
        const data = isBlob ? Buffer.from(ev.d as ArrayBuffer) : JSON.stringify(ev.d);
        this.insEvent.run(cur.id, cur.seq, Math.round(ev.t), ev.k, ev.tf ?? null, data);
      }
      // mantém o contador visível na listagem durante a gravação
      this.db.prepare('UPDATE sessions SET events = ? WHERE id = ?').run(cur.seq, cur.id);
    });
    tx();
  }

  list(): JournalSessionMeta[] {
    const rows = this.db
      .query(
        `SELECT s.id, s.symbol, s.tf, s.start, s.end, s.events
         FROM sessions s ORDER BY s.id DESC`,
      )
      .all() as { id: number; symbol: string; tf: string; start: number; end: number | null; events: number }[];
    return rows.map((r) => ({
      id: r.id,
      symbol: r.symbol,
      tf: r.tf as Timeframe,
      start: r.start,
      end: r.end ?? r.start,
      events: r.events,
    }));
  }

  delete(id: number): void {
    if (this.cur?.id === id) this.stop();
    this.db.prepare('DELETE FROM events WHERE sid = ?').run(id);
    this.db.prepare('DELETE FROM sessions WHERE id = ?').run(id);
  }

  /** Carrega TODOS os eventos da sessão (p/ o pacer de replay). */
  allEvents(id: number): EvRow[] {
    const rows = this.db
      .query('SELECT seq, ts, k, tf, data FROM events WHERE sid = ? ORDER BY seq')
      .all(id) as { seq: number; ts: number; k: string; tf: string | null; data: Buffer | string }[];
    return rows.map((r) => ({
      seq: r.seq,
      ts: r.ts,
      k: r.k as JKind,
      tf: (r.tf as Timeframe | null) ?? undefined,
      data: r.data,
    }));  }

  /**
   * Reconstrói o estado do mercado em `upTo` (ms) aplicando os eventos em
   * ordem — usado no load e no seek do replay. Frames MBO são ignorados.
   */
  buildSnapshot(id: number, tf: Timeframe, upTo: number): SnapshotPayload | null {
    const meta = this.db
      .query('SELECT symbol, tf FROM sessions WHERE id = ?')
      .get(id) as { symbol: string; tf: string } | null;
    if (!meta) return null;

    // sementes a partir do snapshot base (gravado no início da sessão)
    let candles: Candle[] = [];
    let tape: Trade[] = [];
    let dom: DomSnapshot | null = null;
    let session: SessionStats | null = null;
    const heat = new Map<number, HeatmapBucket>();

    const baseRow = this.db
      .query("SELECT data FROM events WHERE sid = ? AND k = 'base' LIMIT 1")
      .get(id) as { data: Buffer | string } | null;
    if (baseRow) {
      try {
        const base = JSON.parse(String(baseRow.data)) as SnapshotPayload;
        if (base.tf === tf) {
          candles = base.candles.slice();
          tape = base.tape.slice();
          dom = base.dom;
          session = base.session;
          for (const b of base.heatmap) heat.set(b.t, b);
        }
      } catch {
        // base corrompido: reconstrói só com os eventos
      }
    }

    const rows = this.db
      .query(
        "SELECT ts, k, tf, data FROM events WHERE sid = ? AND k != 'mbo' AND ts <= ? ORDER BY seq",
      )
      .all(id, upTo) as { ts: number; k: string; tf: string | null; data: Buffer | string }[];

    for (const r of rows) {
      const k = r.k as JKind;
      if (k === 'base' || k === 'mbo') continue;
      try {
        if (k === 'trade') {
          const tr = JSON.parse(String(r.data)) as Trade;
          tape.push(tr);
          if (tape.length > SNAP_TAPE + 50) tape = tape.slice(-SNAP_TAPE);
        } else if (k === 'candle') {
          const msg = JSON.parse(String(r.data)) as { tf: Timeframe; candle: Candle };
          if (msg.tf !== tf) continue;
          const c = msg.candle;
          const last = candles[candles.length - 1];
          if (last && last.t === c.t) candles[candles.length - 1] = c;
          else if (!last || c.t > last.t) {
            candles.push(c);
            if (candles.length > SNAP_CANDLES) candles = candles.slice(-SNAP_CANDLES);
          }
        } else if (k === 'dom') {
          dom = JSON.parse(String(r.data)) as DomSnapshot;
        } else if (k === 'session') {
          session = JSON.parse(String(r.data)) as SessionStats;
        } else if (k === 'heat') {
          const msg = JSON.parse(String(r.data)) as { tf: Timeframe; bucket: HeatmapBucket };
          if (msg.tf !== tf) continue;
          heat.set(msg.bucket.t, msg.bucket);
          if (heat.size > SNAP_HEAT) {
            const oldest = heat.keys().next().value;
            if (oldest !== undefined) heat.delete(oldest);
          }
        }
      } catch {
        // linha corrompida: ignora
      }
    }

    return {
      symbol: meta.symbol,
      tf,
      serverTime: upTo,
      candles,
      dom: dom ?? { bids: [], asks: [], vol: {}, delta: {} },
      tape: tape.slice(-200),
      session: session ?? {
        symbol: meta.symbol,
        open: 0, high: 0, low: 0, last: 0,
        volume: 0, delta: 0, trades: 0, vwap: 0, poc: 0,
      },
      heatmap: Array.from(heat.values()).sort((a, b) => a.t - b.t),
    };
  }

  dispose(): void {
    if (this.touchTimer) clearInterval(this.touchTimer);
    this.stop();
    this.db.close();
  }
}
