// ─────────────────────────────────────────────────────────────────────────────
// Pré-geração de histórico por símbolo (rápida, <1s):
// - ~600 velas por timeframe (5s/15s/1m/5m), random walk com incrementos AR(1)
//   (volatilidade por símbolo coerente com o motor ao vivo), ranges com wicks,
//   volume/delta/n por barra e clusters `lv` em forma de sino ao redor de um
//   POC aleatório, com viés de delta conforme a direção da vela.
// - A última vela de cada tf é a "em formação", alinhada ao bucket atual.
// - Semeia também: tape inicial (200 trades), mapas de sessão (vol/delta) e
//   estatísticas de sessão coerentes com o histórico.
// ─────────────────────────────────────────────────────────────────────────────

import {
  TF_MS, TIMEFRAMES,
  type Aggressor, type Candle, type CandleLevel, type Timeframe, type Trade,
} from './types';
import type { SymbolCfg } from './config';
import { clamp, gauss, poisson, priceOf, roundSize, U } from './util';

const PREGEN_BARS = 600;
const SESSION_BARS = 150; // últimas barras de 1m usadas para semear a sessão
/** janela máxima (± ticks) de níveis por vela — limita payload/memória em tfs longos */
const LV_HALF = 120;

export interface PregenResult {
  candles: Record<Timeframe, Candle[]>;
  tape: Trade[];
  nextTradeId: number;
  sessionVol: Record<number, number>;
  sessionDelta: Record<number, number>;
  sessionSeed: {
    open: number;
    high: number;
    low: number;
    last: number;
    volume: number;
    delta: number;
    trades: number;
    vwapNum: number;
    pocIdx: number;
  };
}

export function pregenSymbol(cfg: SymbolCfg, now: number): PregenResult {
  const sd = cfg.sizeDecimals;
  const startIdx = Math.round(cfg.startPrice / cfg.tick);
  const abs = (x: number) => priceOf(cfg, startIdx + x);
  const phase = Math.random() * 100;
  const activity = (i: number) =>
    clamp(
      1 + 0.45 * Math.sin(i / 37 + phase) + 0.3 * Math.sin(i / 9.7 + phase * 2.1) + 0.2 * Math.sin(i / 151 + phase * 0.7),
      0.3,
      2.4,
    );

  const candles = {} as Record<Timeframe, Candle[]>;
  const sessionVol: Record<number, number> = {};
  const sessionDelta: Record<number, number> = {};
  let sessVolume = 0, sessDelta = 0, sessTrades = 0, sessVwapNum = 0;
  let sessHigh = -Infinity, sessLow = Infinity;
  let sessOpen: number | null = null;

  for (const tf of TIMEFRAMES) {
    const tfMs = TF_MS[tf];
    const tfSec = tfMs / 1000;
    const sigma = cfg.volPerMinTicks * Math.sqrt(tfMs / 60000); // σ do fechamento por barra
    const N = PREGEN_BARS;
    const bucket0 = Math.floor(now / tfMs) * tfMs;

    // caminho de fechamentos (incrementos AR(1) → tendências plausíveis), termina em startIdx
    const closes: number[] = new Array(N);
    let inc = 0, p = 0;
    for (let i = 0; i < N; i++) {
      inc = 0.82 * inc + gauss() * 0.57 * sigma;
      p += Math.round(inc);
      closes[i] = p;
    }
    const shift = -closes[N - 1]!; // último fechamento relativo = 0

    const arr: Candle[] = new Array(N);
    let prev = closes[0]! + shift - Math.round(gauss() * sigma * 0.5);

    for (let i = 0; i < N; i++) {
      const isLast = i === N - 1;
      const c = closes[i]! + shift;
      const o = prev;
      const el = isLast ? clamp((now - bucket0) / tfMs, 0.02, 1) : 1; // fração elapsed do bucket atual
      let up = Math.abs(gauss()) * sigma * U(0.35, 1.15);
      let dn = Math.abs(gauss()) * sigma * U(0.35, 1.15);
      if (isLast) {
        up *= el;
        dn *= el;
      } else if (Math.random() < 0.03) {
        const m = U(1.8, 3); // barras com spike/expandimento ocasional
        up *= m;
        dn *= m;
      }
      const h = Math.max(o, c) + Math.round(up);
      const l = Math.min(o, c) - Math.round(dn);

      const n = Math.max(isLast ? 0 : 1, poisson(cfg.baseRate * tfSec * activity(i) * U(0.65, 1.45) * el));
      const v = roundSize(n * cfg.avgSize * Math.exp(gauss() * 0.3), sd);
      const dir: 1 | -1 = c > o ? 1 : c < o ? -1 : Math.random() < 0.5 ? 1 : -1;
      const skew = dir > 0 ? U(0.55, 0.82) : U(0.18, 0.45);
      const d = roundSize(v * (2 * skew - 1) * U(0.55, 1), sd);
      const lv = genLevels(cfg, startIdx + l, startIdx + h, v, d, dir);
      const t = isLast ? bucket0 : bucket0 - (N - i) * tfMs;
      arr[i] = { t, o: abs(o), h: abs(h), l: abs(l), c: abs(c), v, d, n, lv };
      prev = c;

      // semeia a sessão com as últimas barras de 1m
      if (tf === '1m' && i >= N - SESSION_BARS) {
        if (sessOpen === null) sessOpen = abs(o);
        sessHigh = Math.max(sessHigh, abs(h));
        sessLow = Math.min(sessLow, abs(l));
        sessVolume = roundSize(sessVolume + v, sd);
        sessDelta = roundSize(sessDelta + d, sd);
        sessTrades += n;
        for (const key of Object.keys(lv)) {
          const k = Number(key);
          const cl = lv[k]!;
          const vol = cl.a + cl.b;
          sessionVol[k] = roundSize((sessionVol[k] ?? 0) + vol, sd);
          sessionDelta[k] = roundSize((sessionDelta[k] ?? 0) + (cl.a - cl.b), sd);
          sessVwapNum += priceOf(cfg, k) * vol;
        }
      }
    }
    candles[tf] = arr;
  }

  // ── tape inicial: 200 trades amostrados dos níveis das últimas barras de 5s ──
  const pool: { k: number; w: number; share: number; tMax: number }[] = [];
  let poolW = 0;
  for (const bar of candles['5s']!.slice(-14)) {
    for (const key of Object.keys(bar.lv)) {
      const k = Number(key);
      const cl = bar.lv[k]!;
      const w = cl.a + cl.b;
      if (w <= 0) continue;
      pool.push({ k, w, share: cl.a / w, tMax: Math.min(bar.t + TF_MS['5s'], now) });
      poolW += w;
    }
  }
  const tape: Trade[] = [];
  const T = Math.min(200, pool.length * 3);
  for (let i = 0; i < T; i++) {
    let r = Math.random() * poolW;
    let pick = pool[pool.length - 1]!;
    for (const e of pool) {
      r -= e.w;
      if (r <= 0) {
        pick = e;
        break;
      }
    }
    const side: Aggressor = Math.random() < pick.share ? 'buy' : 'sell';
    let s: number;
    if (Math.random() < 0.004) s = Math.max(cfg.bigThreshold * U(1, 2.5), cfg.avgSize * U(4, 12));
    else s = Math.exp(gauss() * 0.85) * cfg.avgSize;
    s = roundSize(clamp(s, cfg.minSize, cfg.maxSize * 2), sd);
    const t = Math.max(0, Math.min(now, Math.round(pick.tMax - U(0, 4800))));
    const tr: Trade = { id: 0, t, p: priceOf(cfg, pick.k), s, side };
    if (s >= cfg.bigThreshold) tr.big = true;
    tape.push(tr);
  }
  tape.sort((a, b) => a.t - b.t);
  for (let i = 0; i < tape.length; i++) tape[i]!.id = i + 1;

  // ── POC da sessão semeada ──
  let pocIdx = startIdx, best = -1;
  for (const key of Object.keys(sessionVol)) {
    const k = Number(key);
    if (sessionVol[k]! > best) {
      best = sessionVol[k]!;
      pocIdx = k;
    }
  }

  const last = priceOf(cfg, startIdx);
  return {
    candles,
    tape,
    nextTradeId: tape.length + 1,
    sessionVol,
    sessionDelta,
    sessionSeed: {
      open: sessOpen ?? last,
      high: sessHigh === -Infinity ? last : sessHigh,
      low: sessLow === Infinity ? last : sessLow,
      last,
      volume: sessVolume,
      delta: sessDelta,
      trades: sessTrades,
      vwapNum: sessVwapNum,
      pocIdx,
    },
  };
}

/**
 * Clusters de uma vela: volume distribuído em sino ao redor de um POC aleatório,
 * com share agressor (a/b) enviesado pela direção: vela de alta → asks dominam
 * nos fundos e bids aparecem no topo (e o inverso para vela de baixa).
 */
function genLevels(cfg: SymbolCfg, l: number, h: number, v: number, d: number, dir: 1 | -1): Record<number, CandleLevel> {
  const sd = cfg.sizeDecimals;
  const lv: Record<number, CandleLevel> = {};
  if (v <= 0) return lv;
  const span = h - l;
  const poc = clamp(l + Math.round(U(0.3, 0.7) * span) + Math.round(dir * U(0, 0.12) * span), l, h);
  const sig = Math.max(1, Math.min(span / 3, 45));
  const k0 = Math.max(l, poc - LV_HALF);
  const k1 = Math.min(h, poc + LV_HALF);
  const ks: number[] = [];
  const ws: number[] = [];
  let W = 0;
  for (let k = k0; k <= k1; k++) {
    const w = Math.exp(-((k - poc) * (k - poc)) / (2 * sig * sig)) + 0.03;
    ks.push(k);
    ws.push(w);
    W += w;
  }
  const base = 0.5 + dir * U(0.12, 0.26);
  let sumA = 0;
  for (let i = 0; i < ks.length; i++) {
    const k = ks[i]!;
    const pos = span > 0 ? (k - (l + h) / 2) / (span / 2) : 0; // −1 (fundo) .. 1 (topo)
    const share = clamp(base - dir * pos * U(0.08, 0.2) + U(-0.07, 0.07), 0.06, 0.94);
    const vk = roundSize((v * ws[i]!) / W, sd);
    const ak = roundSize(vk * share, sd);
    lv[k] = { b: roundSize(vk - ak, sd), a: ak };
    sumA += ak;
  }
  // reconcilia o delta dos clusters com o delta da vela (ajusta o nível do POC)
  const targetA = roundSize((v + d) / 2, sd);
  const diff = roundSize(targetA - sumA, sd);
  if (diff !== 0) {
    const cl = lv[poc];
    if (cl && cl.a + diff >= 0 && cl.b - diff >= 0) {
      cl.a += diff;
      cl.b -= diff;
    }
  }
  return lv;
}
