// ─────────────────────────────────────────────────────────────────────────────
// Réplica do contrato compartilhado (fonte de verdade: src/lib/market/types.ts).
// Alterações no contrato devem ser replicadas aqui.
// ─────────────────────────────────────────────────────────────────────────────

export type Aggressor = 'buy' | 'sell';

/** Um negócio (trade) impresso no tape. */
export interface Trade {
  id: number;
  /** timestamp em ms */
  t: number;
  /** preço do negócio */
  p: number;
  /** quantidade negociada */
  s: number;
  /** agressor: 'buy' compra pelo ask, 'sell' vende pelo bid */
  side: Aggressor;
  /** trade grande (marcado pelo servidor por símbolo) */
  big?: boolean;
}

/** Volumes por nível de preço dentro de uma vela (cluster). */
export interface CandleLevel {
  /** volume agressor de venda (executado no bid) */
  b: number;
  /** volume agressor de compra (executado no ask) */
  a: number;
}

/** Vela com clusters por nível (chave = índice do tick: Math.round(price / tick)). */
export interface Candle {
  /** abertura da vela em ms (alinhado ao bucket do timeframe) */
  t: number;
  o: number;
  h: number;
  l: number;
  c: number;
  /** volume total */
  v: number;
  /** delta (ask volume − bid volume) */
  d: number;
  /** número de negócios */
  n: number;
  /** mapa nível→volumes; chave = tick index */
  lv: Record<number, CandleLevel>;
}

export interface DomLevel {
  /** preço do nível */
  p: number;
  /** quantidade ofertada */
  s: number;
}

export interface DomSnapshot {
  /** lados ordenados do maior para o menor preço (12 níveis por lado) */
  bids: DomLevel[];
  asks: DomLevel[];
  /** volume negociado na sessão por tick index (coluna Volume do DOM) */
  vol: Record<number, number>;
  /** delta da sessão por tick index (coluna Delta do DOM) */
  delta: Record<number, number>;
}

export interface SessionStats {
  symbol: string;
  open: number;
  high: number;
  low: number;
  last: number;
  volume: number;
  delta: number;
  trades: number;
  vwap: number;
  /** preço do POC da sessão */
  poc: number;
}

/**
 * Bucket do heatmap de liquidez: book RESTANTE (limit orders) agregado por
 * timeframe. Para cada tick index guarda o MÁXIMO de quantidade visto no
 * bucket separado por lado [bid, ask] — paredes ficam visíveis mesmo com
 * oscilação momentânea do book.
 */
export interface HeatmapBucket {
  /** abertura do bucket em ms (alinhado ao bucket do timeframe) */
  t: number;
  /** tick index → [bid, ask] */
  lv: Record<number, [number, number]>;
}

export interface SnapshotPayload {
  symbol: string;
  tf: Timeframe;
  serverTime: number;
  candles: Candle[];
  dom: DomSnapshot;
  tape: Trade[];
  session: SessionStats;
  /** histórico recente de liquidez do book (buckets alinhados ao tf) */
  heatmap: HeatmapBucket[];
}

export const TIMEFRAMES = ['5s', '15s', '1m', '5m'] as const;
export type Timeframe = (typeof TIMEFRAMES)[number];

export const TF_MS: Record<Timeframe, number> = {
  '5s': 5_000,
  '15s': 15_000,
  '1m': 60_000,
  '5m': 300_000,
};

// ── Eventos socket.io ────────────────────────────────────────────────────────
export const EV_SUBSCRIBE = 'terminal:subscribe';
export const EV_UNSUBSCRIBE = 'terminal:unsubscribe';
export const EV_SNAPSHOT = 'terminal:snapshot';
export const EV_TRADE = 'terminal:trade';
export const EV_CANDLE = 'terminal:candle';
export const EV_DOM = 'terminal:dom';
export const EV_SESSION = 'terminal:session';
export const EV_HEATMAP = 'terminal:heatmap';
/** delta binário do order book (FlatBuffers-style, payload = ArrayBuffer) */
export const EV_MBO = 'terminal:mbo';

// ── Eventos do journal (replay de sessões gravadas) ─────────────────────────
export const EV_J_LOAD = 'journal:load';
export const EV_J_PLAY = 'journal:play';
export const EV_J_SPEED = 'journal:speed';
export const EV_J_SEEK = 'journal:seek';
export const EV_J_STOP = 'journal:stop';
export const EV_J_SNAPSHOT = 'journal:snapshot';
export const EV_J_EVENT = 'journal:event';
export const EV_J_STATUS = 'journal:status';

/** Sessão gravada no journal (listagem REST). */
export interface JournalSessionMeta {
  id: number;
  symbol: string;
  tf: Timeframe;
  start: number;
  end: number;
  events: number;
}

/** kinds de evento capturados no journal. `base` = snapshot completo no início. */
export type JKind = 'base' | 'trade' | 'candle' | 'dom' | 'session' | 'heat' | 'mbo';

/** Evento capturado pelo engine p/ o journal (sink). */
export interface CaptureEvent {
  sym: string;
  k: JKind;
  /** tf quando aplicável (candle/heat) */
  tf?: Timeframe;
  /** ms do evento (tempo do mercado) */
  t: number;
  /** payload: Trade / {tf, candle} / DomSnapshot / SessionStats / {tf, bucket} / ArrayBuffer(base=mbo) */
  d: unknown;
}

export interface SubscribeMsg {
  symbol: string;
  tf: Timeframe;
}

export interface CandleMsg {
  tf: Timeframe;
  candle: Candle;
}

export interface HeatmapMsg {
  tf: Timeframe;
  bucket: HeatmapBucket;
}
