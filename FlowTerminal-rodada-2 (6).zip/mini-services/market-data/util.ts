import type { SymbolCfg } from './config';

/** Uniforme em [a, b). */
export function U(a: number, b: number): number {
  return a + Math.random() * (b - a);
}

let spare: number | null = null;

/** Gaussiana padrão (Box-Muller polar, com reciclagem do 2º valor). */
export function gauss(): number {
  if (spare !== null) {
    const s = spare;
    spare = null;
    return s;
  }
  let u = 0, v = 0, sq = 0;
  do {
    u = Math.random() * 2 - 1;
    v = Math.random() * 2 - 1;
    sq = u * u + v * v;
  } while (sq === 0 || sq >= 1);
  const m = Math.sqrt((-2 * Math.log(sq)) / sq);
  spare = v * m;
  return u * m;
}

/** Poisson (Knuth; aproximação normal para λ grande). */
export function poisson(lambda: number): number {
  if (lambda <= 0) return 0;
  if (lambda > 30) return Math.max(0, Math.round(lambda + Math.sqrt(lambda) * gauss()));
  const L = Math.exp(-lambda);
  let k = 0, p = 1;
  do {
    k++;
    p *= Math.random();
  } while (p > L);
  return k - 1;
}

export function clamp(x: number, a: number, b: number): number {
  return x < a ? a : x > b ? b : x;
}

/** Arredonda quantidade para as casas decimais do símbolo (evita lixo de float). */
export function roundSize(v: number, sd: number): number {
  if (sd === 0) return Math.round(v);
  const m = Math.pow(10, sd);
  return Math.round(v * m) / m;
}

/** Preço absoluto a partir do tick index (arredondado às casas do símbolo). */
export function priceOf(cfg: SymbolCfg, idx: number): number {
  return +(idx * cfg.tick).toFixed(cfg.priceDecimals);
}
