/**
 * build-wasm.ts — Compila o kernel MBO do FlowTerminal (WAT → WASM).
 *
 * Uso: bun run scripts/build-wasm.ts
 *
 * Lê tools/mbo-kernel.wat, compila com o pacote `wabt` (wabt.js) e escreve o
 * artefato em public/wasm/mbo-kernel.wasm (servido estaticamente pelo Next.js;
 * o mbo-worker o busca em /wasm/mbo-kernel.wasm e faz WebAssembly.instantiate).
 */
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import path from "node:path";

// Tipos mínimos da API do wabt.js (o pacote não embarca typings).
interface WabtCompiledModule {
  resolveNames(): void;
  validate(): void;
  toBinary(options: Record<string, unknown>): { buffer: ArrayBuffer };
  destroy?(): void;
}
interface WabtInstance {
  parseWat(filename: string, source: string): WabtCompiledModule;
}

const RAIZ = path.resolve(import.meta.dir, "..");
const watPath = path.join(RAIZ, "tools", "mbo-kernel.wat");
const outDir = path.join(RAIZ, "public", "wasm");
const outPath = path.join(outDir, "mbo-kernel.wasm");

const fonte = readFileSync(watPath, "utf8");

// O pacote wabt exporta a fábrica emscripten: WabtModule() → Promise<módulo>.
const importado = await import("wabt");
const wabtInit = (importado.default ?? importado) as unknown as () => Promise<WabtInstance>;
const wabt = await wabtInit();

// Pipeline exigido: parseWat → resolveNames → validate → toBinary.
const mod = wabt.parseWat("mbo-kernel.wat", fonte);
mod.resolveNames();
mod.validate();
const { buffer } = mod.toBinary({});
mod.destroy?.();

mkdirSync(outDir, { recursive: true });
writeFileSync(outPath, Buffer.from(buffer));

console.log(`[build-wasm] OK: ${path.relative(RAIZ, outPath)} — ${buffer.byteLength} bytes`);
