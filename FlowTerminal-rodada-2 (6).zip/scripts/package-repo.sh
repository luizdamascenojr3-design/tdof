#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# Empacota o repositório FlowTerminal em public/downloads/FlowTerminal-rodada-N.zip
#
# Uso:  bash scripts/package-repo.sh [N]
#   N = número da rodada (default: 2)
#
# O zip fica servido pelo próprio app Next (pasta public/) e é baixável em:
#   /downloads/FlowTerminal-rodada-N.zip
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

ROUND="${1:-2}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="${ROOT}/public/downloads"
NAME="FlowTerminal-rodada-${ROUND}.zip"
OUT="${OUT_DIR}/${NAME}"

mkdir -p "$OUT_DIR"
rm -f "$OUT"

cd "$ROOT"

# Exclusões: dependências, build, artefatos locais e pastas do scaffold que
# não pertencem ao projeto (node_modules wildcard pega o aninhado do mini-serviço).
zip -r -q "$OUT" . \
  -x "*node_modules/*" \
  -x "*.next/*" \
  -x ".git/*" \
  -x "public/downloads/*" \
  -x "tool-results/*" \
  -x "download/*" \
  -x "upload/*" \
  -x "skills/*" \
  -x "tests/*" \
  -x ".zscripts/*" \
  -x "db/*.db" \
  -x "db/*.db-journal" \
  -x "dev.log" \
  -x "server.log" \
  -x "*.log" \
  -x "worklog.md" \
  -x "tsconfig.tsbuildinfo"

# Manifest consumido pela UI (tamanho, rodada e data de build).
SIZE=$(du -h "$OUT" | cut -f1)
FILES=$(unzip -l "$OUT" | tail -1 | awk '{print $2}')
printf '{"file":"%s","round":%s,"size":"%s","files":%s,"builtAt":"%s"}\n' \
  "$NAME" "$ROUND" "$SIZE" "$FILES" "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  > "${OUT_DIR}/latest.json"

echo "✓ ${NAME} (${SIZE}, ${FILES} arquivos)"
echo "  manifest: public/downloads/latest.json"
