// ─────────────────────────────────────────────────────────────────────────────
// Proxy REST p/ o journal do mini-serviço market-data (porta 3003).
// O gateway XTransformPort não está disponível em todos os previews; este
// route handler garante que o REST do journal (sessões + REC) funcione sempre.
// ─────────────────────────────────────────────────────────────────────────────

import { type NextRequest, NextResponse } from 'next/server';

const SVC = 'http://localhost:3003/journal';

type Ctx = { params: Promise<{ path?: string[] }> };

async function proxy(
  req: NextRequest,
  method: 'GET' | 'POST' | 'DELETE',
  ctx: Ctx,
): Promise<NextResponse> {
  const { path } = await ctx.params;
  const suffix = path?.length ? `/${path.join('/')}` : '';
  const search = req.nextUrl.search ?? '';
  try {
    const res = await fetch(`${SVC}${suffix}${search}`, {
      method,
      headers: { 'content-type': 'application/json' },
      body: method === 'POST' ? await req.text() : undefined,
      cache: 'no-store',
    });
    const body = await res.text();
    return new NextResponse(body, {
      status: res.status,
      headers: { 'content-type': 'application/json; charset=utf-8' },
    });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: `journal svc indisponível: ${String(err)}` },
      { status: 502 },
    );
  }
}

export async function GET(req: NextRequest, ctx: Ctx) {
  return proxy(req, 'GET', ctx);
}
export async function POST(req: NextRequest, ctx: Ctx) {
  return proxy(req, 'POST', ctx);
}
export async function DELETE(req: NextRequest, ctx: Ctx) {
  return proxy(req, 'DELETE', ctx);
}
