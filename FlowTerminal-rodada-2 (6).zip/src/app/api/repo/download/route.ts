import { execFileSync } from 'child_process';
import { existsSync } from 'fs';
import { readFile } from 'fs/promises';
import path from 'path';
import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

/**
 * GET /api/repo/download?round=N
 *
 * Entrega o zip do repositório (Content-Disposition: attachment) servindo o
 * bytes diretamente — sem redirect, para funcionar atrás de gateways/preview.
 *
 * Ordem de resolução:
 *  1. zip estático em public/downloads/FlowTerminal-rodada-N.zip (gerado por
 *     `bash scripts/package-repo.sh N`);
 *  2. geração on-demand via scripts/package-repo.sh (mesmas exclusões);
 *  3. erro orientado (instruções de empacotamento manual).
 */
export async function GET(request: Request) {
  const url = new URL(request.url);
  const raw = Number(url.searchParams.get('round') ?? 2);
  const round = Number.isFinite(raw) ? Math.max(1, Math.min(99, Math.floor(raw))) : 2;

  const root = process.cwd();
  const outDir = path.join(root, 'public', 'downloads');
  const name = `FlowTerminal-rodada-${round}.zip`;
  const file = path.join(outDir, name);

  if (!existsSync(file)) {
    try {
      execFileSync('bash', [path.join(root, 'scripts', 'package-repo.sh'), String(round)], {
        cwd: root,
        stdio: 'pipe',
        timeout: 120_000,
      });
    } catch {
      return NextResponse.json(
        {
          error:
            'Não foi possível gerar o zip automaticamente (comando `zip`/`bash` indisponível). Rode manualmente: bash scripts/package-repo.sh ' +
            round,
        },
        { status: 500 },
      );
    }
  }

  if (!existsSync(file)) {
    return NextResponse.json(
      { error: `Zip não encontrado: ${name}. Rode bash scripts/package-repo.sh ${round}.` },
      { status: 404 },
    );
  }

  try {
    const buf = await readFile(file);
    return new NextResponse(new Uint8Array(buf), {
      headers: {
        'Content-Type': 'application/zip',
        'Content-Disposition': `attachment; filename="${name}"`,
        'Content-Length': String(buf.length),
        'Cache-Control': 'no-store',
      },
    });
  } catch {
    return NextResponse.json({ error: 'Falha ao ler o arquivo do zip.' }, { status: 500 });
  }
}
