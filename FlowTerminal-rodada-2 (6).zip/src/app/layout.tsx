import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import "../dockview.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "FlowTerminal · Order Flow Suite",
  description:
    "Terminal de trading com cluster charts (footprint), volume profile, delta acumulado, DOM e tape — fluxo de ordens em tempo real.",
  keywords: ["order flow", "cluster chart", "footprint", "volume profile", "DOM", "tape reading", "trading"],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="pt-BR"
      suppressHydrationWarning
      className={`${geistSans.variable} ${geistMono.variable}`}
    >
      <body className="antialiased overflow-hidden bg-[#151515] text-foreground">
        {children}
        <Toaster />
      </body>
    </html>
  );
}
