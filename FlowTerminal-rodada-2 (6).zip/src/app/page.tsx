import { TerminalShell } from '@/components/terminal/terminal-shell';

export default function Page() {
  return <TerminalShell />;
}
