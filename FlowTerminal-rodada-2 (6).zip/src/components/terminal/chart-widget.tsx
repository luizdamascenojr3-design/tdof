'use client';

import { memo, useCallback, useRef, useState } from 'react';
import {
  ArrowLeftRight,
  Camera,
  CandlestickChart,
  ChevronDown,
  Flame,
  Grid2x2,
  GripVertical,
  History,
  Link2,
  LineChart,
  Maximize2,
  Minimize2,
  MousePointer2,
  Settings2,
  Unlink2,
  X,
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { useTerminalStore } from '@/store/terminal';
import { TIMEFRAMES, symbolMeta, TF_MS, type Timeframe } from '@/lib/market/types';
import { fmtCompact, fmtPrice, fmtSignedCompact } from '@/lib/market/format';
import type { BarType } from '@/lib/market/bars';
import { ClusterChart } from './cluster-chart';
import { ReplayBar } from './replay-bar';

const TF_LABEL: Record<Timeframe, string> = { '5s': 'S5', '15s': 'S15', '1m': 'M1', '5m': 'M5' };

const MODE_LABEL: Record<string, string> = {
  clusters: 'Cluster',
  candles: 'Candles',
  line: 'Linha',
  heatmap: 'Heatmap',
};

const BAR_LABEL: Record<BarType, string> = {
  time: 'Velas (tempo)',
  range: 'Range',
  reversal: 'Reversão',
  tick: 'Tick',
  volume: 'Volume',
};

const BAR_UNIT: Record<Exclude<BarType, 'time'>, string> = {
  range: 'ticks',
  reversal: 'ticks',
  tick: 'negócios',
  volume: 'volume',
};

function barPill(type: BarType, param: number): string {
  if (type === 'time') return 'Velas';
  if (type === 'volume') return `Vol ${fmtCompact(param)}`;
  return `${BAR_LABEL[type]} ${param}`;
}

function HeadBtn({
  tip,
  onClick,
  children,
  className = '',
}: {
  tip: string;
  onClick?: () => void;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <TooltipProvider delayDuration={300}>
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            type="button"
            onClick={onClick}
            className={`flex h-7 items-center justify-center rounded px-1.5 text-[#787b86] transition-colors hover:bg-[#222226] hover:text-[#d1d4dc] ${className}`}
          >
            {children}
          </button>
        </TooltipTrigger>
        <TooltipContent side="bottom" className="text-[10px]">
          {tip}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

/** Tabela de estatísticas da vela sob o cursor (Delta / Delta% / Volume), estilo ATAS. */
function StatsTable({ idx }: { idx: number | null }) {
  const candles = useTerminalStore((s) => s.candles);
  if (idx === null || idx < 0 || idx >= candles.length) return null;
  const cols = [-1, 0, 1]
    .map((off) => candles[idx + off])
    .map((c) => c ?? null);
  if (!cols[0] && !cols[1] && !cols[2]) return null;

  const cellCls = (delta: number, volume: number) => {
    if (volume <= 0) return 'bg-[#222226] text-[#d1d4dc]';
    if (delta > 0) return 'bg-[#2962ff] text-white';
    if (delta < 0) return 'bg-[#3a1e24] text-[#f2385a]';
    return 'bg-[#222226] text-[#d1d4dc]';
  };

  return (
    <div className="pointer-events-none absolute bottom-2 left-2 z-10 select-none border border-[#27272a] bg-[#101012] text-[10px] font-num leading-none">
      <div className="flex">
        <div className="h-[18px] w-[76px] bg-[#c8cbd2] px-1.5 py-[5px] font-semibold text-[#1a1c20]">
          Delta
        </div>
        {cols.map((c, i) => (
          <div
            key={`d${i}`}
            className={`h-[18px] w-[62px] px-1 py-[5px] text-right ${
              i === 1 ? 'border-x border-[#4682b4]' : ''
            } ${c ? cellCls(c.d, c.v) : 'bg-[#101012]'}`}
          >
            {c ? fmtSignedCompact(c.d) : ''}
          </div>
        ))}
      </div>
      <div className="flex">
        <div className="h-[18px] w-[76px] bg-[#c8cbd2] px-1.5 py-[5px] font-semibold text-[#1a1c20]">
          Delta/Volume
        </div>
        {cols.map((c, i) => (
          <div
            key={`p${i}`}
            className={`h-[18px] w-[62px] px-1 py-[5px] text-right ${
              i === 1 ? 'border-x border-[#4682b4]' : ''
            } ${c ? cellCls(c.d, c.v) : 'bg-[#101012]'}`}
          >
            {c ? `${Math.round((c.d / Math.max(1, c.v)) * 100)}%` : ''}
          </div>
        ))}
      </div>
      <div className="flex">
        <div className="h-[18px] w-[76px] bg-[#c8cbd2] px-1.5 py-[5px] font-semibold text-[#1a1c20]">
          Volume
        </div>
        {cols.map((c, i) => (
          <div
            key={`v${i}`}
            className={`h-[18px] w-[62px] px-1 py-[5px] text-right text-[#d1d4dc] ${
              i === 1 ? 'border-x border-[#4682b4]' : ''
            } ${c ? 'bg-[#222226]' : 'bg-[#101012]'}`}
          >
            {c ? fmtCompact(c.v) : ''}
          </div>
        ))}
      </div>
    </div>
  );
}

/** Linha de estatísticas da sessão (rodapé do widget, estilo terminal). */
function StripItem({ label, value, cls = 'text-[#d1d4dc]' }: { label: string; value: string; cls?: string }) {
  return (
    <span className="flex items-baseline gap-1 whitespace-nowrap">
      <span className="text-[9px] uppercase tracking-wider text-[#787b86]">{label}</span>
      <span className={`text-[10px] font-num font-semibold tabular-nums ${cls}`}>{value}</span>
    </span>
  );
}

function SessionStrip() {
  const show = useTerminalStore((s) => s.showSessionStrip);
  const session = useTerminalStore((s) => s.session);
  const symbol = useTerminalStore((s) => s.symbol);
  if (!show) return null;
  const meta = symbolMeta(symbol);
  const up = session ? session.last >= session.open : true;
  return (
    <div className="flex h-7 shrink-0 items-center gap-3 overflow-x-auto border-t border-[#27272a] bg-[#101012] px-2 scrollbar-none">
      <StripItem label="abr" value={session ? fmtPrice(session.open, meta.tick) : '—'} />
      <StripItem label="máx" value={session ? fmtPrice(session.high, meta.tick) : '—'} cls="text-[#089981]" />
      <StripItem label="mín" value={session ? fmtPrice(session.low, meta.tick) : '—'} cls="text-[#f2385a]" />
      <StripItem
        label="últ"
        value={session ? fmtPrice(session.last, meta.tick) : '—'}
        cls={up ? 'text-[#089981]' : 'text-[#f2385a]'}
      />
      <span className="h-3.5 w-px shrink-0 bg-[#27272a]" />
      <StripItem label="vol" value={session ? fmtCompact(session.volume) : '—'} />
      <StripItem
        label="Δ sess"
        value={session ? fmtSignedCompact(session.delta) : '—'}
        cls={session && session.delta >= 0 ? 'text-[#2962ff]' : 'text-[#f2385a]'}
      />
      <StripItem label="vwap" value={session ? fmtPrice(session.vwap, meta.tick) : '—'} cls="text-[#e8a854]" />
      <StripItem label="poc" value={session ? fmtPrice(session.poc, meta.tick) : '—'} cls="text-[#7ba7c9]" />
      <StripItem label="neg" value={session ? fmtCompact(session.trades) : '—'} />
      <span className="ml-auto hidden shrink-0 whitespace-nowrap pl-2 text-[9px] uppercase tracking-wider text-[#5d606b] md:inline">
        fluxo simulado
      </span>
    </div>
  );
}

/** Widget de gráfico estilo ATAS: header + canvas + tabela de stats + sessão.
 *  `primary` = gráfico principal (strip de sessão + barras de replay só aqui).
 *  `pin` = multi-chart: tf/barType locais do painel (params do dockview) —
 *  tf ≥ stream é derivado localmente; sem pin, segue o store global. */
export const ChartWidget = memo(function ChartWidget({
  className = '',
  primary = true,
  pin,
}: {
  className?: string;
  primary?: boolean;
  pin?: { tf?: Timeframe; barType?: BarType; barParam?: number };
}) {
  const symbol = useTerminalStore((s) => s.symbol);
  const setSymbolOpen = useTerminalStore((s) => s.setDialog);
  const tf = useTerminalStore((s) => s.tf);
  const setTf = useTerminalStore((s) => s.setTf);
  const chartMode = useTerminalStore((s) => s.chartMode);
  const barType = useTerminalStore((s) => s.barType);
  const barParams = useTerminalStore((s) => s.barParams);
  const chartCount = useTerminalStore((s) => s.chartCount);
  const patch = useTerminalStore((s) => s.patchSettings);
  const replayActive = useTerminalStore((s) => s.replay.active);
  const enterReplay = useTerminalStore((s) => s.enterReplay);
  const exitReplay = useTerminalStore((s) => s.exitReplay);
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);
  const [fullscreen, setFullscreen] = useState(false);
  const sectionRef = useRef<HTMLElement | null>(null);
  const onHover = useCallback((idx: number | null) => setHoverIdx(idx), []);
  const meta = symbolMeta(symbol);

  // pin local do painel (multi-chart): inicializado dos params do dockview;
  // alterações de TF/tipo de barra afetam SÓ este painel quando pinado
  const [pinnedTf, setPinnedTf] = useState<Timeframe | undefined>(pin?.tf);
  const [pinnedBar, setPinnedBar] = useState<{ type: BarType; param: number } | null>(
    pin?.barType ? { type: pin.barType, param: pin.barParam ?? 50 } : null,
  );
  const isPinned = pinnedTf !== undefined || pinnedBar !== null;
  const effTf = pinnedTf ?? tf;
  const effBarType = pinnedBar?.type ?? barType;
  const effBarParam = pinnedBar?.param ?? barParams[barType];

  /** Anexa/desanexa o gráfico ao lado do principal (mesmo instrumento). */
  const toggleAttach = () => patch({ chartCount: chartCount === 2 ? 1 : 2 });

  /** Screenshot: compõe os canvas (2D + WebGL) e baixa o PNG. */
  const takeShot = () => {
    const sec = sectionRef.current;
    if (!sec) return;
    const canvases = Array.from(sec.querySelectorAll('canvas'));
    if (canvases.length === 0) return;
    const w = Math.max(...canvases.map((c) => c.width));
    const h = Math.max(...canvases.map((c) => c.height));
    const out = document.createElement('canvas');
    out.width = w;
    out.height = h;
    const g = out.getContext('2d');
    if (!g) return;
    g.fillStyle = '#18181b';
    g.fillRect(0, 0, w, h);
    for (const c of canvases) g.drawImage(c, 0, 0, c.width, c.height);
    const a = document.createElement('a');
    a.href = out.toDataURL('image/png');
    a.download = `${symbol}-${tf}-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')}.png`;
    a.click();
  };

  /** Tela cheia do terminal (ou restaura). */
  const toggleFullscreen = () => {
    if (document.fullscreenElement) {
      void document.exitFullscreen();
      setFullscreen(false);
    } else {
      void document.documentElement.requestFullscreen?.();
      setFullscreen(true);
    }
  };

  const modeIcon =
    chartMode === 'heatmap' ? (
      <Flame className="h-3.5 w-3.5" />
    ) : chartMode === 'line' ? (
      <LineChart className="h-3.5 w-3.5" />
    ) : (
      <CandlestickChart className="h-3.5 w-3.5" />
    );

  return (
    <section
      ref={sectionRef}
      className={`flex min-h-0 min-w-0 flex-1 flex-col ${className}`}
      aria-label={primary ? 'Gráfico' : 'Gráfico anexado'}
    >
      {/* ── header ATAS ── */}
      <header className="flex h-9 shrink-0 items-center gap-1 overflow-x-auto border-b border-[#27272a] bg-[#151515] px-1.5 scrollbar-none">
        <GripVertical className="h-3.5 w-3.5 shrink-0 text-[#5d606b]" aria-hidden />
        <button
          type="button"
          onClick={() => setSymbolOpen('symbol')}
          className="h-7 shrink-0 rounded px-1.5 text-[12px] font-bold text-white transition-colors hover:bg-[#222226]"
        >
          #{symbol}
        </button>
        {isPinned && (
          <span
            className="flex h-5 shrink-0 items-center gap-1 rounded border border-[#4682b4] bg-[#1d2a38] px-1.5 text-[9px] font-bold uppercase tracking-wider text-[#7ba7c9]"
            title="Painel pinado: timeframe/tipo de barra independentes (multi-chart)"
          >
            pin
          </span>
        )}
        <span className="hidden shrink-0 whitespace-nowrap pr-1 text-[10px] text-[#787b86] sm:inline">
          tick {meta.tick}
        </span>
        <span className="h-5 w-px shrink-0 bg-[#27272a]" />

        {/* timeframes — painel pinado: altera só o painel (tf ≥ stream) */}
        <div className="flex shrink-0 items-center gap-0.5">
          {TIMEFRAMES.map((t) => {
            const derivable = pinnedTf === undefined || TF_MS[t] >= TF_MS[tf];
            return (
              <button
                key={t}
                type="button"
                disabled={!derivable}
                title={
                  !derivable
                    ? `S5/S15 abaixo do stream (${TF_LABEL[tf]}) não são deriváveis localmente`
                    : undefined
                }
                onClick={() => (pinnedTf !== undefined ? setPinnedTf(t) : setTf(t))}
                className={`h-7 rounded px-2 text-[11px] font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-35 ${
                  effTf === t
                    ? 'bg-[#27272a] text-white shadow-[inset_0_-2px_0_0_#4682b4]'
                    : 'text-[#b2b5be] hover:bg-[#222226] hover:text-white'
                }`}
              >
                {TF_LABEL[t]}
              </button>
            );
          })}
          <Popover>
            <PopoverTrigger asChild>
              <button
                type="button"
                aria-label="Mais timeframes"
                className="flex h-7 w-5 items-center justify-center rounded text-[#787b86] hover:bg-[#222226] hover:text-white"
              >
                <ChevronDown className="h-3.5 w-3.5" />
              </button>
            </PopoverTrigger>
            <PopoverContent
              side="bottom"
              align="start"
              className="w-40 border-[#27272a] bg-[#1f1f23] p-1"
            >
              {(['M15', 'M30', 'H1', 'D1'] as const).map((t) => (
                <div
                  key={t}
                  className="flex h-7 cursor-not-allowed items-center justify-between rounded px-2 text-[11px] text-[#5d606b]"
                >
                  {t}
                  <span className="text-[9px]">sem histórico</span>
                </div>
              ))}
            </PopoverContent>
          </Popover>
        </div>

        <span className="h-5 w-px shrink-0 bg-[#27272a]" />
        <HeadBtn tip="Sessão" className="shrink-0">
          <span className="text-[11px] font-semibold">$ 0</span>
        </HeadBtn>

        {/* indicadores */}
        <button
          type="button"
          onClick={() => setSymbolOpen('indicators')}
          className="flex h-7 shrink-0 items-center gap-1.5 rounded px-2 text-[11px] font-medium text-[#d1d4dc] transition-colors hover:bg-[#222226]"
        >
          <LineChart className="h-3.5 w-3.5 text-[#787b86]" />
          <span className="hidden md:inline">Indicadores</span>
        </button>

        {/* heatmap de liquidez (toggle rápido) */}
        <HeadBtn
          tip={
            chartMode === 'heatmap'
              ? 'Sair do heatmap (voltar ao cluster)'
              : 'Heatmap de liquidez (profundidade do book por bucket)'
          }
          className="shrink-0"
          onClick={() => patch({ chartMode: chartMode === 'heatmap' ? 'clusters' : 'heatmap' })}
        >
          <span
            className={`flex h-7 items-center gap-1.5 rounded px-2 text-[11px] font-semibold transition-colors ${
              chartMode === 'heatmap'
                ? 'bg-[#3a2f1e] text-[#e8a854] hover:bg-[#46382a]'
                : 'text-[#b2b5be] hover:bg-[#222226] hover:text-white'
            }`}
          >
            <Flame className="h-3.5 w-3.5" />
            <span className="hidden md:inline">Heatmap</span>
          </span>
        </HeadBtn>

        {/* tipo de gráfico */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              type="button"
              aria-label="Tipo de gráfico"
              className="flex h-7 w-7 shrink-0 items-center justify-center rounded text-[#d1d4dc] transition-colors hover:bg-[#222226]"
            >
              {modeIcon}
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent
            align="start"
            className="border-[#27272a] bg-[#1f1f23] text-[#d1d4dc]"
          >
            <DropdownMenuLabel className="text-[9px] uppercase tracking-wider text-[#787b86]">
              Tipo de gráfico
            </DropdownMenuLabel>
            {(
              [
                { id: 'clusters', label: 'Cluster', icon: <Grid2x2 className="h-3.5 w-3.5" /> },
                { id: 'candles', label: 'Candles', icon: <CandlestickChart className="h-3.5 w-3.5" /> },
                { id: 'line', label: 'Linha', icon: <LineChart className="h-3.5 w-3.5" /> },
                { id: 'heatmap', label: 'Heatmap', icon: <Flame className="h-3.5 w-3.5" /> },
              ] as const
            ).map((o) => (
              <DropdownMenuItem
                key={o.id}
                onClick={() => patch({ chartMode: o.id })}
                className={`gap-2 text-[11px] data-[highlighted]:bg-[#27272a] ${
                  chartMode === o.id ? 'text-white' : ''
                }`}
              >
                {o.icon}
                {o.label}
                {chartMode === o.id && <span className="ml-auto text-[#4682b4]">●</span>}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* tipo de barra (tempo / não-temporal) */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              type="button"
              aria-label="Tipo de barra"
              className={`flex h-7 shrink-0 items-center gap-1 rounded px-2 text-[11px] font-semibold transition-colors ${
                barType === 'time'
                  ? 'text-[#b2b5be] hover:bg-[#222226] hover:text-white'
                  : 'bg-[#27272a] text-white shadow-[inset_0_-2px_0_0_#4682b4]'
              }`}
            >
              {barPill(effBarType, effBarType === 'time' ? 0 : effBarParam)}
              <ChevronDown className="h-3 w-3 opacity-70" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent
            align="start"
            className="border-[#27272a] bg-[#1f1f23] text-[#d1d4dc]"
          >
            <DropdownMenuLabel className="text-[9px] uppercase tracking-wider text-[#787b86]">
              Tipo de barra
            </DropdownMenuLabel>
            {(
              [
                { id: 'time', hint: 'por tempo' },
                { id: 'range', hint: 'amplitude em ticks' },
                { id: 'reversal', hint: 'reversão em ticks' },
                { id: 'tick', hint: 'negócios por barra' },
                { id: 'volume', hint: 'volume por barra' },
              ] as const
            ).map((o) => (
              <DropdownMenuItem
                key={o.id}
                onClick={() =>
                  pinnedBar
                    ? setPinnedBar({ type: o.id as BarType, param: pinnedBar.param })
                    : patch({ barType: o.id as BarType })
                }
                className={`gap-2 text-[11px] data-[highlighted]:bg-[#27272a] ${
                  effBarType === o.id ? 'text-white' : ''
                }`}
              >
                {o.id === 'time' ? BAR_LABEL.time : BAR_LABEL[o.id as Exclude<BarType, 'time'>]}
                <span className="ml-auto text-[9px] text-[#5d606b]">{o.hint}</span>
                {effBarType === o.id && <span className="ml-1 text-[#4682b4]">●</span>}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* parâmetro da barra não-temporal */}
        {effBarType !== 'time' && (
          <input
            type="number"
            min={1}
            value={effBarParam}
            onChange={(e) => {
              const v = Math.max(1, Math.floor(Number(e.target.value) || 1));
              if (pinnedBar) setPinnedBar({ ...pinnedBar, param: v });
              else
                patch({
                  barParams: { [effBarType]: v } as Partial<Record<Exclude<BarType, 'time'>, number>>,
                });
            }}
            aria-label={`Parâmetro da barra (${BAR_UNIT[effBarType as Exclude<BarType, 'time'>]})`}
            title={`Parâmetro em ${BAR_UNIT[effBarType as Exclude<BarType, 'time'>]}`}
            className="h-7 w-14 shrink-0 rounded border border-[#27272a] bg-[#222226] px-1 text-center font-num text-[11px] text-[#d1d4dc] outline-none focus:border-[#4682b4]"
          />
        )}

        {/* replay de mercado */}
        <HeadBtn
          tip={replayActive ? 'Sair do replay' : 'Replay de mercado'}
          className="shrink-0"
          onClick={() => (replayActive ? exitReplay() : enterReplay())}
        >
          <span
            className={`flex h-7 items-center gap-1.5 rounded px-2 text-[11px] font-semibold transition-colors ${
              replayActive
                ? 'bg-[#e8a854] text-[#1a1c20] hover:bg-[#f0b96b]'
                : 'text-[#b2b5be] hover:bg-[#222226] hover:text-white'
            }`}
          >
            <History className="h-3.5 w-3.5" />
            <span className="hidden md:inline">Replay</span>
          </span>
        </HeadBtn>

        {/* decorativos */}
        <HeadBtn tip="Modo do mouse (em breve)" className="hidden shrink-0 lg:flex">
          <MousePointer2 className="h-3.5 w-3.5" />
        </HeadBtn>
        <HeadBtn tip="Configurações gerais" className="shrink-0" onClick={() => setSymbolOpen('settings')}>
          <Settings2 className="h-3.5 w-3.5" />
        </HeadBtn>
        <HeadBtn tip="Chart Trader (em breve)" className="hidden shrink-0 lg:flex">
          <ArrowLeftRight className="h-3.5 w-3.5" />
        </HeadBtn>

        <span className="min-w-2 flex-1" />

        {/* anexar/desanexar gráfico */}
        <HeadBtn
          tip={
            primary
              ? 'Anexar gráfico ao lado (mesmo instrumento)'
              : 'Desanexar este gráfico'
          }
          className="hidden shrink-0 xl:flex"
          onClick={toggleAttach}
        >
          {chartCount === 2 ? (
            <Unlink2 className="h-3.5 w-3.5 text-[#4682b4]" />
          ) : (
            <Link2 className="h-3.5 w-3.5" />
          )}
        </HeadBtn>
        <HeadBtn tip="Escala de preço (em breve)" className="hidden shrink-0 xl:flex">
          <span className="text-[10px] font-semibold">⇕</span>
        </HeadBtn>
        <HeadBtn tip="Screenshot (PNG do gráfico)" className="hidden shrink-0 xl:flex" onClick={takeShot}>
          <Camera className="h-3.5 w-3.5" />
        </HeadBtn>
        <HeadBtn
          tip={fullscreen ? 'Sair da tela cheia' : 'Tela cheia'}
          className="hidden shrink-0 xl:flex"
          onClick={toggleFullscreen}
        >
          {fullscreen ? <Minimize2 className="h-3.5 w-3.5" /> : <Maximize2 className="h-3.5 w-3.5" />}
        </HeadBtn>
        {!primary && (
          <HeadBtn tip="Fechar gráfico anexado" className="hidden shrink-0 xl:flex" onClick={toggleAttach}>
            <X className="h-3.5 w-3.5" />
          </HeadBtn>
        )}
      </header>

      {/* ── canvas + stats — container zerado: motor gráfico encosta nas divisórias ── */}
      <div className="canvas-fit relative min-h-0 flex-1">
        <ClusterChart
          onHoverCandle={onHover}
          pinnedTf={pinnedTf}
          pinnedBar={pinnedBar}
        />
        <StatsTable idx={hoverIdx} />
        {primary && <ReplayBar />}
      </div>

      {primary && <SessionStrip />}
    </section>
  );
});
