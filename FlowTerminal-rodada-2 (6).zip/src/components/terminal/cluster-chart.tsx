'use client';

import { memo, useEffect, useRef, useState } from 'react';
import { Undo2 } from 'lucide-react';
import { mboClient } from '@/lib/mbo/client';
import type { FlowSignal } from '@/lib/market/flow';
import { useTerminalStore } from '@/store/terminal';
import { useTradingStore } from '@/lib/trading/engine';
import { aggregateCandles, buildBars, type BarType } from '@/lib/market/bars';
import { ema, rsi, sma } from '@/lib/market/indicators';
import { buildChain, flipSpot, gexPerStrike, strikeStep } from '@/lib/quant/quant';
import { HeatGl, signalColor, type GlBubble, type HeatGlScene } from '@/lib/render/heat-gl';
import {
  useDrawingStore,
  hitTestDraw,
  moveDraw,
  type DrawHandle,
  type DrawKind,
  type DrawObj,
  type DrawPt,
} from '@/lib/drawings';
import { symbolMeta, TF_MS, type Candle, type CandleLevel, type Timeframe } from '@/lib/market/types';
import {
  fmtCompact,
  fmtHm,
  fmtPrice,
  fmtSignedCompact,
  fmtSize,
  fmtTime,
} from '@/lib/market/format';

// ── paleta ATAS Web ──────────────────────────────────────────────────────────
const TEAL = '8,153,129'; // #089981  bids / compra / alta
const RED = '242,56,90'; // #f2385a  asks / venda / baixa
const BLUE = '41,98,255'; // #2962ff  delta positivo (ATAS)
const STEEL = '70,130,180'; // #4682b4  acento / último preço (azul aço)
const AMBER = '232,168,84'; // #e8a854  VWAP / máximo
const GRID = '39,39,42'; // linhas de grade — neutras e sólidas sobre #18181b
const TXT = '178,181,190'; // texto secundário
/** colunas da borda viva pintadas pelo anel GL (resto: caminho 2D) */
const LIVE_RING_COLS = 3;

const BG = '#18181b';
const rgba = (c: string, a: number) => `rgba(${c},${a})`;

const TIME_AXIS_H = 24;
const PANE_H = 96; // painel de delta: histograma + CVD + faixa bid/ask
const STRIP_H = 24; // faixa bid|ask por vela (dentro do painel)
const RSI_H = 64; // painel de RSI (14)
const AXIS_W = 64;

const FIB_RATIOS = [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1] as const;
/** extensões de Fibonacci (projeção além do swing a→b) */
const FIB_EXT_RATIOS = [0, 0.618, 1, 1.272, 1.618, 2, 2.618] as const;
const DRAW_RGB = '70,130,180'; // azul aço — cor default dos desenhos

// cores GL (0..1) para bolhas/sinais na camada WebGL
const GL_TEAL: [number, number, number] = [0.031, 0.6, 0.506];
const GL_RED: [number, number, number] = [0.949, 0.22, 0.353];
const GL_AMBER: [number, number, number] = [0.91, 0.659, 0.329];

const FONT_MONO = (px: number, weight = '') =>
  `${weight} ${px}px ${monoFamily()}`.trimStart();

/**
 * Tipografia técnica: resolve a pilha monospace de `--font-numeric`
 * (classe .font-num) uma única vez e reutiliza no canvas — clusters
 * numéricos do gráfico usam a MESMA fonte mono estrita do DOM.
 */
let monoFamilyCache = '';
function monoFamily(): string {
  if (monoFamilyCache) return monoFamilyCache;
  try {
    const probe = document.createElement('span');
    probe.className = 'font-num';
    probe.style.position = 'absolute';
    probe.style.opacity = '0';
    probe.style.pointerEvents = 'none';
    probe.textContent = '0';
    document.body.appendChild(probe);
    monoFamilyCache = getComputedStyle(probe).fontFamily || 'monospace';
    probe.remove();
  } catch {
    monoFamilyCache = 'monospace';
  }
  return monoFamilyCache;
}

/**
 * Legibilidade do footprint: sombra de texto equivalente a
 * `text-shadow: 1px 1px 2px rgba(0,0,0,0.9)` + peso ≥600 — destaca os números
 * sobre o heatmap (células bid/ask, delta e volume total).
 */
function textShadowOn(ctx: CanvasRenderingContext2D) {
  ctx.shadowColor = 'rgba(0,0,0,0.9)';
  ctx.shadowOffsetX = 1;
  ctx.shadowOffsetY = 1;
  ctx.shadowBlur = 2;
}
function textShadowOff(ctx: CanvasRenderingContext2D) {
  ctx.shadowColor = 'transparent';
  ctx.shadowOffsetX = 0;
  ctx.shadowOffsetY = 0;
  ctx.shadowBlur = 0;
}

interface Group {
  gIdx: number;
  b: number;
  a: number;
  lo: number; // tick index mínimo do grupo
  hi: number; // tick index máximo do grupo
  buyImb: boolean;
  sellImb: boolean;
  maxVol: number;
}

/**
 * Agrupa níveis de preço em blocos (merge levels estilo ATAS). Desequilíbrio
 * diagonal clássico: ask[i] vs bid[i-1] (g=1) ou entre grupos adjacentes.
 */
function buildGroups(candle: Candle, g: number, ratio: number, showImb: boolean): Group[] {
  const map = new Map<number, Group>();
  const lv = candle.lv;
  for (const key in lv) {
    const tickIdx = Number(key);
    const l: CandleLevel = lv[key];
    const vol = l.a + l.b;
    if (vol <= 0) continue;
    const gi = Math.floor(tickIdx / g);
    let grp = map.get(gi);
    if (!grp) {
      grp = { gIdx: gi, b: 0, a: 0, lo: tickIdx, hi: tickIdx, buyImb: false, sellImb: false, maxVol: 0 };
      map.set(gi, grp);
    }
    grp.b += l.b;
    grp.a += l.a;
    if (tickIdx < grp.lo) grp.lo = tickIdx;
    if (tickIdx > grp.hi) grp.hi = tickIdx;
    grp.maxVol += vol;
  }
  const groups = Array.from(map.values()).sort((x, y) => x.gIdx - y.gIdx);
  if (showImb && groups.length > 1) {
    for (let i = 1; i < groups.length; i++) {
      const cur = groups[i];
      const below = groups[i - 1];
      if (cur.a > 0 && cur.a >= ratio * below.b) cur.buyImb = true;
      if (below.b > 0 && below.b >= ratio * cur.a) below.sellImb = true;
    }
  }
  return groups;
}

function niceStep(raw: number, tick: number): number {
  const mag = Math.pow(10, Math.floor(Math.log10(Math.max(raw, Number.EPSILON))));
  const norm = raw / mag;
  const nice = norm <= 1 ? 1 : norm <= 2 ? 2 : norm <= 2.5 ? 2.5 : norm <= 5 ? 5 : 10;
  const step = nice * mag;
  const steps = Math.max(1, Math.round(step / tick));
  return steps * tick;
}

interface ViewState {
  candleW: number;
  rightOffsetPx: number;
  panY: number;
  /** zoom vertical do heatmap (1 = enquadra tudo; >1 aproxima os níveis de preço) */
  zoomY: number;
  dragging: boolean;
  downX: number;
  downY: number;
  downOffset: number;
  downPanY: number;
  moved: boolean;
  hoverX: number;
  hoverY: number;
  hovering: boolean;
}

interface ClusterChartProps {
  /** índice da vela sob o cursor (ou null); usado pela tabela de stats do widget */
  onHoverCandle?: (idx: number | null) => void;
  /**
   * PIN do painel (multi-chart): timeframe e/ou tipo de barra independentes
   * do stream global. tf ≥ stream é derivado localmente (aggregateCandles);
   * tipo de barra não-temporal é derivado via buildBars.
   */
  pinnedTf?: Timeframe;
  pinnedBar?: { type: BarType; param: number } | null;
}

/** rótulos das ferramentas de desenho (hint no rodapé do gráfico) */
const TOOL_LABEL: Record<string, string> = {
  trend: 'Tendência',
  hline: 'Linha horizontal',
  hray: 'Raio horizontal',
  vline: 'Linha vertical',
  rect: 'Retângulo',
  ellipse: 'Elipse',
  triangle: 'Triângulo',
  arrow: 'Seta',
  fib: 'Fibonacci',
  fibext: 'Fibonacci (extensão)',
  rrisk: 'Risco/Retorno',
  vprof: 'Volume Profile (range fixo)',
  ruler: 'Régua',
  text: 'Texto',
  range: 'Canal de range',
  mlevel: 'Níveis matemáticos',
};

// ── Fixed Range Volume Profile (helper da ferramenta vprof) ──────────────

interface RangeRow {
  lo: number; // tick idx mínimo do bloco
  hi: number; // tick idx máximo do bloco
  v: number;
}

interface RangeProfile {
  rows: RangeRow[];
  pocV: number;
  total: number;
}

/**
 * Agrega o volume executado por bloco de `g` ticks no intervalo de barras
 * [i0..i1] (espaço de barras EFETIVO do gráfico — tempo ou não-temporal).
 * Custo O(range × níveis); o resultado é cacheado por objeto no chart.
 */
function buildRangeProfile(candles: Candle[], i0: number, i1: number, g: number): RangeProfile {
  const pg = new Map<number, RangeRow>();
  let total = 0;
  const hi = Math.min(i1, candles.length - 1);
  for (let i = Math.max(0, i0); i <= hi; i++) {
    const c = candles[i];
    if (!c) continue;
    for (const key in c.lv) {
      const l = c.lv[key];
      const vol = l.a + l.b;
      if (vol <= 0) continue;
      const idx = Number(key);
      const gi = Math.floor(idx / g);
      const cur = pg.get(gi);
      if (cur) {
        cur.v += vol;
        if (idx < cur.lo) cur.lo = idx;
        if (idx > cur.hi) cur.hi = idx;
      } else {
        pg.set(gi, { lo: idx, hi: idx, v: vol });
      }
      total += vol;
    }
  }
  let pocV = 0;
  for (const r of pg.values()) if (r.v > pocV) pocV = r.v;
  return { rows: Array.from(pg.values()), pocV, total };
}

// ── Assinaturas MBO no gráfico (iceberg × spoofing) ──────────────────

/**
 * Marcadores de execução de iceberg e de cancelamento abrupto (spoofing)
 * desenhados DIRETAMENTE sobre os clusters do footprint/heatmap:
 * - iceberg: disco ciano + anel tracejado pulsante — nível oculto que se
 *   reabastece sob fogo contínuo;
 * - spoofing: quadrado com X laranja — liquidez-fantasma (grande, perto do
 *   BBO) cancelada sem execução relevante.
 *
 * Sempre no caminho 2D (assinatura consistente com ou sem WebGL); custo O(1)
 * — poucos sinais vivos (TTL 6s, rate-limit 6/s no worker), fora do hot-path
 * dos clusters.
 */
function drawMboSignature(
  ctx: CanvasRenderingContext2D,
  kind: 'iceberg' | 'spoof',
  x: number,
  y: number,
  pulse: number,
  strength: number,
): void {
  if (kind === 'iceberg') {
    const r1 = 3.2 + 2.5 * strength;
    ctx.fillStyle = rgba('41,182,246', 0.5 + 0.45 * pulse);
    ctx.beginPath();
    ctx.arc(x, y, r1, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = rgba('41,182,246', 0.3 + 0.6 * pulse);
    ctx.lineWidth = 1.3;
    ctx.setLineDash([2.5, 2.5]);
    ctx.beginPath();
    ctx.arc(x, y, r1 + 4 + 2 * pulse, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.lineWidth = 1;
  } else {
    const s = 3.4 + 2.2 * strength;
    ctx.strokeStyle = rgba('255,109,58', 0.45 + 0.55 * pulse);
    ctx.lineWidth = 1.4;
    ctx.strokeRect(x - s, y - s, s * 2, s * 2);
    ctx.beginPath();
    ctx.moveTo(x - s, y - s);
    ctx.lineTo(x + s, y + s);
    ctx.moveTo(x + s, y - s);
    ctx.lineTo(x - s, y + s);
    ctx.stroke();
    ctx.lineWidth = 1;
  }
}

export const ClusterChart = memo(function ClusterChart({
  onHoverCandle,
  pinnedTf,
  pinnedBar,
}: ClusterChartProps) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  /** canvas WebGL (heatmap/bolhas/sinais) sobreposto ao canvas 2D */
  const glCanvasRef = useRef<HTMLCanvasElement>(null);
  const glRef = useRef<HeatGl | null>(null);
  const rafRef = useRef(0);
  const followRef = useRef(true);
  const [followUi, setFollowUi] = useState(true);
  const hoverIdxRef = useRef<number | null>(null);
  const onHoverRef = useRef(onHoverCandle);
  useEffect(() => {
    onHoverRef.current = onHoverCandle;
  }, [onHoverCandle]);

  // pin do painel (multi-chart): refs espelhadas p/ o loop de draw (rAF)
  const pinnedTfRef = useRef<Timeframe | undefined>(pinnedTf);
  const pinnedBarRef = useRef<{ type: BarType; param: number } | null | undefined>(pinnedBar);

  // desenhos: rascunho em criação + pré-visualização + âncora de texto
  const draftRef = useRef<{ kind: DrawKind; pts: DrawPt[] } | null>(null);
  const draftDragRef = useRef(false);
  const previewRef = useRef<DrawPt | null>(null);
  /**
   * Manipulação (drag) de um desenho existente: estado local do arrasto —
   * o store só é tocado no pointerup (commit único) e o redraw acontece no
   * rAF do loop principal, sem trabalho extra fora do frame.
   */
  const drawDragRef = useRef<{
    key: string;
    id: string;
    kind: DrawKind;
    handle: DrawHandle;
    orig: DrawPt[];
    pts: DrawPt[];
    moved: boolean;
  } | null>(null);
  /** desenh sob o cursor (feedback de handles) — atualizado no pointermove */
  const drawHoverRef = useRef<{ id: string; handle: DrawHandle } | null>(null);
  /** cache de Fixed Range Volume Profiles (ferramenta vprof) por objeto */
  const vprofCacheRef = useRef<Map<string, { key: string; prof: RangeProfile }>>(new Map());
  const scaleRef = useRef({ plotW: 0, mainH: 0, priceTop: 0, range: 1 });
  const [textEdit, setTextEdit] = useState<{ px: number; py: number; pt: DrawPt } | null>(null);
  const activeTool = useDrawingStore((s) => s.tool);

  /** agenda um redraw (mesmo padrão do efeito principal) */
  const scheduleDraw = () => {
    if (rafRef.current === 0) {
      rafRef.current = requestAnimationFrame(() => {
        rafRef.current = 0;
        drawRef.current();
      });
    }
  };

  /** confirma o texto do tool "Texto" no espaço de dados da âncora */
  const commitText = (val: string) => {
    const cur = textEdit;
    setTextEdit(null);
    if (cur && val.trim()) {
      const st2 = useTerminalStore.getState();
      useDrawingStore.getState().add(`${st2.symbol}|${st2.tf}`, {
        id: `t${Date.now().toString(36)}`,
        kind: 'text',
        pts: [{ i: cur.pt.i, p: cur.pt.p }],
        text: val.trim(),
      });
      scheduleDraw();
    }
  };

  const view = useRef<ViewState>({
    candleW: 38,
    rightOffsetPx: 64,
    panY: 0,
    zoomY: 1,
    dragging: false,
    downX: 0,
    downY: 0,
    downOffset: 0,
    downPanY: 0,
    moved: false,
    hoverX: 0,
    hoverY: 0,
    hovering: false,
  });

  // ── draw ───────────────────────────────────────────────────────────────────
  const draw = () => {
    const cv = canvasRef.current;
    if (!cv) return;
    const ctx = cv.getContext('2d');
    if (!ctx) return;

    const stRaw = useTerminalStore.getState();
    const meta = symbolMeta(stRaw.symbol);
    const tick = meta.tick;
    // PIN do painel: deriva candles/tf/barType efetivos (multi-chart). tf maior
    // é agregado localmente; tipo de barra vem do pin (buildBars). Sem pin,
    // stRaw é usado direto (zero custo extra no gráfico principal).
    let st = stRaw;
    const pinTf = pinnedTfRef.current;
    const pinBar = pinnedBarRef.current;
    if (pinTf && pinTf !== stRaw.tf && TF_MS[pinTf] >= TF_MS[stRaw.tf]) {
      st = { ...stRaw, tf: pinTf, candles: aggregateCandles(stRaw.candles, stRaw.tf, pinTf) };
    }
    if (pinBar) {
      st = { ...st, barType: pinBar.type, barParams: { ...st.barParams, [pinBar.type]: pinBar.param } };
    }
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    const W = cv.width / dpr;
    const H = cv.height / dpr;
    const v = view.current;

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = BG;
    ctx.fillRect(0, 0, W, H);

    const showDelta = st.showDeltaPane;
    const rsiH = st.showRSI ? RSI_H : 0;
    const paneH = (showDelta ? PANE_H : 0) + rsiH;
    const mainH = Math.max(60, H - TIME_AXIS_H - paneH);
    const plotW = Math.max(50, W - AXIS_W);
    const mode = st.chartMode;
    // heatmap de liquidez requer alinhamento temporal — barras não-temporais caem p/ clusters
    const heatMode = mode === 'heatmap' && st.barType === 'time';
    // no modo heatmap com barras não-temporais, desenha o footprint no lugar
    const clustersMode = mode === 'clusters' || (mode === 'heatmap' && st.barType !== 'time');
    const cellMode = st.displayMode;
    // replay: fatia do histórico até o playhead; ao vivo usa tudo
    const rep = st.replay;
    const liveLen = st.candles.length;
    const cutIdx = rep.active ? Math.min(rep.idx, liveLen - 1) : liveLen - 1;
    const shownCandles =
      rep.active && liveLen > 0 ? st.candles.slice(0, Math.max(1, cutIdx + 1)) : st.candles;
    // barras: as-is (tempo) ou construídas (Range/Reversão/Tick/Volume)
    const candles =
      st.barType === 'time'
        ? shownCandles
        : buildBars(shownCandles, st.barType, st.barParams[st.barType] ?? 10, tick, st.tf);
    const N = candles.length;

    // ── escala X ─────────────────────────────────────────────────────────
    const rightEdgeOfLast = plotW - v.rightOffsetPx;
    const cxOf = (i: number) => rightEdgeOfLast - (N - 1 - i) * v.candleW - v.candleW / 2;
    const firstVisible = Math.max(0, Math.ceil(N - 1 - (plotW - v.rightOffsetPx) / v.candleW) - 1);
    const lastVisible = Math.min(
      N - 1,
      Math.ceil(N - 1 + (plotW + v.candleW - (plotW - v.rightOffsetPx)) / v.candleW),
    );
    const idxAt = (x: number) =>
      Math.round(N - 1 - (rightEdgeOfLast - v.candleW / 2 - x) / v.candleW);
    const vis = candles.slice(Math.max(0, firstVisible), Math.max(0, lastVisible + 1));

    // ── escala Y (preço) ─────────────────────────────────────────────────
    let pMin = Infinity;
    let pMax = -Infinity;
    for (const c of vis) {
      if (c.l < pMin) pMin = c.l;
      if (c.h > pMax) pMax = c.h;
    }
    if (st.session) {
      pMin = Math.min(pMin, st.session.last);
      pMax = Math.max(pMax, st.session.last);
    }
    if (!isFinite(pMin) || !isFinite(pMax)) {
      pMin = 0;
      pMax = 1;
    }
    if (heatMode) {
      // zoom vertical: só quando o USUÁRIO pede (Shift+roda). O auto-zoom antigo
      // (forçar ~2,6px/tick) espremia a vista em ±25 ticks — com o preço caminhando,
      // o heatmap nascia quase vazio. No padrão (zoomY=1) a vista mostra toda a
      // amplitude visível: o degrau de liquidez acompanha o preço (estilo TapeDelta).
      const zoom = Math.max(1, v.zoomY);
      if (zoom > 1) {
        // replay: centra no close do playhead (não no preço ao vivo)
        const center =
          rep.active && N > 0
            ? candles[N - 1].c
            : (st.session?.last ?? (pMin + pMax) / 2);
        const span0 = pMax - pMin;
        const half = Math.max(tick * 14, span0 / 2 / zoom);
        pMin = center - half;
        pMax = center + half;
      }
      pMin -= tick * 6;
      pMax += tick * 6;
    }
    if (pMax - pMin < tick * 8) {
      const mid = (pMin + pMax) / 2;
      pMin = mid - tick * 4;
      pMax = mid + tick * 4;
    }
    const pad = (pMax - pMin) * 0.14;
    let priceTop = pMax + pad;
    let priceBot = pMin - pad;
    const ppp0 = mainH / (priceTop - priceBot);
    const shift = v.panY;
    priceTop += shift * ppp0;
    priceBot += shift * ppp0;
    const range = priceTop - priceBot;
    const yOf = (p: number) => ((priceTop - p) / range) * mainH;
    const rowH = (tick / range) * mainH;
    // escala exposta p/ os handlers de desenho (coords de tela ↔ dados)
    scaleRef.current = { plotW, mainH, priceTop, range };

    // ── camada WebGL (motor MBO): anel do heatmap + bolhas + sinais ────────
    const glInst = glRef.current;
    const glOn = !!(st.useWebgl && glInst?.ok);
    let glScene: HeatGlScene | null = null;
    if (glOn && glInst) {
      glScene = {
        ring: null,
        x0: 0,
        dx: v.candleW,
        y0: 0,
        dy: rowH,
        colsUsed: 0,
        heatAlpha: 1,
        bubbles: [],
        plotX: 0,
        plotY: 0,
        plotW,
        plotH: mainH,
      };
    }

    const minCellPx = v.candleW >= 34 ? 11 : 4;
    const g = Math.max(1, Math.ceil(minCellPx / Math.max(rowH, 0.05)));

    const clipPlot = () => {
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 0, plotW, mainH);
      ctx.clip();
    };

    // ── grade ────────────────────────────────────────────────────────────
    clipPlot();
    ctx.lineWidth = 1;
    const step = niceStep(range / 7, tick);
    ctx.strokeStyle = rgba(GRID, 0.6);
    for (let p = Math.ceil(priceBot / step) * step; p <= priceTop; p += step) {
      const y = Math.round(yOf(p)) + 0.5;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(plotW, y);
      ctx.stroke();
    }
    const tStep = Math.max(1, Math.ceil(120 / v.candleW));
    ctx.strokeStyle = rgba(GRID, 0.42);
    for (let i = N - 1 - ((N - 1 - Math.floor((plotW - v.rightOffsetPx) / v.candleW)) % tStep); i >= 0; i -= tStep) {
      const x = Math.round(cxOf(i)) + 0.5;
      if (x < -v.candleW) break;
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, mainH);
      ctx.stroke();
    }

    // separadores de sessão (mudança de dia) — linha azul pontilhada ATAS
    ctx.strokeStyle = rgba('96,116,230', 0.55);
    ctx.setLineDash([2, 4]);
    for (let i = Math.max(1, firstVisible); i <= lastVisible && i < N; i++) {
      const dPrev = new Date(candles[i - 1].t);
      const dCur = new Date(candles[i].t);
      if (dPrev.getDate() !== dCur.getDate() || dPrev.getMonth() !== dCur.getMonth()) {
        const x = Math.round(cxOf(i) - v.candleW / 2) + 0.5;
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, mainH);
        ctx.stroke();
      }
    }
    ctx.setLineDash([]);

    if (N === 0) {
      ctx.restore();
      ctx.fillStyle = rgba(TXT, 0.6);
      ctx.font = FONT_MONO(12);
      ctx.textAlign = 'center';
      ctx.fillText('aguardando dados de mercado…', plotW / 2, mainH / 2);
      // limpa a camada GL (evita frame velho congelado)
      if (glScene && glInst) {
        glInst.render({ ...glScene, ring: null, bubbles: [] });
      }
      return;
    }

    // ── modo Candles / Linha ─────────────────────────────────────────────
    if (mode === 'candles' || mode === 'line') {
      if (mode === 'candles') {
        const bodyW = Math.max(2, Math.min(19, v.candleW - 3));
        for (let k = 0; k < vis.length; k++) {
          const c = vis[k];
          const cx = cxOf(firstVisible + k);
          const up = c.c >= c.o;
          const col = up ? TEAL : RED;
          ctx.strokeStyle = rgba(col, 0.9);
          ctx.beginPath();
          ctx.moveTo(Math.round(cx) + 0.5, yOf(c.h));
          ctx.lineTo(Math.round(cx) + 0.5, yOf(c.l));
          ctx.stroke();
          const yO = yOf(c.o);
          const yC = yOf(c.c);
          ctx.fillStyle = rgba(col, 0.92);
          ctx.fillRect(cx - bodyW / 2, Math.min(yO, yC), bodyW, Math.max(1.5, Math.abs(yC - yO)));
        }
      } else {
        ctx.strokeStyle = rgba('209,212,220', 0.9);
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        let started = false;
        for (let k = 0; k < vis.length; k++) {
          const cx = cxOf(firstVisible + k);
          const y = yOf(vis[k].c);
          if (!started) {
            ctx.moveTo(cx, y);
            started = true;
          } else ctx.lineTo(cx, y);
        }
        ctx.stroke();
        ctx.lineWidth = 1;
      }
    }

    // ── footprint (clusters) ─────────────────────────────────────────────
    if (!heatMode && clustersMode) {
      const showImb = st.showImbalances && cellMode === 'bidask';
      const ratio = st.imbalanceRatio;
      const minCellVol = st.minCellVolume;
      const showMax = st.showMaxLevels;

      let maxVolView = 0;
      const groupsPerCandle: Group[][] = [];
      for (const c of vis) {
        const gr = buildGroups(c, g, ratio, showImb);
        groupsPerCandle.push(gr);
        for (const grp of gr) if (grp.a + grp.b > maxVolView) maxVolView = grp.a + grp.b;
      }
      maxVolView = Math.max(maxVolView, 1);

      const gH = g * rowH;
      const textOk = gH >= 8 && v.candleW >= 30;
      const compact = v.candleW < 72;
      const fsz = Math.max(7, Math.min(10, Math.floor(gH) - 1));

      for (let k = 0; k < vis.length; k++) {
        const c = vis[k];
        const gr = groupsPerCandle[k];
        const cx = cxOf(firstVisible + k);
        const x = cx - v.candleW / 2;
        const w = v.candleW;
        const up = c.c >= c.o;
        const sideCol = up ? TEAL : RED;

        // pavio + contorno do corpo (atrás das células, como no ATAS)
        ctx.strokeStyle = rgba(sideCol, 0.6);
        ctx.beginPath();
        ctx.moveTo(Math.round(cx) + 0.5, yOf(c.h));
        ctx.lineTo(Math.round(cx) + 0.5, yOf(c.l));
        ctx.stroke();
        const yO = yOf(c.o);
        const yC = yOf(c.c);
        ctx.strokeStyle = rgba(sideCol, 0.8);
        ctx.strokeRect(x + 0.5, Math.min(yO, yC), w - 1, Math.max(1.5, Math.abs(yC - yO)));

        const half = w / 2;
        let maxGrp: Group | null = null;

        for (const grp of gr) {
          const vol = grp.a + grp.b;
          if (minCellVol > 0 && vol < minCellVol) continue;
          if (!maxGrp || vol > maxGrp.a + maxGrp.b) maxGrp = grp;
          const yTop = yOf(grp.hi * tick + tick / 2);
          const yBot = yOf(grp.lo * tick - tick / 2);
          const hh = Math.max(1, yBot - yTop);
          if (yBot < 0 || yTop > mainH) continue;
          const d = grp.a - grp.b;

          let bidFill = '';
          let askFill = '';
          let cellFill = '';
          let txtBid = '';
          let txtAsk = '';
          let txtCell = '';
          let txtColor = 'rgba(255,255,255,0.94)';

          if (cellMode === 'bidask') {
            const heat = 0.1 + 0.46 * Math.sqrt(vol / maxVolView);
            const bidDom = grp.b > grp.a;
            bidFill = rgba(RED, Math.min(0.78, bidDom ? heat * 1.35 : heat));
            askFill = rgba(TEAL, Math.min(0.78, !bidDom ? heat * 1.35 : heat));
            if (textOk) {
              txtBid = compact ? fmtCompact(grp.b) : fmtSize(grp.b, meta.sizeDecimals);
              txtAsk = compact ? fmtCompact(grp.a) : fmtSize(grp.a, meta.sizeDecimals);
            }
            // desequilíbrio: célula sólida no lado vencedor
            if (grp.buyImb || grp.sellImb) {
              if (grp.buyImb) askFill = rgba(TEAL, 0.85);
              if (grp.sellImb) bidFill = rgba(RED, 0.85);
              txtColor = 'rgba(255,255,255,0.98)';
            }
          } else if (cellMode === 'delta') {
            const heat = 0.12 + 0.52 * Math.sqrt(Math.abs(d) / maxVolView);
            cellFill = d >= 0 ? rgba(BLUE, heat) : rgba(RED, heat);
            txtColor = 'rgba(255,255,255,0.95)';
            if (textOk) txtCell = fmtSignedCompact(d);
          } else {
            const heat = 0.08 + 0.42 * Math.sqrt(vol / maxVolView);
            cellFill = rgba(AMBER, heat);
            txtColor = 'rgba(255,248,235,0.95)';
            if (textOk) txtCell = fmtCompact(vol);
          }

          if (cellFill) {
            ctx.fillStyle = cellFill;
            ctx.fillRect(x + 0.5, yTop, w - 1, hh);
          } else {
            ctx.fillStyle = bidFill;
            ctx.fillRect(x + 0.5, yTop, half - 0.5, hh);
            ctx.fillStyle = askFill;
            ctx.fillRect(x + half, yTop, half - 0.5, hh);
          }

          if (textOk) {
            // legibilidade: peso maior (600/700) + sombra 1px 1px 2px preta
            // — contraste rígido sobre as cores do heatmap do footprint
            ctx.font = FONT_MONO(fsz, fsz >= 9 ? '700' : '600');
            textShadowOn(ctx);
            ctx.fillStyle = txtColor;
            if (txtCell) {
              ctx.fillText(txtCell, cx, yTop + hh / 2, w - 3);
            } else if (txtBid && txtAsk) {
              ctx.fillText(txtBid, x + half / 2, yTop + hh / 2, half - 2);
              ctx.fillText(txtAsk, x + half + half / 2, yTop + hh / 2, half - 2);
            }
            textShadowOff(ctx);
          }
        }

        // nível de máximo volume da vela (contorno âmbar ATAS)
        if (showMax && maxGrp) {
          const yTop = yOf(maxGrp.hi * tick + tick / 2);
          const yBot = yOf(maxGrp.lo * tick - tick / 2);
          ctx.fillStyle = rgba(AMBER, 0.08);
          ctx.fillRect(x + 1, yTop, w - 2, Math.max(2, yBot - yTop));
          ctx.strokeStyle = rgba(AMBER, 0.9);
          ctx.lineWidth = 1.2;
          ctx.strokeRect(x + 1, yTop, w - 2, Math.max(2, yBot - yTop));
          ctx.lineWidth = 1;
        }
      }
    }

    // ── heatmap de liquidez ──────────────────────────────────────────────
    if (heatMode) {
      const buckets = st.heatmap;
      const tfMs = TF_MS[st.tf];
      const tRef = candles[N - 1].t;
      const xForT = (t: number) =>
        rightEdgeOfLast - ((tRef - t) / tfMs) * v.candleW - v.candleW / 2;

      // camada WebGL: mapeia o anel do worker MBO para a BORDA VIVA do gráfico
      // (últimas colunas). O histórico fica no caminho 2D — o anel cobre só
      // ±160 ticks ao redor do preço corrente; se pintasse o plot inteiro,
      // o heatmap nascia praticamente vazio (só a janela do anel aparecia).
      // No replay o playhead fica longe do preço ao vivo — a janela do anel
      // segue o livro ao vivo, então cai para o caminho 2D (buckets JSON).
      let ringEdgeX: number | undefined;
      if (glScene && !rep.active) {
        const ring = mboClient.ring;
        if (ring && ring.tfMs === tfMs) {
          glScene.ring = ring;
          glScene.x0 = xForT(ring.firstT);
          glScene.dx = v.candleW;
          glScene.y0 = yOf(ring.colBase * tick + tick / 2);
          glScene.dy = rowH;
          const colsUsed = Math.max(
            0,
            Math.min(ring.cols, Math.floor((tRef - ring.firstT) / tfMs) + 1),
          );
          glScene.colsUsed = colsUsed;
          glScene.ringFromX = glScene.x0 + Math.max(0, colsUsed - LIVE_RING_COLS) * glScene.dx;
          ringEdgeX = glScene.ringFromX;
        }
      }

      const hr = Math.max(1, Math.ceil(3 / Math.max(rowH, 0.02)));
      interface HRow { g: number; b: number; a: number }
      let maxQ = 1;
      const cols: { x: number; rows: HRow[] }[] = [];
      const tFirst = candles[Math.max(0, firstVisible)].t;
      // cols SEMPRE construídas: alimenta as células 2D e as bolhas de profundidade
      {
      for (const b of buckets) {
        if (b.t < tFirst || b.t > tRef) continue; // replay: corta buckets do futuro
        const x = xForT(b.t);
        if (x < -v.candleW || x > plotW + v.candleW) continue;
        const gm = new Map<number, HRow>();
        for (const key in b.lv) {
          const idx = Number(key);
          const pair = b.lv[key];
          const gi = Math.floor(idx / hr);
          let row = gm.get(gi);
          if (!row) {
            row = { g: gi, b: 0, a: 0 };
            gm.set(gi, row);
          }
          if (pair[0] > row.b) row.b = pair[0];
          if (pair[1] > row.a) row.a = pair[1];
        }
        const rows = Array.from(gm.values());
        for (const r of rows) {
          if (r.b > maxQ) maxQ = r.b;
          if (r.a > maxQ) maxQ = r.a;
        }
        cols.push({ x, rows });
      }
      }

      const colW = Math.max(1, v.candleW - 1);

      // células 2D — desenham o HISTÓRICO COMPLETO do heatmap (buckets JSON do
      // snapshot + eventos); a borda viva (últimas LIVE_RING_COLS colunas) fica
      // por conta do anel GL, mais fino (1 tick) e atualizado a ~9 Hz.
      const wallQ = maxQ * 0.72; // paredes esquentam: realce sutil nos maiores
      for (const { x, rows } of cols) {
        for (const r of rows) {
          if (ringEdgeX !== undefined && x + colW > ringEdgeX) continue; // anel cobre
          const yTop = yOf((r.g + 1) * hr * tick);
          const yBot = yOf(r.g * hr * tick);
          const hh = Math.max(1, yBot - yTop);
          if (yBot < 0 || yTop > mainH) continue;
          const useBid = r.b >= r.a;
          const q = useBid ? r.b : r.a;
          if (q <= 0) continue;
          const heat = 0.05 + 0.75 * Math.sqrt(q / maxQ);
          ctx.fillStyle = useBid ? rgba(TEAL, heat) : rgba(RED, heat);
          ctx.fillRect(x, yTop, colW, hh);
          if (q >= wallQ && colW >= 5 && hh >= 4) {
            ctx.strokeStyle = rgba(useBid ? TEAL : RED, 0.5);
            ctx.strokeRect(x + 0.5, yTop + 0.5, colW - 1, hh - 1);
          }
        }
      }

      // ── bolhas de PROFUNDIDADE (raio ∝ book restante no bucket) ─────────
      // aro sobre o heatmap: paredes de liquidez bid/ask que dominaram o bucket
      if (st.showDepthBubbles) {
        const thr = maxQ * (st.depthBubbleMinPct / 100);
        for (const { x, rows } of cols) {
          for (const r of rows) {
            const q = Math.max(r.b, r.a);
            if (q < thr) continue;
            const useBid = r.b >= r.a;
            const yTopD = yOf((r.g + 1) * hr * tick);
            const yBotD = yOf(r.g * hr * tick);
            const yMid = (yTopD + yBotD) / 2;
            if (yMid < -12 || yMid > mainH + 12) continue;
            const strD = Math.min(1, q / Math.max(1, maxQ));
            const radD = Math.min(13, 2.5 + Math.sqrt(strD) * 10);
            const cxD = x + colW / 2;
            if (glScene) {
              glScene.bubbles.push({
                x: cxD,
                y: yMid,
                r: radD,
                color: useBid ? GL_TEAL : GL_RED,
                alpha: 0.2 + 0.5 * strD,
                hollow: 1,
              });
            } else {
              ctx.strokeStyle = rgba(useBid ? TEAL : RED, 0.3 + 0.5 * strD);
              ctx.lineWidth = 1.4;
              ctx.beginPath();
              ctx.arc(cxD, yMid, radD, 0, Math.PI * 2);
              ctx.stroke();
              ctx.lineWidth = 1;
            }
          }
        }
      }

      // linha do último preço sobre o heatmap
      ctx.strokeStyle = rgba('209,212,220', 0.55);
      ctx.lineWidth = 1;
      ctx.beginPath();
      let started = false;
      for (let k = 0; k < vis.length; k++) {
        const cx = cxOf(firstVisible + k);
        const y = yOf(vis[k].c);
        if (!started) {
          ctx.moveTo(cx, y);
          started = true;
        } else ctx.lineTo(cx, y);
      }
      ctx.stroke();

      // legenda do modo heatmap
      ctx.font = FONT_MONO(9);
      ctx.textAlign = 'left';
      ctx.textBaseline = 'top';
      const legendTxt =
        'bolhas: raio ∝ volume · âmbar = trade grande · aros = profundidade do book';
      const legendW = ctx.measureText(legendTxt).width + 12;
      ctx.fillStyle = '#101012';
      ctx.fillRect(4, 4, legendW, 17);
      ctx.fillStyle = rgba('178,181,190', 0.9);
      ctx.fillText(legendTxt, 10, 8);
    }

    // ── volume profile no eixo (vermelho acima da POC, teal abaixo) ──────
    if (st.showProfile && !heatMode) {
      const profileW = Math.min(110, plotW * 0.22);
      const agg = new Map<number, number>();
      if (st.profileMode === 'session' && st.dom) {
        for (const key in st.dom.vol) agg.set(Number(key), st.dom.vol[key]);
      } else {
        for (const c of vis) {
          for (const key in c.lv) {
            const l = c.lv[key];
            const vol = l.a + l.b;
            if (vol <= 0) continue;
            agg.set(Number(key), (agg.get(Number(key)) ?? 0) + vol);
          }
        }
      }
      const pg = new Map<number, { lo: number; hi: number; v: number }>();
      let totalV = 0;
      for (const [tickIdx, vol] of agg) {
        const gi = Math.floor(tickIdx / g);
        const cur = pg.get(gi);
        if (cur) {
          cur.v += vol;
          cur.lo = Math.min(cur.lo, tickIdx);
          cur.hi = Math.max(cur.hi, tickIdx);
        } else {
          pg.set(gi, { lo: tickIdx, hi: tickIdx, v: vol });
        }
        totalV += vol;
      }
      const rows = Array.from(pg.values());
      if (rows.length && totalV > 0) {
        let pocRow = rows[0];
        for (const r of rows) if (r.v > pocRow.v) pocRow = r;
        const maxPV = pocRow.v;
        const sorted = [...rows].sort((a, b) => b.v - a.v);
        let acc = 0;
        let vah = pocRow.lo;
        let val = pocRow.hi;
        for (const r of sorted) {
          acc += r.v;
          vah = Math.max(vah, r.hi);
          val = Math.min(val, r.lo);
          if (acc >= totalV * 0.7) break;
        }
        const inVA = (r: { lo: number; hi: number }) => r.hi >= val && r.lo <= vah;
        const pocMid = (pocRow.lo + pocRow.hi) / 2;

        for (const r of rows) {
          const yTop = yOf(r.hi * tick + tick / 2);
          const yBot = yOf(r.lo * tick - tick / 2);
          const len = (r.v / maxPV) * profileW;
          const above = (r.lo + r.hi) / 2 > pocMid;
          const col = above ? RED : TEAL;
          ctx.fillStyle = r === pocRow ? rgba(AMBER, 0.75) : rgba(col, inVA(r) ? 0.5 : 0.22);
          ctx.fillRect(plotW - len, yTop + 0.5, Math.max(1, len), Math.max(1, yBot - yTop - 1));
        }
        // linhas POC / VA
        const yPoc = Math.round(yOf(pocRow.hi * tick)) + 0.5;
        ctx.strokeStyle = rgba(STEEL, 0.75);
        ctx.setLineDash([6, 4]);
        ctx.beginPath();
        ctx.moveTo(0, yPoc);
        ctx.lineTo(plotW, yPoc);
        ctx.stroke();
        ctx.strokeStyle = rgba(AMBER, 0.3);
        ctx.setLineDash([2, 4]);
        for (const lvl of [vah, val]) {
          const y = Math.round(yOf(lvl * tick)) + 0.5;
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(plotW, y);
          ctx.stroke();
        }
        ctx.setLineDash([]);
      }
    }

    // ── VWAP da sessão ───────────────────────────────────────────────────
    if (st.showVwap && st.session && st.session.vwap > 0) {
      const yV = Math.round(yOf(st.session.vwap)) + 0.5;
      if (yV > -2 && yV < mainH + 2) {
        ctx.strokeStyle = rgba(AMBER, 0.85);
        ctx.setLineDash([2, 3]);
        ctx.beginPath();
        ctx.moveTo(0, yV);
        ctx.lineTo(plotW, yV);
        ctx.stroke();
        ctx.setLineDash([]);
      }
    }

    // ── bandas de desvio-padrão da VWAP (±1σ, ±2σ) ───────────────────────
    if (st.showVwapBands && st.showVwap && st.session && st.session.vwap > 0 && N > 4) {
      let sv = 0;
      let sv2 = 0;
      let sVol = 0;
      for (const c of candles) {
        if (c.v <= 0) continue;
        const tp = (c.h + c.l + c.c) / 3;
        sv += tp * c.v;
        sv2 += tp * tp * c.v;
        sVol += c.v;
      }
      if (sVol > 0) {
        const vwap = sv / sVol;
        const sigma = Math.sqrt(Math.max(0, sv2 / sVol - vwap * vwap));
        if (sigma > 0) {
          // fill entre 1σ e 2σ (acima e abaixo)
          const y1u = yOf(vwap + sigma);
          const y2u = yOf(vwap + 2 * sigma);
          const y1d = yOf(vwap - sigma);
          const y2d = yOf(vwap - 2 * sigma);
          ctx.fillStyle = rgba(AMBER, 0.05);
          if (y2u < y1u)
            ctx.fillRect(0, Math.max(0, y2u), plotW, Math.min(mainH, y1u) - Math.max(0, y2u));
          if (y1d < y2d)
            ctx.fillRect(0, Math.max(0, y1d), plotW, Math.min(mainH, y2d) - Math.max(0, y1d));
          ctx.setLineDash([2, 3]);
          for (const [bnd, alpha] of [
            [sigma, 0.5],
            [2 * sigma, 0.28],
          ] as const) {
            ctx.strokeStyle = rgba(AMBER, alpha);
            for (const lvl of [vwap + bnd, vwap - bnd]) {
              const y = Math.round(yOf(lvl)) + 0.5;
              if (y < -2 || y > mainH + 2) continue;
              ctx.beginPath();
              ctx.moveTo(0, y);
              ctx.lineTo(plotW, y);
              ctx.stroke();
            }
          }
          ctx.setLineDash([]);
        }
      }
    }

    // ── médias móveis (EMA 9 / EMA 21 / SMA 50) ─────────────────────────
    if (st.showEma9 || st.showEma21 || st.showSma50) {
      const lines: { vals: number[]; col: string; label: string }[] = [];
      if (st.showEma9) lines.push({ vals: ema(candles, 9), col: STEEL, label: 'EMA 9' });
      if (st.showEma21) lines.push({ vals: ema(candles, 21), col: AMBER, label: 'EMA 21' });
      if (st.showSma50) lines.push({ vals: sma(candles, 50), col: BLUE, label: 'SMA 50' });
      ctx.lineWidth = 1.2;
      for (const ln of lines) {
        ctx.strokeStyle = rgba(ln.col, 0.85);
        ctx.beginPath();
        let startedMa = false;
        for (let i = Math.max(0, firstVisible); i <= lastVisible && i < N; i++) {
          const val = ln.vals[i];
          if (!Number.isFinite(val)) continue;
          const x = cxOf(i);
          const y = yOf(val);
          if (!startedMa) {
            ctx.moveTo(x, y);
            startedMa = true;
          } else ctx.lineTo(x, y);
        }
        ctx.stroke();
        // rótulo no último valor visível da linha
        for (let i = Math.min(lastVisible, N - 1); i >= 0; i--) {
          const val = ln.vals[i];
          if (!Number.isFinite(val)) continue;
          ctx.fillStyle = rgba(ln.col, 0.95);
          ctx.font = FONT_MONO(9, '700');
          ctx.textAlign = 'right';
          ctx.textBaseline = 'middle';
          ctx.fillText(ln.label, plotW - 4, yOf(val));
          break;
        }
      }
      ctx.lineWidth = 1;
    }

    // ── bolhas de trades (todos os modos; raio ∝ volume, agregadas) ─────
    {
      const tfMs = TF_MS[st.tf];
      const tRefB = N > 0 ? candles[N - 1].t : 0;
      const tCut = tRefB + tfMs; // replay: trades do futuro ficam de fora
      const timeMode = st.barType === 'time';
      const xForT = timeMode
        ? (t: number) => rightEdgeOfLast - ((tRefB - t) / tfMs) * v.candleW - v.candleW / 2
        : (t: number) => {
            // barra não-temporal: tempo → índice da barra contenedora (busca binária)
            let lo = 0;
            let hi = N - 1;
            let res = 0;
            while (lo <= hi) {
              const mid = (lo + hi) >> 1;
              if (candles[mid].t <= t) {
                res = mid;
                lo = mid + 1;
              } else hi = mid - 1;
            }
            return cxOf(res);
          };

      interface Bub { x: number; y: number; r: number; buy: boolean; big: boolean }
      const out: Bub[] = [];
      const minBub = st.bubbleMinVolume;
      let accKey = NaN;
      let accX = 0;
      let accLvl = 0;
      let accVol = 0;
      let accBuy = false;
      let accBig = false;
      const emit = () => {
        if (accVol <= 0 || accVol < minBub) return;
        const y = yOf(accLvl * tick);
        if (y < -14 || y > mainH + 14 || accX < -16 || accX > plotW + 16) return;
        out.push({
          x: accX,
          y,
          r: Math.min(14, Math.max(2, 1.5 + Math.sqrt(accVol) * 0.8)),
          buy: accBuy,
          big: accBig,
        });
      };
      if (st.showHeatBubbles && N > 0) {
        for (let i = 0; i < st.tape.length; i++) {
          const tr = st.tape[i]; // mais novos primeiro
          if (tr.t > tCut) continue; // replay: pula impressões futuras
          const x = xForT(tr.t);
          if (x < -30) break; // os demais são ainda mais antigos
          const lvl = Math.round(tr.p / tick);
          const buy = tr.side === 'buy';
          const key = lvl * 2 + (buy ? 1 : 0);
          if (key === accKey && Math.abs(x - accX) < 3) {
            accVol += tr.s;
            accBig = accBig || !!tr.big;
          } else {
            emit();
            accKey = key;
            accX = x;
            accLvl = lvl;
            accVol = tr.s;
            accBuy = buy;
            accBig = !!tr.big;
          }
        }
        emit();
        // bolhas: WebGL quando ativo; senão Canvas2D (radial gradient)
        if (glScene) {
          for (let i = out.length - 1; i >= 0; i--) {
            const bb = out[i];
            glScene.bubbles.push({
              x: bb.x,
              y: bb.y,
              r: bb.r,
              color: bb.buy ? GL_TEAL : GL_RED,
              alpha: 0.85,
              hollow: 0,
            });
            if (bb.big) {
              glScene.bubbles.push({
                x: bb.x,
                y: bb.y,
                r: bb.r + 1.5,
                color: GL_AMBER,
                alpha: 0.95,
                hollow: 1,
              });
            }
          }
        } else {
          // desenha do mais antigo p/ o mais novo (novos ficam por cima)
          for (let i = out.length - 1; i >= 0; i--) {
            const bb = out[i];
            const c = bb.buy ? TEAL : RED;
            const gr = ctx.createRadialGradient(bb.x, bb.y, 0, bb.x, bb.y, bb.r);
            gr.addColorStop(0, rgba(c, 0.85));
            gr.addColorStop(0.7, rgba(c, 0.45));
            gr.addColorStop(1, rgba(c, 0.08));
            ctx.fillStyle = gr;
            ctx.beginPath();
            ctx.arc(bb.x, bb.y, bb.r, 0, Math.PI * 2);
            ctx.fill();
            ctx.strokeStyle = rgba(c, 0.9);
            ctx.lineWidth = 1;
            ctx.stroke();
            if (bb.big) {
              ctx.strokeStyle = rgba(AMBER, 0.95);
              ctx.lineWidth = 1.4;
              ctx.beginPath();
              ctx.arc(bb.x, bb.y, bb.r + 1.5, 0, Math.PI * 2);
              ctx.stroke();
              ctx.lineWidth = 1;
            }
          }
        }
      }
    }

    // ── sinais de fluxo (motor MBO) ─────────────────────────────────────
    // absorção/exaustão: bolhas GL (ou halo 2D no fallback).
    // iceberg/spoofing: assinaturas 2D dedicadas (drawMboSignature) —
    // fusão Footprint×Heatmap com marcadores consistentes nos dois modos.
    if (st.showFlowSignals && st.flowSignals.length > 0 && N > 0) {
      const nowMs = Date.now();
      const tfMsS = TF_MS[st.tf];
      const tRefS = candles[N - 1].t;
      const xSig =
        st.barType === 'time'
          ? (t: number) => rightEdgeOfLast - ((tRefS - t) / tfMsS) * v.candleW - v.candleW / 2
          : (t: number) => {
              // barra não-temporal: tempo → índice da barra contenedora
              let lo = 0;
              let hi = N - 1;
              let res = 0;
              while (lo <= hi) {
                const mid = (lo + hi) >> 1;
                if (candles[mid].t <= t) {
                  res = mid;
                  lo = mid + 1;
                } else hi = mid - 1;
              }
              return cxOf(res);
            };
      let mboSigLive = false;
      for (const sig of st.flowSignals as FlowSignal[]) {
        if (sig.until <= nowMs) continue;
        const x = xSig(sig.t);
        if (x < -14 || x > plotW + 14) continue;
        const y = yOf(sig.priceIdx * tick);
        if (y < -12 || y > mainH + 12) continue;
        const pulse = 0.55 + 0.35 * Math.sin(nowMs / 200 + sig.id * 1.7);
        const col = signalColor(sig.kind);
        // assinaturas dedicadas: iceberg (◎) e spoofing (⊠) sempre em 2D
        if (sig.kind === 'iceberg' || sig.kind === 'spoof') {
          mboSigLive = true;
          drawMboSignature(ctx, sig.kind, x, y, pulse, sig.strength);
          continue;
        }
        if (glScene) {
          glScene.bubbles.push({
            x,
            y,
            r: 4 + 6 * sig.strength,
            color: col,
            alpha: 0.45 + 0.5 * pulse,
            hollow: 0,
          });
          glScene.bubbles.push({
            x,
            y,
            r: 8 + 9 * sig.strength,
            color: col,
            alpha: 0.22 * pulse,
            hollow: 1,
          });
        } else {
          // fallback 2D: disco + halo
          const c2 = `${Math.round(col[0] * 255)},${Math.round(col[1] * 255)},${Math.round(col[2] * 255)}`;
          const r1 = 4 + 6 * sig.strength;
          const gr2 = ctx.createRadialGradient(x, y, 0, x, y, r1 + 7);
          gr2.addColorStop(0, rgba(c2, 0.75 * pulse));
          gr2.addColorStop(0.55, rgba(c2, 0.35 * pulse));
          gr2.addColorStop(1, rgba(c2, 0));
          ctx.fillStyle = gr2;
          ctx.beginPath();
          ctx.arc(x, y, r1 + 7, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = rgba(c2, 0.9);
          ctx.beginPath();
          ctx.arc(x, y, r1, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = rgba('255,255,255', 0.65);
          ctx.beginPath();
          ctx.arc(x, y, r1, 0, Math.PI * 2);
          ctx.stroke();
        }
      }
      // legenda das assinaturas MBO (empilha sob heatmap/GEX quando ativas)
      if (mboSigLive) {
        const mtxt = 'assinaturas MBO: ◎ iceberg (execução oculta) · ⊠ spoofing (cancelamento)';
        ctx.font = FONT_MONO(9);
        const mw = ctx.measureText(mtxt).width + 12;
        const mby = 4 + (heatMode ? 20 : 0) + (st.showGexHeatmap || st.showGexFlip ? 22 : 0);
        ctx.fillStyle = '#101012';
        ctx.fillRect(4, mby, mw, 17);
        ctx.fillStyle = rgba('178,181,190', 0.92);
        ctx.textAlign = 'left';
        ctx.textBaseline = 'top';
        ctx.fillText(mtxt, 10, mby + 4);
      }
    }

    // ── heatmap de GEX (gamma líquido por strike) + gamma flip ─────────
    if ((st.showGexHeatmap || st.showGexFlip) && N > 0) {
      // spot: replay usa o close do playhead; ao vivo usa o último preço
      const spotGex = rep.active
        ? candles[N - 1].c
        : (st.session?.last ?? candles[N - 1].c);
      if (Number.isFinite(spotGex) && spotGex > 0) {
        const chain = buildChain(st.symbol, spotGex, 'flowterminal');
        if (chain.strikes.length > 0) {
          const stepG = strikeStep(st.symbol, tick);
          const rowsG = st.showGexHeatmap ? gexPerStrike(chain, tick) : [];
          let maxAbsG = 0;
          for (const r of rowsG) maxAbsG = Math.max(maxAbsG, Math.abs(r.net));
          if (maxAbsG > 0) {
            for (const r of rowsG) {
              const yTop = yOf(r.strike + stepG / 2);
              const yBot = yOf(r.strike - stepG / 2);
              const hh = Math.max(1, yBot - yTop);
              if (yBot < 0 || yTop > mainH) continue;
              const frac = Math.abs(r.net) / maxAbsG;
              const a = 0.03 + 0.11 * Math.sqrt(frac);
              ctx.fillStyle = rgba(r.net >= 0 ? TEAL : RED, a);
              ctx.fillRect(0, yTop, plotW, hh);
              if (frac > 0.55 && hh >= 3) {
                ctx.strokeStyle = rgba(r.net >= 0 ? TEAL : RED, 0.22);
                ctx.strokeRect(0.5, Math.round(yTop) + 0.5, plotW - 1, hh - 1);
              }
            }
            // legenda compacta (abaixo da do heatmap, quando ativa)
            const gtxt = 'GEX por strike: γ+ teal · γ− vermelho';
            ctx.font = FONT_MONO(9);
            const gw = ctx.measureText(gtxt).width + 12;
            const gy = heatMode ? 24 : 4;
            ctx.fillStyle = '#101012';
            ctx.fillRect(4, gy, gw, 17);
            ctx.fillStyle = rgba('178,181,190', 0.9);
            ctx.textAlign = 'left';
            ctx.textBaseline = 'top';
            ctx.fillText(gtxt, 10, gy + 4);
          }
          // linha do gamma flip (spot onde o GEX líquido cruza zero)
          if (st.showGexFlip) {
            const flip = flipSpot(chain, tick);
            if (flip !== null) {
              const yF = Math.round(yOf(flip)) + 0.5;
              if (yF > -2 && yF < mainH + 2) {
                ctx.strokeStyle = rgba('41,182,246', 0.75);
                ctx.setLineDash([8, 5]);
                ctx.lineWidth = 1.2;
                ctx.beginPath();
                ctx.moveTo(0, yF);
                ctx.lineTo(plotW, yF);
                ctx.stroke();
                ctx.setLineDash([]);
                ctx.lineWidth = 1;
                const lbl = `FLIP ${fmtPrice(flip, tick)}`;
                ctx.font = FONT_MONO(9, '700');
                const w = ctx.measureText(lbl).width + 10;
                const ly = Math.min(Math.max(4, yF - 17), mainH - 16);
                ctx.fillStyle = 'rgba(15,34,51,0.92)';
                ctx.fillRect(4, ly, w, 14);
                ctx.strokeStyle = rgba('41,182,246', 0.8);
                ctx.strokeRect(4.5, ly + 0.5, w - 1, 13);
                ctx.fillStyle = 'rgba(166,229,255,0.98)';
                ctx.textAlign = 'left';
                ctx.textBaseline = 'middle';
                ctx.fillText(lbl, 9, ly + 7);
              }
            }
          }
        }
      }
    }

    // ── ladder de profundidade (book atual) na borda direita — todos os modos ─
    if (st.showDepthLadder && st.dom) {
      const hrL = Math.max(1, Math.ceil(3 / Math.max(rowH, 0.02)));
      const LW = Math.max(64, Math.min(96, plotW * 0.26));
      const lx = plotW - LW;
      const priceColW = Math.max(44, Math.min(54, LW * 0.56));
      const sideW = (LW - priceColW) / 2;
      const bidEdge = lx + sideW; // barras bid crescem p/ a esquerda a partir daqui
      const askEdge = plotW - sideW; // barras ask crescem p/ a direita a partir daqui
      const barW = Math.max(8, sideW - 2);

      ctx.fillStyle = '#101012';
      ctx.fillRect(lx, 0, LW, mainH);
      ctx.strokeStyle = rgba(GRID, 0.9);
      ctx.beginPath();
      ctx.moveTo(Math.round(lx) + 0.5, 0);
      ctx.lineTo(Math.round(lx) + 0.5, mainH);
      ctx.stroke();

      // agrupa por blocos de hr ticks — mesmas linhas do heatmap
      const bidMap = new Map<number, number>();
      for (const d of st.dom.bids) {
        const gi = Math.floor(Math.round(d.p / tick) / hrL);
        if (d.s > (bidMap.get(gi) ?? 0)) bidMap.set(gi, d.s);
      }
      const askMap = new Map<number, number>();
      for (const d of st.dom.asks) {
        const gi = Math.floor(Math.round(d.p / tick) / hrL);
        if (d.s > (askMap.get(gi) ?? 0)) askMap.set(gi, d.s);
      }
      let maxSz = 0;
      for (const s of bidMap.values()) maxSz = Math.max(maxSz, s);
      for (const s of askMap.values()) maxSz = Math.max(maxSz, s);

      if (maxSz > 0) {
        const G0 = Math.floor(Math.ceil(priceBot / tick) / hrL);
        const G1 = Math.floor(Math.floor(priceTop / tick) / hrL);
        for (let gi = G0; gi <= G1; gi++) {
          const yTop = yOf((gi + 1) * hrL * tick);
          const yBot = yOf(gi * hrL * tick);
          const rhRaw = yBot - yTop;
          const rh = Math.max(1, rhRaw - (rhRaw > 5 ? 1 : 0));
          if (yBot < 0 || yTop > mainH) continue;
          const b = bidMap.get(gi) ?? 0;
          const a = askMap.get(gi) ?? 0;
          if (b > 0) {
            const w = Math.max(3, Math.min(barW, (b / maxSz) * barW));
            ctx.fillStyle = rgba(TEAL, 0.62);
            ctx.fillRect(bidEdge - w, yTop, w, rh);
          }
          if (a > 0) {
            const w = Math.max(3, Math.min(barW, (a / maxSz) * barW));
            ctx.fillStyle = rgba(RED, 0.62);
            ctx.fillRect(askEdge, yTop, w, rh);
          }
          if (rhRaw >= 11) {
            ctx.font = FONT_MONO(9);
            ctx.textBaseline = 'middle';
            const yMid = (yTop + yBot) / 2;
            if (b > 0) {
              ctx.fillStyle = rgba(TEAL, 0.95);
              ctx.textAlign = 'right';
              ctx.fillText(fmtSize(b, meta.sizeDecimals), bidEdge - 3, yMid);
            }
            if (a > 0) {
              ctx.fillStyle = rgba(RED, 0.95);
              ctx.textAlign = 'left';
              ctx.fillText(fmtSize(a, meta.sizeDecimals), askEdge + 3, yMid);
            }
            if (rhRaw >= 13) {
              ctx.fillStyle = rgba('120,123,134', 0.9);
              ctx.textAlign = 'center';
              ctx.fillText(fmtPrice(gi * hrL * tick, tick), (bidEdge + askEdge) / 2, yMid);
            }
          }
        }
      }
    }

    // ── desenhos do usuário (ferramentas) + rascunho em criação ──────────
    {
      const dKey = `${st.symbol}|${st.tf}`;
      const objs = useDrawingStore.getState().items[dKey] ?? [];
      const draft = draftRef.current;
      const preview = previewRef.current;

      const drawOne = (obj: DrawObj, isPrev: boolean) => {
        const col = isPrev ? '209,212,220' : DRAW_RGB;
        const alpha = isPrev ? 0.7 : 0.95;
        ctx.strokeStyle = rgba(col, alpha);
        ctx.fillStyle = rgba(col, alpha * 0.12);
        ctx.lineWidth = 1.4;
        if (isPrev) ctx.setLineDash([5, 4]);
        const a = obj.pts[0];
        const b = obj.pts[1];
        const p1 = a ? { x: cxOf(a.i), y: yOf(a.p) } : null;
        const p2 = b ? { x: cxOf(b.i), y: yOf(b.p) } : null;

        switch (obj.kind) {
          case 'hline': {
            if (!p1 || !a) break;
            const y = Math.round(p1.y) + 0.5;
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(plotW, y);
            ctx.stroke();
            const lbl = fmtPrice(a.p, tick);
            ctx.font = FONT_MONO(9, '700');
            const w = ctx.measureText(lbl).width + 8;
            ctx.fillStyle = rgba(col, isPrev ? 0.5 : 0.9);
            ctx.fillRect(plotW - w - 2, y - 7, w, 14);
            ctx.fillStyle = 'rgba(255,255,255,0.97)';
            ctx.textAlign = 'left';
            ctx.textBaseline = 'middle';
            ctx.fillText(lbl, plotW - w, y);
            break;
          }
          case 'hray': {
            if (!p1) break;
            const y = Math.round(p1.y) + 0.5;
            ctx.beginPath();
            ctx.moveTo(Math.max(0, p1.x), y);
            ctx.lineTo(plotW, y);
            ctx.stroke();
            break;
          }
          case 'vline': {
            if (!p1) break;
            const x = Math.round(p1.x) + 0.5;
            ctx.beginPath();
            ctx.moveTo(x, 0);
            ctx.lineTo(x, mainH);
            ctx.stroke();
            break;
          }
          case 'trend':
          case 'arrow': {
            if (!p1 || !p2) break;
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
            if (obj.kind === 'arrow') {
              const ang = Math.atan2(p2.y - p1.y, p2.x - p1.x);
              const hl = 8;
              ctx.beginPath();
              ctx.moveTo(p2.x, p2.y);
              ctx.lineTo(p2.x - hl * Math.cos(ang - Math.PI / 7), p2.y - hl * Math.sin(ang - Math.PI / 7));
              ctx.lineTo(p2.x - hl * Math.cos(ang + Math.PI / 7), p2.y - hl * Math.sin(ang + Math.PI / 7));
              ctx.closePath();
              ctx.fillStyle = rgba(col, alpha);
              ctx.fill();
            }
            break;
          }
          case 'rect': {
            if (!p1 || !p2) break;
            const rx = Math.min(p1.x, p2.x);
            const ry = Math.min(p1.y, p2.y);
            ctx.fillRect(rx, ry, Math.abs(p2.x - p1.x), Math.abs(p2.y - p1.y));
            ctx.strokeRect(rx + 0.5, ry + 0.5, Math.abs(p2.x - p1.x), Math.abs(p2.y - p1.y));
            break;
          }
          case 'ellipse': {
            if (!p1 || !p2) break;
            ctx.beginPath();
            ctx.ellipse(
              (p1.x + p2.x) / 2,
              (p1.y + p2.y) / 2,
              Math.abs(p2.x - p1.x) / 2,
              Math.abs(p2.y - p1.y) / 2,
              0,
              0,
              Math.PI * 2,
            );
            ctx.fill();
            ctx.stroke();
            break;
          }
          case 'triangle': {
            if (!p1 || !p2) break;
            ctx.beginPath();
            ctx.moveTo((p1.x + p2.x) / 2, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.lineTo(p1.x, p2.y);
            ctx.closePath();
            ctx.fill();
            ctx.stroke();
            break;
          }
          case 'fib': {
            if (!p1 || !p2 || !a || !b) break;
            const x0 = Math.min(p1.x, p2.x);
            const x1 = Math.max(p1.x, p2.x);
            const hiP = Math.max(a.p, b.p);
            const loP = Math.min(a.p, b.p);
            ctx.font = FONT_MONO(9, '600');
            ctx.textAlign = 'left';
            ctx.textBaseline = 'bottom';
            for (let ri = 0; ri < FIB_RATIOS.length; ri++) {
              const r = FIB_RATIOS[ri];
              const price = hiP - (hiP - loP) * r;
              const y = Math.round(yOf(price)) + 0.5;
              const colF = ri === 0 || ri === FIB_RATIOS.length - 1 ? AMBER : DRAW_RGB;
              ctx.strokeStyle = rgba(colF, isPrev ? 0.5 : 0.75);
              ctx.beginPath();
              ctx.moveTo(x0, y);
              ctx.lineTo(x1, y);
              ctx.stroke();
              if (ri > 0) {
                const prevR = FIB_RATIOS[ri - 1];
                const yPrev = yOf(hiP - (hiP - loP) * prevR);
                ctx.fillStyle = rgba(colF, 0.05);
                ctx.fillRect(x0, Math.min(y, yPrev), x1 - x0, Math.abs(y - yPrev));
              }
              if (!isPrev && x1 - x0 > 46) {
                ctx.fillStyle = rgba(colF, 0.95);
                ctx.fillText(`${(r * 100).toFixed(1)}% ${fmtPrice(price, tick)}`, x0 + 3, y - 1);
              }
            }
            break;
          }
          case 'fibext': {
            // extensões de Fibonacci: projeta além da âncora b os múltiplos
            // do swing a→b (0% = b, 100% = 1× o swing, 261.8% …)
            if (!p1 || !p2 || !a || !b) break;
            const x0e = Math.min(p1.x, p2.x);
            const x1e = Math.max(p1.x, p2.x);
            ctx.font = FONT_MONO(9, '600');
            ctx.textAlign = 'right';
            ctx.textBaseline = 'bottom';
            for (let ri = 0; ri < FIB_EXT_RATIOS.length; ri++) {
              const r = FIB_EXT_RATIOS[ri];
              const price = b.p + (b.p - a.p) * r;
              const y = Math.round(yOf(price)) + 0.5;
              const colF = r === 0 || r === 1 ? AMBER : DRAW_RGB;
              ctx.strokeStyle = rgba(colF, isPrev ? 0.5 : 0.75);
              ctx.beginPath();
              ctx.moveTo(x0e, y);
              ctx.lineTo(x1e, y);
              ctx.stroke();
              if (ri > 0 && r !== 1) {
                const prevPrice = b.p + (b.p - a.p) * FIB_EXT_RATIOS[ri - 1];
                const yPrev = yOf(prevPrice);
                ctx.fillStyle = rgba(colF, 0.05);
                ctx.fillRect(x0e, Math.min(y, yPrev), x1e - x0e, Math.abs(y - yPrev));
              }
              if (!isPrev && x1e - x0e > 46) {
                ctx.fillStyle = rgba(colF, 0.95);
                ctx.fillText(`${(r * 100).toFixed(1)}% ${fmtPrice(price, tick)}`, x1e - 3, y - 1);
              }
            }
            // linha base do swing (a→b) tracejada
            ctx.setLineDash([4, 3]);
            ctx.strokeStyle = rgba(col, isPrev ? 0.5 : 0.6);
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
            ctx.setLineDash(isPrev ? [5, 4] : []);
            break;
          }
          case 'rrisk': {
            // Risco/Retorno: a = entrada, b = stop. Zona de risco (vermelho),
            // zona de alvo 1:RR (teal) e linhas 1:1 / 1:RR / 1:3 projetadas
            // até a borda direita. Direção: 'long' se o stop está abaixo.
            if (!p1 || !p2 || !a || !b) break;
            const dir = obj.dir ?? (b.p < a.p ? 'long' : 'short');
            const sgn = dir === 'long' ? 1 : -1;
            const risk = Math.abs(a.p - b.p);
            if (risk <= 0) break;
            const rr = obj.rr && obj.rr > 0 ? obj.rr : 2;
            const xa = Math.min(p1.x, p2.x);
            const yEntry = p1.y;
            const yStop = p2.y;
            const riskTop = Math.min(yEntry, yStop);
            const riskBot = Math.max(yEntry, yStop);
            const wide = plotW - xa > 60;
            // zona de alvo (entrada → 1:RR) — teal
            const yT = yOf(a.p + sgn * risk * rr);
            ctx.fillStyle = rgba(TEAL, 0.08);
            ctx.fillRect(xa, Math.min(yEntry, yT), plotW - xa, Math.abs(yT - yEntry));
            // zona de risco (entrada → stop) — vermelho
            ctx.fillStyle = rgba(RED, 0.1);
            ctx.fillRect(xa, riskTop, plotW - xa, riskBot - riskTop);
            if (!isPrev && wide) {
              ctx.font = FONT_MONO(9, '700');
              ctx.textAlign = 'left';
              ctx.fillStyle = rgba(TEAL, 0.9);
              ctx.textBaseline = 'top';
              ctx.fillText(
                `alvo 1:${rr} ${fmtPrice(a.p + sgn * risk * rr, tick)} (${fmtSignedCompact(sgn * risk * rr)})`,
                xa + 4,
                Math.min(yEntry, yT) + 2,
              );
              ctx.fillStyle = rgba(RED, 0.9);
              ctx.textBaseline = 'bottom';
              ctx.fillText(
                `risco ${(risk / tick).toFixed(0)}t ${fmtPrice(b.p, tick)}`,
                xa + 4,
                riskBot - 1,
              );
            }
            ctx.setLineDash([4, 3]);
            const rrLine = (
              price: number,
              colStr: string,
              alpha: number,
              lbl: string,
              strong: boolean,
            ) => {
              const y = Math.round(yOf(price)) + 0.5;
              ctx.strokeStyle = rgba(colStr, alpha);
              ctx.lineWidth = strong ? 1.4 : 1;
              ctx.beginPath();
              ctx.moveTo(xa, y);
              ctx.lineTo(plotW, y);
              ctx.stroke();
              ctx.lineWidth = 1;
              if (!isPrev && wide) {
                ctx.font = FONT_MONO(9, '600');
                ctx.textAlign = 'left';
                ctx.textBaseline = 'bottom';
                ctx.fillStyle = rgba(colStr, Math.min(1, alpha + 0.2));
                ctx.fillText(lbl, xa + 4, y - 1);
              }
            };
            rrLine(b.p, RED, isPrev ? 0.5 : 0.85, `stop ${fmtPrice(b.p, tick)}`, false);
            rrLine(
              a.p,
              STEEL,
              isPrev ? 0.5 : 0.95,
              `entrada ${fmtPrice(a.p, tick)} · ${dir === 'long' ? 'LONG' : 'SHORT'}`,
              true,
            );
            rrLine(a.p + sgn * risk, TEAL, isPrev ? 0.4 : 0.6, '1:1', false);
            rrLine(a.p + sgn * risk * rr, TEAL, isPrev ? 0.5 : 0.9, `1:${rr}`, true);
            rrLine(a.p + sgn * risk * 3, TEAL, isPrev ? 0.4 : 0.5, '1:3', false);
            ctx.setLineDash(isPrev ? [5, 4] : []);
            break;
          }
          case 'vprof': {
            // Fixed Range Volume Profile: histograma horizontal agregado no
            // range temporal desenhado (âncoras i), com POC + Value Area 70%.
            // Agregação cacheada por objeto — key inclui dataVersion/zoom/keys.
            if (!p1 || !p2 || !a || !b) break;
            const i0 = Math.floor(Math.min(a.i, b.i));
            const i1 = Math.ceil(Math.max(a.i, b.i));
            const pLo = Math.min(a.p, b.p);
            const pHi = Math.max(a.p, b.p);
            const rx = Math.min(p1.x, p2.x);
            const ry = Math.min(p1.y, p2.y);
            const rw = Math.abs(p2.x - p1.x);
            const rh = Math.abs(p2.y - p1.y);
            if (N > 0 && i1 >= i0 && pHi > pLo) {
              const ck = `${st.symbol}|${st.tf}|${st.barType}|${st.dataVersion}|${i0}|${i1}|${g}`;
              let cached = vprofCacheRef.current.get(obj.id);
              if (!cached || cached.key !== ck) {
                cached = { key: ck, prof: buildRangeProfile(candles, i0, i1, g) };
                if (vprofCacheRef.current.size > 12) vprofCacheRef.current.clear();
                vprofCacheRef.current.set(obj.id, cached);
              }
              const prof = cached.prof;
              if (prof.rows.length > 0 && prof.pocV > 0) {
                let pocRow = prof.rows[0];
                for (const r of prof.rows) if (r.v > pocRow.v) pocRow = r;
                const sortedP = [...prof.rows].sort((x, y) => y.v - x.v);
                let acc = 0;
                let vah = pocRow.hi;
                let val = pocRow.lo;
                for (const r of sortedP) {
                  acc += r.v;
                  vah = Math.max(vah, r.hi);
                  val = Math.min(val, r.lo);
                  if (acc >= prof.total * 0.7) break;
                }
                const xStart = obj.extend ? 0 : rx;
                const profW = Math.min(130, Math.max(36, plotW * 0.24));
                for (const r of prof.rows) {
                  const yTop = yOf(r.hi * tick + tick / 2);
                  const yBot = yOf(r.lo * tick - tick / 2);
                  if (yBot < 0 || yTop > mainH) continue;
                  const len = (r.v / prof.pocV) * profW;
                  const inVA = r.hi >= val && r.lo <= vah;
                  ctx.fillStyle =
                    r === pocRow ? rgba(AMBER, 0.72) : rgba(STEEL, inVA ? 0.52 : 0.22);
                  ctx.fillRect(xStart, yTop + 0.5, Math.max(1, len), Math.max(1, yBot - yTop - 1));
                }
                // POC + limites da Value Area (limitados ao perfil)
                const yPoc = Math.round(yOf(pocRow.hi * tick)) + 0.5;
                ctx.strokeStyle = rgba(STEEL, isPrev ? 0.5 : 0.9);
                ctx.setLineDash([6, 4]);
                ctx.beginPath();
                ctx.moveTo(xStart, yPoc);
                ctx.lineTo(xStart + profW, yPoc);
                ctx.stroke();
                ctx.strokeStyle = rgba(AMBER, isPrev ? 0.35 : 0.5);
                ctx.setLineDash([2, 4]);
                for (const lvl of [vah * tick, val * tick]) {
                  const y = Math.round(yOf(lvl)) + 0.5;
                  if (y < -2 || y > mainH + 2) continue;
                  ctx.beginPath();
                  ctx.moveTo(xStart, y);
                  ctx.lineTo(xStart + profW, y);
                  ctx.stroke();
                }
                ctx.setLineDash(isPrev ? [5, 4] : []);
                if (!isPrev && profW > 46) {
                  ctx.font = FONT_MONO(9, '700');
                  ctx.textAlign = 'left';
                  ctx.textBaseline = 'bottom';
                  ctx.fillStyle = rgba(STEEL, 0.95);
                  ctx.fillText(
                    `VP ${fmtCompact(prof.total)} · POC ${fmtPrice(pocRow.hi * tick, tick)}`,
                    xStart + 2,
                    Math.max(9, Math.min(yPoc, yOf(pHi)) - 3),
                  );
                }
              }
            }
            // contorno do range selecionado (sempre visível)
            ctx.strokeStyle = rgba(col, isPrev ? 0.5 : 0.8);
            ctx.setLineDash([5, 4]);
            ctx.strokeRect(rx + 0.5, ry + 0.5, rw, rh);
            ctx.setLineDash([]);
            break;
          }
          case 'ruler': {
            if (!p1 || !p2 || !a || !b) break;
            ctx.setLineDash([4, 3]);
            ctx.beginPath();
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
            ctx.setLineDash([]);
            const barsN = Math.abs(b.i - a.i);
            const ticksN = Math.abs(b.p - a.p) / tick;
            const txt = `${barsN} barras · ${fmtSignedCompact(b.p - a.p)} (${ticksN.toFixed(0)} ticks)`;
            ctx.font = FONT_MONO(10, '700');
            const tw = ctx.measureText(txt).width + 12;
            const mx = (p1.x + p2.x) / 2;
            const my = (p1.y + p2.y) / 2;
            ctx.fillStyle = rgba(b.p >= a.p ? TEAL : RED, 0.92);
            ctx.fillRect(mx - tw / 2, my - 18, tw, 15);
            ctx.fillStyle = 'rgba(255,255,255,0.97)';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(txt, mx, my - 10);
            break;
          }
          case 'range': {
            // canal de range: duas linhas horizontais (topo/fundo) + preenchimento
            // + linha média tracejada + etiqueta com amplitude em ticks
            if (!p1 || !p2 || !a || !b) break;
            const yA = p1.y;
            const yB = p2.y;
            const x0 = obj.extend ? 0 : Math.min(p1.x, p2.x);
            const x1 = obj.extend ? plotW : Math.max(p1.x, p2.x);
            ctx.fillStyle = rgba(col, alpha * 0.08);
            ctx.fillRect(x0, Math.min(yA, yB), x1 - x0, Math.abs(yB - yA));
            const ya = Math.round(yA) + 0.5;
            const yb = Math.round(yB) + 0.5;
            ctx.beginPath();
            ctx.moveTo(x0, ya);
            ctx.lineTo(x1, ya);
            ctx.moveTo(x0, yb);
            ctx.lineTo(x1, yb);
            ctx.stroke();
            const ym = Math.round((yA + yB) / 2) + 0.5;
            ctx.setLineDash([4, 4]);
            ctx.strokeStyle = rgba(col, alpha * 0.5);
            ctx.beginPath();
            ctx.moveTo(x0, ym);
            ctx.lineTo(x1, ym);
            ctx.stroke();
            ctx.setLineDash(isPrev ? [5, 4] : []);
            const hiP = Math.max(a.p, b.p);
            const loP = Math.min(a.p, b.p);
            const lbl = `range ${fmtPrice(loP, tick)}–${fmtPrice(hiP, tick)} · ${((hiP - loP) / tick).toFixed(0)}t`;
            ctx.font = FONT_MONO(9, '700');
            const lw = ctx.measureText(lbl).width + 8;
            const ly = Math.min(ya, yb) - 14;
            ctx.fillStyle = rgba(col, isPrev ? 0.5 : 0.85);
            ctx.fillRect(x0 + 2, ly, lw, 13);
            ctx.fillStyle = 'rgba(255,255,255,0.97)';
            ctx.textAlign = 'left';
            ctx.textBaseline = 'middle';
            ctx.fillText(lbl, x0 + 6, ly + 7);
            break;
          }
          case 'mlevel': {
            // níveis matemáticos: âncora (âmbar) ± k níveis equidistantes,
            // passo definido pela distância entre os dois pontos
            if (!p1 || !p2 || !a || !b) break;
            const step = Math.abs(b.p - a.p) || tick;
            const k = obj.levels ?? 3;
            const x0 = obj.extend ? 0 : Math.min(p1.x, p2.x);
            const x1 = obj.extend ? plotW : Math.max(p1.x, p2.x);
            ctx.font = FONT_MONO(9, '600');
            ctx.textAlign = 'left';
            ctx.textBaseline = 'bottom';
            for (let n = -k; n <= k; n++) {
              if (n === 0) continue; // âncora desenhada à parte
              const price = a.p + n * step;
              const y = Math.round(yOf(price)) + 0.5;
              if (y < -4 || y > mainH + 4) continue;
              ctx.strokeStyle = rgba(col, alpha * (Math.abs(n) === 1 ? 0.85 : 0.5));
              ctx.setLineDash(Math.abs(n) === 1 ? [] : [6, 4]);
              ctx.beginPath();
              ctx.moveTo(x0, y);
              ctx.lineTo(x1, y);
              ctx.stroke();
              ctx.setLineDash(isPrev ? [5, 4] : []);
              if (!isPrev && x1 - x0 > 46) {
                ctx.fillStyle = rgba(col, 0.95);
                ctx.fillText(`${n > 0 ? '+' : ''}${n}·${fmtPrice(price, tick)}`, x0 + 3, y - 1);
              }
            }
            const y0 = Math.round(p1.y) + 0.5;
            ctx.strokeStyle = rgba(AMBER, isPrev ? 0.6 : 0.9);
            ctx.beginPath();
            ctx.moveTo(x0, y0);
            ctx.lineTo(x1, y0);
            ctx.stroke();
            if (!isPrev && x1 - x0 > 46) {
              ctx.fillStyle = rgba(AMBER, 0.97);
              ctx.fillText(`0·${fmtPrice(a.p, tick)}`, x0 + 3, y0 - 1);
            }
            break;
          }
          case 'text': {
            if (!p1 || !obj.text) break;
            ctx.font = FONT_MONO(11, '600');
            ctx.textAlign = 'left';
            ctx.textBaseline = 'middle';
            ctx.fillStyle = rgba(col, 0.9);
            ctx.beginPath();
            ctx.arc(p1.x, p1.y, 2.2, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = 'rgba(240,241,244,0.97)';
            ctx.fillText(obj.text, p1.x + 6, p1.y);
            break;
          }
        }
        ctx.setLineDash([]);
        ctx.lineWidth = 1;
      };

      /** handles de manipulação (quadrados nas âncoras) do objeto ativo/hover */
      const drawHandles = (obj: DrawObj, override?: DrawPt[]) => {
        const pts = override ?? obj.pts;
        ctx.fillStyle = 'rgba(24,24,27,0.9)';
        ctx.strokeStyle = 'rgba(240,241,244,0.95)';
        ctx.lineWidth = 1.2;
        for (const p of pts) {
          // posição do handle por kind: linhas horizontais ancoram na borda
          // direita, verticais no rodapé; demais no ponto de dados
          let hx: number;
          let hy: number;
          if (obj.kind === 'hline' || obj.kind === 'hray') {
            hx = plotW - 44;
            hy = yOf(p.p);
          } else if (obj.kind === 'vline') {
            hx = cxOf(p.i);
            hy = mainH - 16;
          } else {
            hx = cxOf(p.i);
            hy = yOf(p.p);
          }
          if (!Number.isFinite(hx) || !Number.isFinite(hy)) continue;
          ctx.beginPath();
          ctx.rect(hx - 3, hy - 3, 6, 6);
          ctx.fill();
          ctx.stroke();
        }
        ctx.lineWidth = 1;
      };

      const drag = drawDragRef.current;
      const hover = drawHoverRef.current;
      for (const obj of objs) {
        if (drag && drag.id === obj.id && drag.key === dKey) {
          drawOne({ ...obj, pts: drag.pts }, false);
          drawHandles(obj, drag.pts);
        } else {
          drawOne(obj, false);
          if (hover && hover.id === obj.id && activeTool === 'crosshair') {
            drawHandles(obj);
          }
        }
      }
      if (draft) {
        const pts = preview && draft.pts.length === 1 ? [draft.pts[0], preview] : draft.pts;
        drawOne({ id: 'draft', kind: draft.kind, pts }, true);
      }
    }

    ctx.restore(); // fim clip plot

    // ── painel de delta ──────────────────────────────────────────────────
    if (showDelta) {
      const top = mainH;
      ctx.fillStyle = 'rgba(0,0,0,0.28)';
      ctx.fillRect(0, top, plotW, paneH);
      ctx.strokeStyle = rgba(GRID, 0.9);
      ctx.beginPath();
      ctx.moveTo(0, top + 0.5);
      ctx.lineTo(plotW, top + 0.5);
      ctx.stroke();

      ctx.save();
      ctx.beginPath();
      ctx.rect(0, top, plotW, paneH);
      ctx.clip();

      const stripY = top + paneH - STRIP_H;
      const histH = STRIP_H > 0 ? paneH - STRIP_H : paneH;

      // delta acumulado (CVD)
      const cum: number[] = [];
      let run = 0;
      for (const c of candles) {
        run += c.d;
        cum.push(run);
      }
      let cMin = Infinity;
      let cMax = -Infinity;
      for (let i = Math.max(0, firstVisible); i <= lastVisible && i < N; i++) {
        cMin = Math.min(cMin, cum[i]);
        cMax = Math.max(cMax, cum[i]);
      }
      if (isFinite(cMin) && isFinite(cMax)) {
        if (cMax - cMin < 1) {
          cMax += 1;
          cMin -= 1;
        }
        const padD = (cMax - cMin) * 0.12;
        cMin -= padD;
        cMax += padD;
        const cy = (val: number) => top + 6 + ((cMax - val) / (cMax - cMin)) * (histH - 12);
        // linha do zero
        const yZero = Math.round(cy(0)) + 0.5;
        if (yZero > top && yZero < top + histH) {
          ctx.strokeStyle = rgba(GRID, 0.8);
          ctx.beginPath();
          ctx.moveTo(0, yZero);
          ctx.lineTo(plotW, yZero);
          ctx.stroke();
        }
        ctx.strokeStyle = rgba('209,212,220', 0.85);
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        for (let i = Math.max(0, firstVisible); i <= lastVisible && i < N; i++) {
          const x = cxOf(i);
          if (i === Math.max(0, firstVisible)) ctx.moveTo(x, cy(cum[i]));
          else ctx.lineTo(x, cy(cum[i]));
        }
        ctx.stroke();
        ctx.lineWidth = 1;
      }

      // histograma de delta por vela (azul/vermelho ATAS)
      let maxAbs = 0;
      for (const c of vis) maxAbs = Math.max(maxAbs, Math.abs(c.d));
      if (maxAbs > 0) {
        const base = top + histH / 2;
        const bw = Math.max(1, v.candleW - 4);
        for (let k = 0; k < vis.length; k++) {
          const c = vis[k];
          const x = cxOf(firstVisible + k) - bw / 2;
          const bh = (Math.abs(c.d) / maxAbs) * (histH / 2 - 6);
          ctx.fillStyle = c.d >= 0 ? rgba(BLUE, 0.8) : rgba(RED, 0.8);
          ctx.fillRect(x, c.d >= 0 ? base - bh : base, bw, Math.max(1, bh));
        }
      }

      // rótulos do painel
      ctx.fillStyle = rgba(TXT, 0.7);
      ctx.font = FONT_MONO(9);
      ctx.textAlign = 'left';
      ctx.textBaseline = 'top';
      ctx.fillText('Δ vela · CVD', 6, top + 3);
      if (cum.length) {
        const lastCum = cum[Math.min(lastVisible, N - 1)];
        ctx.font = FONT_MONO(10, '700');
        ctx.textAlign = 'right';
        ctx.textBaseline = 'top';
        ctx.fillStyle = lastCum >= 0 ? rgba(BLUE, 1) : rgba(RED, 1);
        ctx.fillText(fmtSignedCompact(lastCum), plotW - 6, top + 3);
      }

      // faixa bid|ask por vela (rodapé do painel, estilo ATAS)
      ctx.fillStyle = 'rgba(0,0,0,0.3)';
      ctx.fillRect(0, stripY, plotW, STRIP_H);
      const stripH2 = STRIP_H - 2;
      for (let k = 0; k < vis.length; k++) {
        const c = vis[k];
        const x = cxOf(firstVisible + k) - v.candleW / 2;
        const w = v.candleW;
        const tot = c.v;
        if (tot <= 0) continue;
        // split b/a aproximado pelo delta conhecido: b=(v-d)/2, a=(v+d)/2
        const b = Math.max(0, (tot - c.d) / 2);
        const a = Math.max(0, tot - b);
        const bw = (b / tot) * w;
        ctx.fillStyle = rgba(RED, 0.85);
        ctx.fillRect(x, stripY + 1, bw, stripH2);
        ctx.fillStyle = rgba(TEAL, 0.85);
        ctx.fillRect(x + bw, stripY + 1, w - bw, stripH2);
        if (w >= 46) {
          ctx.font = FONT_MONO(9, '700');
          ctx.fillStyle = 'rgba(255,255,255,0.95)';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(`${fmtCompact(tot)}L`, x + w / 2, stripY + 1 + stripH2 / 2, w - 4);
        }
      }
      ctx.restore();
    }

    // ── painel de RSI (14) ──────────────────────────────────────────────
    if (st.showRSI) {
      const topR = mainH + (showDelta ? PANE_H : 0);
      ctx.fillStyle = 'rgba(0,0,0,0.28)';
      ctx.fillRect(0, topR, plotW, rsiH);
      ctx.strokeStyle = rgba(GRID, 0.9);
      ctx.beginPath();
      ctx.moveTo(0, topR + 0.5);
      ctx.lineTo(plotW, topR + 0.5);
      ctx.stroke();

      ctx.save();
      ctx.beginPath();
      ctx.rect(0, topR, plotW, rsiH);
      ctx.clip();

      const hIn = rsiH - 12;
      const yR = (val: number) => topR + 6 + (1 - val / 100) * hIn;
      // guias 70/50/30
      ctx.setLineDash([3, 3]);
      const guides: [number, string, number][] = [
        [70, RED, 0.4],
        [50, GRID, 0.85],
        [30, TEAL, 0.4],
      ];
      for (const [lvl, col, a] of guides) {
        const y = Math.round(yR(lvl)) + 0.5;
        ctx.strokeStyle = rgba(col, a);
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(plotW, y);
        ctx.stroke();
      }
      ctx.setLineDash([]);

      const series = rsi(candles, 14);
      ctx.strokeStyle = rgba(STEEL, 0.95);
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      let startedR = false;
      let lastValR = NaN;
      for (let i = Math.max(0, firstVisible); i <= lastVisible && i < N; i++) {
        const val = series[i];
        if (!Number.isFinite(val)) continue;
        lastValR = val;
        const x = cxOf(i);
        const y = yR(val);
        if (!startedR) {
          ctx.moveTo(x, y);
          startedR = true;
        } else ctx.lineTo(x, y);
      }
      ctx.stroke();
      ctx.lineWidth = 1;

      ctx.fillStyle = rgba(TXT, 0.7);
      ctx.font = FONT_MONO(9);
      ctx.textAlign = 'left';
      ctx.textBaseline = 'top';
      ctx.fillText('RSI 14', 6, topR + 3);
      if (Number.isFinite(lastValR)) {
        ctx.font = FONT_MONO(10, '700');
        ctx.textAlign = 'right';
        ctx.fillStyle =
          lastValR >= 70 ? rgba(RED, 1) : lastValR <= 30 ? rgba(TEAL, 1) : rgba('209,212,220', 0.95);
        ctx.fillText(lastValR.toFixed(1), plotW - 6, topR + 3);
      }
      ctx.restore();
    }

    // ── eixo de preços (direita) ─────────────────────────────────────────
    ctx.fillStyle = BG;
    ctx.fillRect(plotW, 0, AXIS_W, mainH);
    ctx.strokeStyle = rgba(GRID, 0.9);
    ctx.beginPath();
    ctx.moveTo(plotW + 0.5, 0);
    ctx.lineTo(plotW + 0.5, H - TIME_AXIS_H);
    ctx.stroke();
    ctx.font = FONT_MONO(10);
    ctx.fillStyle = rgba('209,212,220', 0.8);
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    for (let p = Math.ceil(priceBot / step) * step; p <= priceTop; p += step) {
      const y = yOf(p);
      if (y < 8 || y > mainH - 4) continue;
      ctx.fillText(fmtPrice(p, tick), plotW + 6, y);
    }

    // linha/chips do último preço + best bid/ask
    const last = rep.active ? candles[N - 1].c : (st.session?.last ?? candles[N - 1].c);
    const yLast = yOf(last);
    if (yLast >= 0 && yLast <= mainH) {
      clipPlot();
      ctx.strokeStyle = rgba(STEEL, 0.8);
      ctx.setLineDash([2, 3]);
      ctx.beginPath();
      ctx.moveTo(0, Math.round(yLast) + 0.5);
      ctx.lineTo(plotW, Math.round(yLast) + 0.5);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();
      const chip = (p: number, bg: string, bold: boolean) => {
        const y = yOf(p);
        if (y < 8 || y > mainH - 8) return;
        ctx.fillStyle = bg;
        ctx.fillRect(plotW + 1, y - 8, AXIS_W - 2, 16);
        ctx.fillStyle = 'rgba(255,255,255,0.97)';
        ctx.font = FONT_MONO(10, bold ? '700' : '600');
        ctx.fillText(fmtPrice(p, tick), plotW + 6, y);
      };
      if (st.dom) {
        // melhor ask = menor preço (array DESC); melhor bid = maior preço
        if (st.dom.asks.length) chip(st.dom.asks[st.dom.asks.length - 1].p, rgba(RED, 0.95), false);
        if (st.dom.bids.length) chip(st.dom.bids[0].p, rgba(TEAL, 0.95), false);
      }
      chip(last, rgba(STEEL, 0.98), true);
      // chips informativos VWAP/POC
      if (st.showVwap && st.session && st.session.vwap > 0) {
        const yV = yOf(st.session.vwap);
        if (yV >= 8 && yV <= mainH - 8) {
          ctx.fillStyle = BG;
          ctx.fillRect(plotW + 1, yV - 7, AXIS_W - 2, 14);
          ctx.strokeStyle = rgba(AMBER, 0.7);
          ctx.strokeRect(plotW + 1.5, yV - 6.5, AXIS_W - 3, 13);
          ctx.fillStyle = rgba(AMBER, 0.95);
          ctx.font = FONT_MONO(9, '600');
          ctx.fillText(fmtPrice(st.session.vwap, tick), plotW + 5, yV);
        }
      }
    }

    // ── ordens + posição (trading simulado) ──────────────────────────────
    {
      const tr = useTradingStore.getState();
      const axisChip = (p: number, txt: string, bg: string) => {
        const y = yOf(p);
        if (y < 8 || y > mainH - 8) return;
        ctx.fillStyle = bg;
        ctx.fillRect(plotW + 1, y - 8, AXIS_W - 2, 16);
        ctx.fillStyle = 'rgba(255,255,255,0.97)';
        ctx.font = FONT_MONO(9, '700');
        ctx.textAlign = 'left';
        ctx.textBaseline = 'middle';
        ctx.fillText(txt, plotW + 5, y);
      };
      if (tr.orders.length || tr.position.qty !== 0) {
        // linhas dentro do plot (com clip)
        clipPlot();
        for (const o of tr.orders) {
          const p = o.role === 'stop' ? o.trigger : o.price;
          if (p === null) continue;
          const y = Math.round(yOf(p)) + 0.5;
          if (y < 0 || y > mainH) continue;
          ctx.strokeStyle = rgba(o.side === 'buy' ? TEAL : RED, o.role === 'manual' ? 0.8 : 0.5);
          ctx.setLineDash(o.role === 'manual' ? [6, 4] : [3, 3]);
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(plotW, y);
          ctx.stroke();
          ctx.setLineDash([]);
        }
        if (tr.position.qty !== 0) {
          const y = Math.round(yOf(tr.position.avg)) + 0.5;
          if (y >= 0 && y <= mainH) {
            ctx.strokeStyle = rgba(BLUE, 0.9);
            ctx.lineWidth = 1.2;
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(plotW, y);
            ctx.stroke();
            ctx.lineWidth = 1;
          }
        }
        ctx.restore();

        // rótulo da posição dentro do plot (borda direita, acima da linha)
        if (tr.position.qty !== 0) {
          const y = yOf(tr.position.avg);
          if (y >= 20 && y <= mainH - 4) {
            const q = tr.position.qty;
            const txt = `POS ${q > 0 ? '+' : ''}${q} @ ${fmtPrice(tr.position.avg, tick)}`;
            ctx.font = FONT_MONO(9, '700');
            const tw = ctx.measureText(txt).width + 10;
            const x = Math.max(4, plotW - tw - 8);
            ctx.fillStyle = 'rgba(21,47,89,0.92)';
            ctx.fillRect(x, y - 17, tw, 14);
            ctx.strokeStyle = rgba(BLUE, 0.9);
            ctx.strokeRect(x + 0.5, y - 16.5, tw - 1, 13);
            ctx.fillStyle = 'rgba(255,255,255,0.97)';
            ctx.textAlign = 'left';
            ctx.textBaseline = 'middle';
            ctx.fillText(txt, x + 5, y - 10);
          }
        }

        // chips das ordens no eixo de preço
        for (const o of tr.orders) {
          const p = o.role === 'stop' ? o.trigger : o.price;
          if (p === null) continue;
          const lbl =
            o.role === 'target'
              ? `A${o.qty}`
              : o.role === 'stop'
                ? `S${o.qty}`
                : `${o.side === 'buy' ? 'C' : 'V'}${o.qty}`;
          const col =
            o.role === 'stop'
              ? rgba(AMBER, 0.95)
              : o.side === 'buy'
                ? rgba(TEAL, 0.95)
                : rgba(RED, 0.95);
          axisChip(p, lbl, col);
        }
        // chip da posição no eixo
        if (tr.position.qty !== 0) {
          const q = tr.position.qty;
          axisChip(tr.position.avg, `${q > 0 ? '+' : ''}${q}`, rgba(BLUE, 0.95));
        }
      }
    }

    // ── eixo do tempo ────────────────────────────────────────────────────
    const axisTop = H - TIME_AXIS_H;
    ctx.fillStyle = BG;
    ctx.fillRect(0, axisTop, W, TIME_AXIS_H);
    ctx.strokeStyle = rgba(GRID, 0.9);
    ctx.beginPath();
    ctx.moveTo(0, axisTop + 0.5);
    ctx.lineTo(W, axisTop + 0.5);
    ctx.stroke();
    ctx.font = FONT_MONO(10);
    ctx.fillStyle = rgba('120,123,134', 0.95);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const intraday = st.tf === '5s' || st.tf === '15s';
    for (let i = N - 1; i >= 0; i -= tStep) {
      const x = cxOf(i);
      if (x < 20) break;
      if (x > plotW - 20) continue;
      ctx.fillText(intraday ? fmtTime(candles[i].t) : fmtHm(candles[i].t), x, axisTop + TIME_AXIS_H / 2);
    }

    // ── crosshair + legenda de hover ─────────────────────────────────────
    if (v.hovering && v.hoverX < plotW) {
      const hx = v.hoverX;
      const hy = v.hoverY;
      ctx.strokeStyle = rgba('120,123,134', 0.5);
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      ctx.moveTo(Math.round(hx) + 0.5, 0);
      ctx.lineTo(Math.round(hx) + 0.5, H - TIME_AXIS_H);
      ctx.moveTo(0, Math.round(hy) + 0.5);
      ctx.lineTo(plotW, Math.round(hy) + 0.5);
      ctx.stroke();
      ctx.setLineDash([]);

      if (hy < mainH) {
        const p = priceTop - (hy / mainH) * range;
        ctx.fillStyle = 'rgba(42,45,53,0.96)';
        ctx.fillRect(plotW + 1, hy - 8, AXIS_W - 2, 16);
        ctx.fillStyle = 'rgba(255,255,255,0.95)';
        ctx.font = FONT_MONO(10);
        ctx.textAlign = 'left';
        ctx.textBaseline = 'middle';
        ctx.fillText(fmtPrice(p, tick), plotW + 6, hy);
      }
      const idx = idxAt(hx);
      if (idx >= 0 && idx < N && hy < H - TIME_AXIS_H) {
        const label = intraday ? fmtTime(candles[idx].t) : fmtHm(candles[idx].t);
        ctx.font = FONT_MONO(10);
        const tw = ctx.measureText(label).width + 10;
        ctx.fillStyle = 'rgba(42,45,53,0.96)';
        ctx.fillRect(hx - tw / 2, H - TIME_AXIS_H + 3, tw, TIME_AXIS_H - 6);
        ctx.fillStyle = 'rgba(255,255,255,0.95)';
        ctx.textAlign = 'center';
        ctx.fillText(label, hx, H - TIME_AXIS_H / 2);
      }

      // legenda ATAS no topo-esquerdo (O H L C V Δ N)
      if (idx >= 0 && idx < N && !heatMode) {
        const c = candles[idx];
        const up = c.c >= c.o;
        const col = up ? rgba(TEAL, 1) : rgba(RED, 1);
        const barLbl =
          st.barType === 'time'
            ? st.tf
            : st.barType === 'range'
              ? `Range ${st.barParams.range}`
              : st.barType === 'reversal'
                ? `Reversão ${st.barParams.reversal}`
                : st.barType === 'tick'
                  ? `Tick ${st.barParams.tick}`
                  : `Vol ${st.barParams.volume}`;
        const lines: { txt: string; col: string }[] = [
          {
            txt: `${st.symbol} · ${barLbl} · ${
              meta.label.includes('·') ? meta.label.split('·')[1].trim() : 'Cluster'
            }`,
            col: 'rgba(255,255,255,0.95)',
          },
          {
            txt: `A ${fmtPrice(c.o, tick)}  M ${fmtPrice(c.h, tick)}  m ${fmtPrice(c.l, tick)}  F ${fmtPrice(c.c, tick)}`,
            col,
          },
          { txt: `V ${fmtCompact(c.v)}   Δ ${fmtSignedCompact(c.d)}   N ${c.n}`, col: rgba('209,212,220', 0.9) },
        ];
        ctx.font = FONT_MONO(10);
        let wMax = 0;
        for (const ln of lines) wMax = Math.max(wMax, ctx.measureText(ln.txt).width);
        ctx.fillStyle = '#101012';
        ctx.fillRect(4, 4, wMax + 12, lines.length * 13 + 7);
        ctx.textAlign = 'left';
        ctx.textBaseline = 'top';
        ctx.font = FONT_MONO(10, '700');
        ctx.fillStyle = lines[0].col;
        ctx.fillText(lines[0].txt, 10, 8);
        ctx.font = FONT_MONO(10);
        ctx.fillStyle = lines[1].col;
        ctx.fillText(lines[1].txt, 10, 21);
        ctx.fillStyle = lines[2].col;
        ctx.fillText(lines[2].txt, 10, 34);
      }
    }

    // selo do replay (topo-centro; empilha abaixo da legenda GEX/heatmap)
    if (rep.active && N > 0) {
      const gexChipY = heatMode ? 24 : 4;
      const badgeY =
        st.showGexHeatmap || st.showGexFlip ? gexChipY + 22 : 4;
      const txt = `REPLAY · barra ${Math.min(rep.idx + 1, liveLen)}/${liveLen}`;
      ctx.font = FONT_MONO(10, '700');
      const tw = ctx.measureText(txt).width + 14;
      const x = plotW / 2 - tw / 2;
      ctx.fillStyle = 'rgba(232,168,84,0.16)';
      ctx.fillRect(x, badgeY, tw, 18);
      ctx.strokeStyle = rgba(AMBER, 0.6);
      ctx.strokeRect(x + 0.5, badgeY + 0.5, tw - 1, 17);
      ctx.fillStyle = rgba(AMBER, 1);
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(txt, plotW / 2, badgeY + 9);
    }

    // ── renderiza a camada WebGL do motor MBO (mesmo frame do 2D) ──────────
    if (glScene && glInst) {
      glInst.setRowHpx(rowH);
      glInst.render(glScene);
    }
  };

  const drawRef = useRef<() => void>(() => {});
  useEffect(() => {
    drawRef.current = draw;
  });

  // mudança de pin (multi-chart) → espelha no ref e agenda redraw
  // (posicionado APÓS a atribuição de drawRef: escrita antes da leitura)
  useEffect(() => {
    if (pinnedTfRef.current !== pinnedTf) {
      pinnedTfRef.current = pinnedTf;
      scheduleDraw();
    }
  }, [pinnedTf]);
  useEffect(() => {
    if (pinnedBarRef.current !== pinnedBar) {
      pinnedBarRef.current = pinnedBar;
      scheduleDraw();
    }
  }, [pinnedBar]);

  // ── efeito da camada WebGL: contexto, resize e anel do worker ────────
  useEffect(() => {
    const el = wrapRef.current;
    const gcv = glCanvasRef.current;
    if (!el || !gcv) return;

    const gl = new HeatGl(gcv);
    glRef.current = gl;
    mboClient.glOk = gl.ok;

    const resizeGl = () => {
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      gl.resize(el.clientWidth, el.clientHeight, dpr);
    };
    resizeGl();

    const ro = new ResizeObserver(() => {
      resizeGl();
      scheduleDraw();
    });
    ro.observe(el);

    // novo anel do worker MBO → redesenha (bypassa o store: arrays grandes)
    const unRing = mboClient.onRing(() => scheduleDraw());

    return () => {
      ro.disconnect();
      unRing();
      gl.dispose();
      glRef.current = null;
      mboClient.glOk = false;
    };
  }, []);

  // ── efeito único: resize, listeners, subscrição de store ─────────────────
  useEffect(() => {
    const el = wrapRef.current;
    const cv = canvasRef.current;
    if (!el || !cv) return;

    const resize = () => {
      const w = el.clientWidth;
      const h = el.clientHeight;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      cv.width = Math.max(1, Math.round(w * dpr));
      cv.height = Math.max(1, Math.round(h * dpr));
      cv.style.width = `${w}px`;
      cv.style.height = `${h}px`;
    };

    const schedule = () => {
      if (rafRef.current === 0) {
        rafRef.current = requestAnimationFrame(() => {
          rafRef.current = 0;
          drawRef.current();
        });
      }
    };

    const ro = new ResizeObserver(() => {
      resize();
      schedule();
    });
    ro.observe(el);
    resize();

    const unsub = useTerminalStore.subscribe((state, prev) => {
      if (
        state.dataVersion !== prev.dataVersion ||
        state.displayMode !== prev.displayMode ||
        state.chartMode !== prev.chartMode ||
        state.showProfile !== prev.showProfile ||
        state.profileMode !== prev.profileMode ||
        state.showImbalances !== prev.showImbalances ||
        state.imbalanceRatio !== prev.imbalanceRatio ||
        state.showMaxLevels !== prev.showMaxLevels ||
        state.minCellVolume !== prev.minCellVolume ||
        state.showDeltaPane !== prev.showDeltaPane ||
        state.showVwap !== prev.showVwap ||
        state.showVwapBands !== prev.showVwapBands ||
        state.showHeatBubbles !== prev.showHeatBubbles ||
        state.bubbleMinVolume !== prev.bubbleMinVolume ||
        state.showDepthBubbles !== prev.showDepthBubbles ||
        state.depthBubbleMinPct !== prev.depthBubbleMinPct ||
        state.showDepthLadder !== prev.showDepthLadder ||
        state.showEma9 !== prev.showEma9 ||
        state.showEma21 !== prev.showEma21 ||
        state.showSma50 !== prev.showSma50 ||
        state.showRSI !== prev.showRSI ||
        state.showGexHeatmap !== prev.showGexHeatmap ||
        state.showGexFlip !== prev.showGexFlip ||
        state.useMbo !== prev.useMbo ||
        state.useWebgl !== prev.useWebgl ||
        state.showFlowSignals !== prev.showFlowSignals ||
        state.replay !== prev.replay ||
        state.barType !== prev.barType ||
        state.barParams !== prev.barParams ||
        state.symbol !== prev.symbol ||
        state.tf !== prev.tf
      ) {
        if (state.symbol !== prev.symbol || state.tf !== prev.tf) {
          view.current.candleW = 38;
          view.current.rightOffsetPx = 64;
          view.current.panY = 0;
          view.current.zoomY = 1;
          followRef.current = true;
          setFollowUi(true);
          // desenhos são por símbolo|tf — rascunho em curso não faz sentido
          draftRef.current = null;
          previewRef.current = null;
        }
        // no heatmap, abre espaço p/ o ladder não cobrir a vela corrente
        if (state.chartMode !== prev.chartMode && state.chartMode === 'heatmap') {
          if (view.current.rightOffsetPx < 120) view.current.rightOffsetPx = 120;
        }
        schedule();
      }
    });

    const reportHover = (idx: number | null) => {
      if (hoverIdxRef.current === idx) return;
      hoverIdxRef.current = idx;
      onHoverRef.current?.(idx);
    };

    // ── ferramentas de desenho ──
    /** comprimento visível (replay corta o histórico) — espelha o draw() */
    const shownLen = () => {
      const st2 = useTerminalStore.getState();
      const n = st2.candles.length;
      if (!st2.replay.active) return n;
      return Math.max(1, Math.min(st2.replay.idx + 1, n));
    };
    /** coords de tela → espaço de dados (índice da barra + preço) */
    const dataPtAt = (x: number, y: number): DrawPt => {
      const sc = scaleRef.current;
      const v2 = view.current;
      const p = sc.priceTop - (y / Math.max(1, sc.mainH)) * sc.range;
      const i = Math.round(
        shownLen() - 1 - (sc.plotW - v2.rightOffsetPx - v2.candleW / 2 - x) / v2.candleW,
      );
      return { i: Math.max(0, i), p };
    };
    const commitDraft = (kind: DrawKind, pts: DrawPt[], text?: string) => {
      const st2 = useTerminalStore.getState();
      useDrawingStore.getState().add(`${st2.symbol}|${st2.tf}`, {
        id: `d${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
        kind,
        pts,
        text,
      });
      draftRef.current = null;
      previewRef.current = null;
      schedule();
    };
    /** clique com ferramenta ativa: define pontos do desenho em construção */
    const handleToolPointer = (tool: DrawKind, px: number, py: number) => {
      const pt = dataPtAt(px, py);
      if (tool === 'hline') {
        commitDraft('hline', [{ i: 0, p: pt.p }]);
        return;
      }
      if (tool === 'vline') {
        commitDraft('vline', [{ i: pt.i, p: 0 }]);
        return;
      }
      if (tool === 'text') {
        setTextEdit({ px, py, pt });
        return;
      }
      const draft = draftRef.current;
      if (!draft) {
        draftRef.current = { kind: tool, pts: [pt] };
        draftDragRef.current = true; // se arrastar até soltar, fecha no pointerup
      } else {
        commitDraft(draft.kind, [draft.pts[0], pt]);
      }
      schedule();
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const v = view.current;
      const plotW = Math.max(50, cv.clientWidth - AXIS_W);
      // Shift+roda no heatmap = zoom vertical (níveis de preço maiores)
      if (e.shiftKey && useTerminalStore.getState().chartMode === 'heatmap') {
        v.zoomY = Math.max(1, Math.min(90, v.zoomY * Math.exp(-e.deltaY * 0.002)));
        schedule();
        return;
      }
      if (e.shiftKey || Math.abs(e.deltaX) > Math.abs(e.deltaY)) {
        v.rightOffsetPx += (e.deltaX || e.deltaY) * 0.6;
        if (v.rightOffsetPx > 40) {
          followRef.current = false;
          setFollowUi(false);
        }
        if (v.rightOffsetPx <= 40 && v.rightOffsetPx >= 0) {
          followRef.current = true;
          setFollowUi(true);
        }
        v.rightOffsetPx = Math.max(-160, Math.min(plotW * 1.5, v.rightOffsetPx));
        schedule();
        return;
      }
      const factor = Math.exp(-e.deltaY * 0.0016);
      const newW = Math.max(4, Math.min(90, v.candleW * factor));
      const mx = e.offsetX;
      const fracFromRight = (plotW - v.rightOffsetPx - mx) / v.candleW;
      v.rightOffsetPx = plotW - mx - fracFromRight * newW;
      v.candleW = newW;
      if (v.rightOffsetPx > 40) {
        followRef.current = false;
        setFollowUi(false);
      }
      schedule();
    };

    const onDown = (e: PointerEvent) => {
      const tool = useDrawingStore.getState().tool;
      const rect = cv.getBoundingClientRect();
      if (tool !== 'crosshair') {
        handleToolPointer(tool, e.clientX - rect.left, e.clientY - rect.top);
        return; // com ferramenta ativa o clique desenha (pan só no crosshair)
      }
      // crosshair = seleção: hit-test dos desenhos (O(n) sobre poucos objetos,
      // apenas no pointerdown) antes do pan
      const st2 = useTerminalStore.getState();
      const dKey = `${st2.symbol}|${st2.tf}`;
      const objs = useDrawingStore.getState().items[dKey] ?? [];
      if (objs.length > 0) {
        const dpt = dataPtAt(e.clientX - rect.left, e.clientY - rect.top);
        const tk = symbolMeta(st2.symbol).tick;
        for (let i = objs.length - 1; i >= 0; i--) {
          const o = objs[i];
          if (!o) continue;
          const h = hitTestDraw(o, dpt, tk);
          if (h) {
            drawDragRef.current = {
              key: dKey,
              id: o.id,
              kind: o.kind,
              handle: h,
              orig: o.pts.map((p) => ({ ...p })),
              pts: o.pts.map((p) => ({ ...p })),
              moved: false,
            };
            try {
              cv.setPointerCapture(e.pointerId);
            } catch {
              /* ponteiro sintético/encerrado — o drag segue sem capture */
            }
            schedule();
            return;
          }
        }
      }
      const v = view.current;
      v.dragging = true;
      v.moved = false;
      v.downX = e.clientX;
      v.downY = e.clientY;
      v.downOffset = v.rightOffsetPx;
      v.downPanY = v.panY;
      try {
        cv.setPointerCapture(e.pointerId);
      } catch {
        /* ponteiro sintético/encerrado — pan segue sem capture */
      }
    };

    const onMove = (e: PointerEvent) => {
      const v = view.current;
      const rect = cv.getBoundingClientRect();
      v.hoverX = e.clientX - rect.left;
      v.hoverY = e.clientY - rect.top;
      v.hovering = true;
      // drag de desenho: move âncora/corpo localmente (store só no pointerup)
      const drag = drawDragRef.current;
      if (drag) {
        const dpt = dataPtAt(v.hoverX, v.hoverY);
        const obj: DrawObj = { id: drag.id, kind: drag.kind, pts: drag.orig };
        drag.pts = moveDraw(obj, drag.handle, drag.orig, dpt);
        drag.moved = true;
        schedule();
        return;
      }
      // hover p/ feedback de handles (crosshair apenas; barato: O(n) pequeno)
      if (v.hoverX >= 0 && v.hoverX <= scaleRef.current.plotW) {
        const st2 = useTerminalStore.getState();
        const dKey = `${st2.symbol}|${st2.tf}`;
        const objs = useDrawingStore.getState().items[dKey] ?? [];
        let hit: { id: string; handle: DrawHandle } | null = null;
        if (objs.length > 0 && useDrawingStore.getState().tool === 'crosshair') {
          const dpt = dataPtAt(v.hoverX, v.hoverY);
          const tk = symbolMeta(st2.symbol).tick;
          for (let i = objs.length - 1; i >= 0; i--) {
            const o = objs[i];
            if (!o) continue;
            const h = hitTestDraw(o, dpt, tk);
            if (h) {
              hit = { id: o.id, handle: h };
              break;
            }
          }
        }
        const prevHover = drawHoverRef.current;
        const changed = (hit?.id ?? null) !== (prevHover?.id ?? null);
        drawHoverRef.current = hit;
        if (changed) schedule();
      } else if (drawHoverRef.current) {
        drawHoverRef.current = null;
        schedule();
      }
      // rascunho de desenho: segue o mouse p/ pré-visualização
      if (draftRef.current && draftRef.current.pts.length === 1) {
        const sc = scaleRef.current;
        previewRef.current =
          v.hoverX >= 0 && v.hoverX <= sc.plotW && v.hoverY >= 0 && v.hoverY <= sc.mainH
            ? dataPtAt(v.hoverX, v.hoverY)
            : null;
        schedule();
      }
      if (v.dragging) {
        const dx = e.clientX - v.downX;
        const dy = e.clientY - v.downY;
        if (Math.abs(dx) + Math.abs(dy) > 3) v.moved = true;
        v.rightOffsetPx = Math.max(-160, v.downOffset + dx);
        v.panY = Math.max(-1200, Math.min(1200, v.downPanY + dy));
        if (v.rightOffsetPx > 40) {
          if (followRef.current) {
            followRef.current = false;
            setFollowUi(false);
          }
        } else if (!followRef.current) {
          followRef.current = true;
          setFollowUi(true);
        }
        reportHover(null);
      } else {
        const plotW = Math.max(50, cv.clientWidth - AXIS_W);
        if (v.hoverX < plotW) {
          const st2 = useTerminalStore.getState();
          const n = st2.candles.length;
          const rightEdge = plotW - v.rightOffsetPx;
          const idx = Math.round(n - 1 - (rightEdge - v.candleW / 2 - v.hoverX) / v.candleW);
          reportHover(idx >= 0 && idx < n ? idx : null);
        } else {
          reportHover(null);
        }
      }
      schedule();
    };

    const onUp = (e: PointerEvent) => {
      const v = view.current;
      // drag de desenho existente: commit único no store (update persiste)
      const drag = drawDragRef.current;
      if (drag) {
        drawDragRef.current = null;
        try {
          cv.releasePointerCapture(e.pointerId);
        } catch {
          /* noop */
        }
        if (drag.moved) {
          useDrawingStore.getState().update(drag.key, drag.id, drag.pts);
        }
        schedule();
        return;
      }
      // desenhando por arraste: fecha o rascunho quando o arraste é real
      if (draftRef.current && draftDragRef.current) {
        draftDragRef.current = false;
        const rect = cv.getBoundingClientRect();
        const pt = dataPtAt(e.clientX - rect.left, e.clientY - rect.top);
        const a = draftRef.current.pts[0];
        if (pt.i !== a.i || Math.abs(pt.p - a.p) > 0) {
          commitDraft(draftRef.current.kind, [a, pt]);
        }
        schedule();
        return;
      }
      v.dragging = false;
      try {
        cv.releasePointerCapture(e.pointerId);
      } catch {
        /* noop */
      }
      schedule();
    };

    // Esc cancela o rascunho em curso, o drag e o editor de texto
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'Escape') return;
      draftRef.current = null;
      previewRef.current = null;
      drawDragRef.current = null;
      drawHoverRef.current = null;
      setTextEdit(null);
      schedule();
    };
    window.addEventListener('keydown', onKey);

    const onLeave = () => {
      view.current.hovering = false;
      reportHover(null);
      schedule();
    };

    const onDbl = () => {
      const v = view.current;
      v.candleW = 38;
      v.rightOffsetPx =
        useTerminalStore.getState().chartMode === 'heatmap' ? 120 : 64;
      v.panY = 0;
      v.zoomY = 1;
      followRef.current = true;
      setFollowUi(true);
      schedule();
    };

    // trading: fills/ordens/posição também redesenham o gráfico
    const unsubTrading = useTradingStore.subscribe(() => schedule());
    // desenhos (add/undo/clear/tool) redesenham o gráfico
    const unsubDraw = useDrawingStore.subscribe(() => schedule());

    cv.addEventListener('wheel', onWheel, { passive: false });
    cv.addEventListener('pointerdown', onDown);
    cv.addEventListener('pointermove', onMove);
    cv.addEventListener('pointerup', onUp);
    cv.addEventListener('pointercancel', onUp);
    cv.addEventListener('pointerleave', onLeave);
    cv.addEventListener('dblclick', onDbl);

    schedule();

    return () => {
      ro.disconnect();
      unsub();
      unsubTrading();
      unsubDraw();
      window.removeEventListener('keydown', onKey);
      cv.removeEventListener('wheel', onWheel);
      cv.removeEventListener('pointerdown', onDown);
      cv.removeEventListener('pointermove', onMove);
      cv.removeEventListener('pointerup', onUp);
      cv.removeEventListener('pointercancel', onUp);
      cv.removeEventListener('pointerleave', onLeave);
      cv.removeEventListener('dblclick', onDbl);
      if (rafRef.current) {
        cancelAnimationFrame(rafRef.current);
        rafRef.current = 0;
      }
    };
  }, []);

  const goLive = () => {
    const v = view.current;
    v.candleW = 38;
    v.rightOffsetPx =
      useTerminalStore.getState().chartMode === 'heatmap' ? 120 : 64;
    v.panY = 0;
    v.zoomY = 1;
    followRef.current = true;
    setFollowUi(true);
    if (rafRef.current === 0) {
      rafRef.current = requestAnimationFrame(() => {
        rafRef.current = 0;
        drawRef.current();
      });
    }
  };

  return (
    <div ref={wrapRef} className="canvas-fit absolute inset-0 bg-[#18181b]">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 h-full w-full cursor-crosshair touch-none select-none"
        aria-label="Gráfico de clusters (footprint) estilo ATAS"
      />
      {/* camada WebGL do motor MBO: heatmap de liquidez + bolhas + sinais */}
      <canvas
        ref={glCanvasRef}
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 h-full w-full"
      />
      {activeTool !== 'crosshair' && (
        <div className="pointer-events-none absolute bottom-2 left-2 z-10 rounded border border-[#27272a] bg-[#101012] px-2 py-1 font-num text-[9px] text-[#d1d4dc]">
          {TOOL_LABEL[activeTool] ?? activeTool}: clique/arraste define os pontos · Esc cancela
        </div>
      )}
      {textEdit && (
        <input
          autoFocus
          defaultValue=""
          placeholder="texto…"
          aria-label="Texto do desenho"
          onBlur={(e) => commitText(e.currentTarget.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') commitText(e.currentTarget.value);
            if (e.key === 'Escape') setTextEdit(null);
          }}
          style={{ left: Math.max(4, textEdit.px), top: Math.max(4, textEdit.py) }}
          className="absolute z-20 h-6 w-40 rounded border border-[#4682b4] bg-[#1f1f23] px-1.5 font-num text-[11px] text-white outline-none"
        />
      )}
      {!followUi && (
        <button
          type="button"
          onClick={goLive}
          className="absolute bottom-9 right-20 z-10 flex items-center gap-1.5 rounded bg-[#3f3f46] px-2.5 py-1 text-[10px] font-semibold text-white transition-colors hover:bg-[#52525b]"
        >
          <Undo2 className="h-3 w-3" />
          ir para o vivo
        </button>
      )}
    </div>
  );
});

// estado local p/ o botão "ir para o vivo" (fora do canvas)
