'use client';

/**
 * WorkspaceDock — sistema de docking do workspace (dockview-core v7, UMD).
 *
 * Substitui o antigo "gráfico principal + aside fixo" por um layout REAL de
 * docking: cada widget (Gráfico 1/2, DOM, SMART TAPE, Quant) é um painel que
 * o usuário arrasta para ANEXAR em outro (split/tab), flutuar, maximizar e
 * fechar. "Anexar o gráfico no outro" = arrastar a aba sobre o alvo.
 *
 * - Fábrica de conteúdo v7: createComponent({ id, name }) → renderizador
 *   vanilla que monta o componente React via createRoot (dispose desmonta).
 * - Layout padrão: Gráfico à esquerda; DOM/Tape/Quant empilhados à direita.
 * - chartCount (store) ⇄ painel 'chart-2' sincronizados (Link2/Unlink2/X do
 *   header do gráfico e o Select de Configurações continuam funcionando).
 * - Persistência: toJSON() → localStorage a cada onDidLayoutChange (debounce);
 *   fromJSON no boot com fallback para o layout padrão.
 * - Topbar dispara CustomEvents: 'terminal:dock-add' {kind} e
 *   'terminal:dock-reset' (menu "Adicionar widget").
 * - Mobile (<md): não monta — terminal-shell mantém as abas por widget.
 */

import { useEffect, useRef } from 'react';
import { createRoot, type Root } from 'react-dom/client';

import { ChartWidget } from './chart-widget';
import DomPanel from './dom-panel';
import TapePanel from './tape-panel';
import QuantPanel from './quant-panel';
import { useTerminalStore } from '@/store/terminal';
import type { BarType } from '@/lib/market/bars';
import type { Timeframe } from '@/lib/market/types';

const SCRIPT_SRC = '/vendor/dockview-core.min.noStyle.js';
const STORAGE_KEY = 'terminal.dockview.v1';
/** largura da coluna de dados (DOM/Tape/Quant) ao criar o split à direita */
const SIDE_W = 340;
/** alturas fixas de SMART TAPE e Quant no layout padrão (dom recebe o resto) */
const TAPE_H = 250;
const QUANT_H = 230;

/**
 * ids lógicos dos painéis ⇄ nomes de componente registrados na fábrica.
 * Gráficos são NUMERADOS (chart-1, chart-2, … chart-N): o multi-chart
 * instancia N gráficos com params independentes (tf/barType por painel).
 */
type DockDataPanelId = 'dom' | 'tape' | 'quant';
type DockPanelId = `chart-${number}` | DockDataPanelId;

const isDataPanel = (id: string): id is DockDataPanelId =>
  id === 'dom' || id === 'tape' || id === 'quant';
const isChartPanel = (id: string): boolean => id.startsWith('chart-');

/** Título do painel: gráficos numerados com sufixo do pin (tf/tipo de barra). */
function panelTitle(id: string, params?: Record<string, unknown>): string {
  if (isDataPanel(id)) {
    return id === 'dom' ? 'DOM' : id === 'tape' ? 'SMART TAPE' : 'Quant';
  }
  const n = id.replace('chart-', '');
  const suffix = chartPinLabel(params);
  const base = id === 'chart-1' ? 'Gráfico' : `Gráfico ${n}`;
  return suffix ? `${base} · ${suffix}` : base;
}

/** Rótulo do pin do painel (ex.: "M5", "Tick 50", "Range 10"). */
const TF_PIN_LABEL: Record<Timeframe, string> = {
  '5s': 'S5',
  '15s': 'S15',
  '1m': 'M1',
  '5m': 'M5',
};

function chartPinLabel(params?: Record<string, unknown>): string {
  if (!params) return '';
  const tf = typeof params.tf === 'string' ? (params.tf as Timeframe) : null;
  const barType = typeof params.barType === 'string' ? params.barType : null;
  const barParam = typeof params.barParam === 'number' ? params.barParam : null;
  if (tf && TF_PIN_LABEL[tf]) return TF_PIN_LABEL[tf];
  if (barType && barType !== 'time') {
    return barType === 'volume'
      ? `Vol ${barParam ?? ''}`.trim()
      : `${barType} ${barParam ?? ''}`.trim();
  }
  return '';
}

const DOCK_EVENT_ADD = 'terminal:dock-add';
const DOCK_EVENT_RESET = 'terminal:dock-reset';
/** kinds válidos do evento de adição (guard do detail do CustomEvent) */
const DOCK_KIND_GUARD: ReadonlySet<string> = new Set([
  'chart',
  'chart-1',
  'chart-2',
  'dom',
  'tape',
  'quant',
]);

/** Detalhe do evento de adição: kind genérico 'chart' cria chart-N novo. */
interface DockAddDetail {
  kind?: DockPanelId | 'chart';
  /** pin de timeframe p/ o novo gráfico (derivado localmente do stream) */
  tf?: Timeframe;
  /** pin de tipo de barra não-temporal (tick/range/reversal/volume) */
  barType?: BarType;
  barParam?: number;
}

// ── serialização (subtipagem defensiva do toJSON v7) ───────────────────────

interface DockviewJsonLeaf {
  type: 'leaf';
  size?: number;
  data: { views: string[]; activeView: string; id: string };
}
interface DockviewJsonBranch {
  type: 'branch';
  size?: number;
  data: Array<DockviewJsonLeaf | DockviewJsonBranch>;
}
interface DockviewJson {
  grid: {
    width: number;
    height: number;
    orientation: string;
    root: DockviewJsonBranch | DockviewJsonLeaf;
  };
  panels: Record<string, { id: string; contentComponent: string; params?: Record<string, unknown>; title?: string }>;
  activeGroup?: string;
}

// ── carregamento do bundle UMD (uma única vez por sessão) ───────────────────

let corePromise: Promise<DockviewCoreGlobal> | null = null;

/** raízes React vivas nos painéis (higienizadas no unmount p/ HMR/StrictMode) */
const liveRoots = new Set<Root>();

/** global exposto pelo bundle UMD: globalThis['dockview-core'] (com hífen) */
function getCoreGlobal(): DockviewCoreGlobal | undefined {
  if (window.dockviewCore) return window.dockviewCore;
  return (window as unknown as Record<string, DockviewCoreGlobal | undefined>)[
    'dockview-core'
  ];
}

function loadDockviewCore(): Promise<DockviewCoreGlobal> {
  if (typeof window === 'undefined') {
    return Promise.reject(new Error('dockview: fora do browser'));
  }
  const existing = getCoreGlobal();
  if (existing) return Promise.resolve(existing);
  if (!corePromise) {
    corePromise = new Promise<DockviewCoreGlobal>((resolve, reject) => {
      const el = document.createElement('script');
      el.src = SCRIPT_SRC;
      el.async = true;
      el.onload = () => {
        const core = getCoreGlobal();
        if (core) resolve(core);
        else reject(new Error('dockview: global ausente após load'));
      };
      el.onerror = () => {
        corePromise = null; // permite retry no próximo mount
        reject(new Error('dockview: falha ao carregar ' + SCRIPT_SRC));
      };
      document.head.appendChild(el);
    });
  }
  return corePromise;
}

// ── fábrica de renderizadores (React via createRoot) ────────────────────────

function contentFor(name: string, params: Record<string, unknown> | undefined) {
  switch (name) {
    case 'chart':
      return (
        <ChartWidget
          primary={params?.primary !== false}
          pin={{
            tf: typeof params?.tf === 'string' ? (params.tf as Timeframe) : undefined,
            barType: typeof params?.barType === 'string' ? (params.barType as BarType) : undefined,
            barParam: typeof params?.barParam === 'number' ? params.barParam : undefined,
          }}
        />
      );
    case 'dom':
      return <DomPanel className="h-full w-full" />;
    case 'tape':
      return <TapePanel className="h-full w-full" />;
    case 'quant':
      return <QuantPanel className="h-full w-full" />;
    default:
      return null;
  }
}

function makeRenderer(name: string): DockviewContentRenderer {
  const el = document.createElement('div');
  el.className = 'dv-panel-host';
  let root: Root | null = null;

  return {
    get element() {
      return el;
    },
    init(part) {
      const node = contentFor(name, part.params);
      root = createRoot(el);
      liveRoots.add(root);
      if (node) {
        root.render(node);
      } else {
        root.render(
          <div className="flex h-full w-full items-center justify-center text-[11px] text-[#5d606b]">
            componente desconhecido: {name}
          </div>,
        );
      }
    },
    dispose() {
      root?.unmount();
      if (root) liveRoots.delete(root);
      root = null;
    },
  };
}

// ── component ───────────────────────────────────────────────────────────────

export function WorkspaceDock({ className }: { className?: string }) {
  const hostRef = useRef<HTMLDivElement | null>(null);
  const apiRef = useRef<DockviewContainerApiLike | null>(null);
  const componentRef = useRef<{ orthogonalize?(): void; dispose(): void } | null>(null);

  useEffect(() => {
    let disposed = false;
    const disposables: DockviewDisposable[] = [];
    let saveTimer = 0;

    const persist = (api: DockviewContainerApiLike) => {
      window.clearTimeout(saveTimer);
      saveTimer = window.setTimeout(() => {
        try {
          localStorage.setItem(STORAGE_KEY, JSON.stringify(api.toJSON()));
        } catch {
          /* quota/privacidade — layout apenas em memória */
        }
      }, 300);
    };

    /** espelha estado do dock no store (ids p/ menu + chartCount ⇄ nº de gráficos) */
    const applyDockState = (api: DockviewContainerApiLike) => {
      const st = useTerminalStore.getState();
      const ids = api.panels.map((p) => p.id);
      if (st.dockPanelIds.join(',') !== ids.join(',')) st.setDockPanelIds(ids);
      const nCharts = ids.filter(isChartPanel).length;
      const chartCount = nCharts >= 2 ? 2 : 1;
      if (st.chartCount !== chartCount) st.patchSettings({ chartCount });
    };

    /**
     * MODO FOCO: maximiza o grupo do gráfico principal (API nativa dockview)
     * — os painéis de dados permanecem MONTADOS (ocultos atrás do grupo
     * maximizado), o canvas assume 100% da área e o retorno é instantâneo,
     * sem remontagem nem re-render dos widgets.
     */
    const syncFocus = (api: DockviewContainerApiLike, focus: boolean) => {
      if (focus) {
        const chart =
          api.getPanel('chart-1') ??
          api.panels.find((p) => isChartPanel(p.id)) ??
          api.panels[0];
        chart?.api.maximize();
      } else {
        for (const p of api.panels) {
          if (p.api.isMaximized()) {
            p.api.exitMaximized();
            break;
          }
        }
      }
    };

    /**
     * Próximo id livre de gráfico (chart-1, chart-2, …): reaproveita buracos
     * após fechamentos p/ evitar inflar ids indefinidamente.
     */
    const nextChartId = (api: DockviewContainerApiLike): `chart-${number}` => {
      const taken = new Set(api.panels.map((p) => p.id));
      let n = 1;
      while (taken.has(`chart-${n}`)) n++;
      return `chart-${n}` as `chart-${number}`;
    };

    const addPanelByKind = (
      api: DockviewContainerApiLike,
      kind: DockPanelId | 'chart',
      detail?: DockAddDetail,
    ) => {
      // gráfico genérico (multi-chart): cria chart-N com params pinados
      if (kind === 'chart' || (isChartPanel(kind) && kind !== 'chart-1' && kind !== 'chart-2')) {
        const id = kind === 'chart' ? nextChartId(api) : (kind as `chart-${number}`);
        const existing = api.getPanel(id);
        if (existing) {
          existing.api.setActive();
          return;
        }
        const params: Record<string, unknown> = { primary: false };
        if (detail?.tf) params.tf = detail.tf;
        if (detail?.barType) {
          params.barType = detail.barType;
          params.barParam = detail.barParam ?? 50;
        }
        api.addPanel({
          id,
          component: 'chart',
          title: panelTitle(id, params),
          params,
          position: api.panels.length
            ? { referencePanel: lastChartId(api) ?? api.panels[0]?.id, direction: 'right' }
            : undefined,
        });
        return;
      }
      const existing = api.getPanel(kind);
      if (existing) {
        existing.api.setActive();
        return;
      }
      if (kind === 'chart-2') {
        useTerminalStore.getState().patchSettings({ chartCount: 2 });
        return;
      }
      const title = panelTitle(kind);
      if (kind === 'chart-1') {
        api.addPanel({
          id: kind,
          component: 'chart',
          title,
          params: { primary: true },
          position: api.panels.length
            ? { referencePanel: api.panels[0]?.id, direction: 'left' }
            : undefined,
        });
        return;
      }
      // dom/tape/quant: anexa à direita do gráfico (ou do primeiro painel);
      // abrir painel de dados derruba o Modo Foco automaticamente
      if (useTerminalStore.getState().focusMode) {
        useTerminalStore.getState().setFocusMode(false);
        syncFocus(api, false);
      }
      const ref = api.getPanel('chart-1')?.id ?? api.panels[0]?.id;
      api.addPanel({
        id: kind,
        component: kind,
        title,
        position: ref ? { referencePanel: ref, direction: 'right' } : undefined,
        initialWidth: ref ? SIDE_W : undefined,
      });
    };

    /** id do último gráfico aberto (referência p/ anexar o próximo à direita) */
    const lastChartId = (api: DockviewContainerApiLike): string | undefined => {
      const charts = api.panels.map((p) => p.id).filter(isChartPanel);
      return charts.length > 0 ? charts[charts.length - 1] : undefined;
    };

    /**
     * Tamanhos em px do layout padrão — a v7 ignora `initialWidth/Height`
     * quando addPanel usa `position`, então corrigimos via toJSON/fromJSON
     * (tamanhos serializados são honrados pelo fromJSON).
     */
    const normalizeDefaultSizes = (api: DockviewContainerApiLike) => {
      const j = api.toJSON() as DockviewJson;
      const root = j?.grid?.root;
      if (!root || root.type !== 'branch' || !j.grid.width || !j.grid.height) return;
      // localiza a branch da coluna de dados (folhas dom/tape/quant) e as
      // folhas de gráfico irmãs — em qualquer profundidade de aninhamento
      let dataBranch: DockviewJsonBranch | null = null;
      let dataParentSiblings: Array<DockviewJsonLeaf | DockviewJsonBranch> = [];
      const leafViews = (n: DockviewJsonLeaf | DockviewJsonBranch) =>
        n.type === 'leaf' ? n.data.views : [];
      const walk = (
        node: DockviewJsonBranch,
        siblings: Array<DockviewJsonLeaf | DockviewJsonBranch>,
      ) => {
        if (
          node.data.some((n) => leafViews(n).includes('dom')) &&
          node.data.every((n) => n.type === 'leaf')
        ) {
          dataBranch = node;
          dataParentSiblings = siblings;
          return;
        }
        for (const n of node.data) if (n.type === 'branch') walk(n, node.data);
      };
      walk(root, [root]);
      if (!dataBranch) return;
      const db: DockviewJsonBranch = dataBranch;
      const sideW = Math.min(SIDE_W, Math.round(j.grid.width * 0.4));
      db.size = sideW;
      // gráficos (irmãos da coluna de dados) dividem o restante em partes iguais
      const chartSiblings = dataParentSiblings.filter((n) => n !== db);
      const each = Math.max(
        240,
        Math.round((j.grid.width - sideW) / Math.max(1, chartSiblings.length)),
      );
      for (const n of chartSiblings) n.size = each;
      // coluna de dados: dom com o restante, tape/quant fixos
      const H = j.grid.height;
      const heights = [Math.max(180, H - TAPE_H - QUANT_H), TAPE_H, QUANT_H];
      db.data.forEach((leaf, i) => {
        if (leaf.type === 'leaf') leaf.size = heights[i] ?? leaf.size;
      });
      api.fromJSON(j);
    };

    const buildDefault = (api: DockviewContainerApiLike) => {
      api.clear();
      api.addPanel({
        id: 'chart-1',
        component: 'chart',
        title: panelTitle('chart-1', { primary: true }),
        params: { primary: true },
      });
      api.addPanel({
        id: 'dom',
        component: 'dom',
        title: panelTitle('dom'),
        position: { referencePanel: 'chart-1', direction: 'right' },
        initialWidth: SIDE_W,
      });
      api.addPanel({
        id: 'tape',
        component: 'tape',
        title: panelTitle('tape'),
        position: { referencePanel: 'dom', direction: 'below' },
        initialHeight: 250,
      });
      api.addPanel({
        id: 'quant',
        component: 'quant',
        title: panelTitle('quant'),
        position: { referencePanel: 'tape', direction: 'below' },
        initialHeight: 230,
      });
      if (useTerminalStore.getState().chartCount === 2) {
        api.addPanel({
          id: 'chart-2',
          component: 'chart',
          title: panelTitle('chart-2'),
          params: { primary: false },
          position: { referencePanel: 'chart-1', direction: 'right' },
        });
      }
      // canonicaliza a árvore (pós-clear pode haver aninhamento residual) e
      // aplica os tamanhos em px do layout padrão
      try {
        componentRef.current?.orthogonalize?.();
      } catch {
        /* opcional */
      }
      normalizeDefaultSizes(api);
    };

    loadDockviewCore()
      .then((core) => {
        if (disposed || !hostRef.current) return;

        const component = new core.DockviewComponent(hostRef.current, {
          createComponent: ({ name }) => makeRenderer(name),
          theme: core.themeDark, // class 'dockview-theme-dark' (overrides ATAS no CSS)
          floatingGroupBounds: 'boundedWithinContainer',
        });
        const api = component.api;
        apiRef.current = api;
        componentRef.current = component;
        // ponte de depuração/integração (terminal power-user + testes E2E)
        (window as unknown as Record<string, unknown>).__dockApi = api;

        // restaura layout persistido; fallback: layout padrão ATAS
        let restored = false;
        try {
          const raw = localStorage.getItem(STORAGE_KEY);
          if (raw) {
            api.fromJSON(JSON.parse(raw));
            restored = true;
          }
        } catch {
          restored = false;
        }
        if (!restored) buildDefault(api);
        // layout persistido durante o Modo Foco pode vir com painéis ocultos —
        // no boot o foco está OFF: garante todos visíveis
        syncFocus(api, useTerminalStore.getState().focusMode);
        applyDockState(api);

        // persistência + espelho no store
        disposables.push(
          api.onDidLayoutChange(() => persist(api)),
          api.onDidAddPanel(() => applyDockState(api)),
          api.onDidRemovePanel(() => applyDockState(api)),
        );

        // store → dock: chartCount (Link2/Unlink2/X/Select de Configurações)
        const unsubChart = useTerminalStore.subscribe((s, prev) => {
          if (s.chartCount === prev.chartCount || apiRef.current !== api) return;
          const has = api.getPanel('chart-2');
          if (s.chartCount === 2 && !has) {
            const ref = api.getPanel('chart-1')?.id ?? api.panels[0]?.id;
            api.addPanel({
              id: 'chart-2',
              component: 'chart',
              title: panelTitle('chart-2'),
              params: { primary: false },
              position: ref ? { referencePanel: ref, direction: 'right' } : undefined,
            });
          } else if (s.chartCount === 1 && has) {
            api.removePanel(has);
          }
        });
        disposables.push({ dispose: unsubChart });

        // store → dock: MODO FOCO (setVisible — sem unmount, sem re-render)
        const unsubFocus = useTerminalStore.subscribe((s, prev) => {
          if (s.focusMode === prev.focusMode || apiRef.current !== api) return;
          syncFocus(api, s.focusMode);
        });
        disposables.push({ dispose: unsubFocus });

        // topbar → dock: adicionar widget / redefinir layout
        const onAdd = (e: Event) => {
          const detail = (e as CustomEvent<DockAddDetail>).detail ?? {};
          const kind = detail.kind;
          if (kind && (kind === 'chart' || DOCK_KIND_GUARD.has(kind))) {
            addPanelByKind(api, kind, detail);
          }
        };
        const onReset = () => {
          try {
            localStorage.removeItem(STORAGE_KEY);
          } catch {
            /* noop */
          }
          buildDefault(api);
          applyDockState(api);
        };
        window.addEventListener(DOCK_EVENT_ADD, onAdd);
        window.addEventListener(DOCK_EVENT_RESET, onReset);
        disposables.push({
          dispose: () => {
            window.removeEventListener(DOCK_EVENT_ADD, onAdd);
            window.removeEventListener(DOCK_EVENT_RESET, onReset);
          },
        });
      })
      .catch((err) => {
        if (!disposed && hostRef.current) {
          const el = hostRef.current;
          el.textContent =
            'Falha ao carregar o sistema de docking (dockview). Recarregue a página. ' +
            (err instanceof Error ? err.message : '');
          el.style.padding = '16px';
          el.style.color = '#f2385a';
        }
      });

    return () => {
      disposed = true;
      window.clearTimeout(saveTimer);
      for (const d of disposables) d.dispose();
      try {
        apiRef.current?.dispose();
      } catch {
        /* dispose duplo em StrictMode — inofensivo */
      }
      apiRef.current = null;
      componentRef.current = null;
      // rede de segurança: qualquer root que o dockview não tenha descartado
      for (const r of liveRoots) {
        try {
          r.unmount();
        } catch {
          /* noop */
        }
      }
      liveRoots.clear();
    };
  }, []);

  return (
    <div
      ref={hostRef}
      className={`min-h-0 min-w-0 flex-1 ${className ?? ''}`}
      aria-label="Workspace com painéis encaixáveis"
    />
  );
}

/** Helper p/ a topbar: adiciona (ou foca) um painel no workspace dockado. */
export function requestDockPanel(kind: DockPanelId | 'chart', opts?: Omit<DockAddDetail, 'kind'>) {
  window.dispatchEvent(
    new CustomEvent<DockAddDetail>(DOCK_EVENT_ADD, { detail: { kind, ...opts } }),
  );
}

/** Helper p/ a topbar: restaura o layout padrão do workspace. */
export function requestDockReset() {
  window.dispatchEvent(new CustomEvent(DOCK_EVENT_RESET));
}

export type { DockPanelId };
