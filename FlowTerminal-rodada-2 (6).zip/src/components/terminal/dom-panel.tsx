'use client';

import { memo, useEffect, useMemo, useRef, useState } from 'react';
import { GripVertical, Maximize2, PanelRight, Settings2, X } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { cn } from '@/lib/utils';
import {
  fmtCompact,
  fmtPrice,
  fmtSignedCompact,
  fmtSize,
  priceOf,
  tickIndex,
} from '@/lib/market/format';
import { symbolMeta } from '@/lib/market/types';
import type { DomLevel } from '@/lib/market/types';
import type { FlowSignal } from '@/lib/market/flow';
import type { DomL3Row } from '@/lib/market/flow';
import type { DomGexMode } from '@/store/terminal';
import { useTerminalStore } from '@/store/terminal';
import {
  buildChain,
  domGexProfile,
  netGex,
  strikeStep,
} from '@/lib/quant/quant';
import type { DomGexProfile, GexRow, GreekWall } from '@/lib/quant/quant';
import {
  unrealizedPnl,
  useTradingStore,
  type Order,
} from '@/lib/trading/engine';
import { decomposeQueue } from '@/lib/mbo/doml3';

const LEVELS = 12;
const FLASH_MS = 250;
const SKELETON_ROWS = 20;

// Grid da escada (5 colunas). O rail de derivativos e o strip de fluxo são
// COLUNAS IRMÃS no flex (fora deste grid) — a escada fica intocada e volta ao
// original quando showDomGex/showDomFlowStrip = false.
// gap-x-1.5 + px-2: respiro entre bid|preço|ask|vol|Δ (anti "poluição visual").
const GRID_COLS = 'grid-cols-[1fr_1.1fr_1fr_1.2fr_1fr] gap-x-1.5';
// Modo MBO L3: 7 colunas — bid|preço|ask|vol|Δ|P/S|Fila de ordens.
const GRID_COLS_MBO = 'grid-cols-[1fr_1.05fr_1fr_0.8fr_0.8fr_1fr_1.5fr] gap-x-1';
/** fila vazia estável (referência) p/ manter a memoização das linhas */
const EMPTY_QUEUE: number[] = [];

// ── Rail de derivativos (γ/vanna/charm) + strip de fluxo (Task 3-a) ─────────
/** largura da rail à direita da escada (px) — folga p/ separar γ/VN/CH da escada */
const RAIL_W = 62;
/** respiro lateral da barra dentro da rail (px) */
const RAIL_PAD = 6;
/** largura do strip de fluxo à esquerda da escada (px) */
const FLOW_STRIP_W = 6;
/** pulse do strip: sen(t/220) → período 2π·220 ≈ 1380ms */
const FLOW_PULSE_MS = 1380;
/** re-render leve do strip só p/ expirar sinais (TTL); o pulse é 100% CSS */
const FLOW_TICK_MS = 250;
/** keyframe do pulse (injetado 1×; alpha via --flo/--fhi ∝ strength) */
const FLOW_PULSE_CSS =
  '@keyframes domFlowPulse{0%,100%{opacity:var(--flo,0.3)}50%{opacity:var(--fhi,0.8)}}';
/** botões γ/VN/CH do header da rail (compactos, sobrescrevem os variants) */
const RAIL_TOGGLE_CLS =
  'h-4 w-[16px] min-w-0 gap-0 rounded-sm px-0 text-[8px] font-bold leading-none hover:bg-[#222226] hover:text-[#d1d4dc] data-[state=on]:bg-[#27272a] data-[state=on]:text-white';

// Paleta ATAS: bid teal, ask vermelho, vol zinc neutro, última = roxo.
const BID_RGB = '8,153,129'; // #089981
const ASK_RGB = '242,56,90'; // #f2385a
const VOL_RGB = '120,123,134'; // #787b86
/** rail: teal = exposição positiva (dealer long), vermelho = negativa */
const GEX_POS = '#089981';
const GEX_NEG = '#f2385a';
/** cores do strip de fluxo por tipo de sinal */
const FLOW_COLOR: Record<FlowSignal['kind'], string> = {
  absorption: '#e8a854',
  exhaustion: '#4682b4',
  iceberg: '#29b6f6',
  spoof: '#ff6d3a',
};
const FLOW_KIND_LABEL: Record<FlowSignal['kind'], string> = {
  absorption: 'ABSORÇÃO',
  exhaustion: 'EXAUSTÃO',
  iceberg: 'ICEBERG',
  spoof: 'SPOOF',
};

/** Métrica líquida da linha de GEX conforme o modo do rail. */
function gexMetric(r: GexRow, mode: DomGexMode): number {
  if (mode === 'vanna') return r.netVanna;
  if (mode === 'charm') return r.netCharm;
  return r.net;
}

/** Escala do rail (maior |valor| por strike) conforme o modo. */
function gexMaxAbs(p: DomGexProfile, mode: DomGexMode): number {
  if (mode === 'vanna') return p.maxAbsVanna;
  if (mode === 'charm') return p.maxAbsCharm;
  return p.maxAbsGamma;
}

/** Rótulo curto da métrica p/ tooltips. */
function gexLabel(mode: DomGexMode): string {
  if (mode === 'vanna') return 'vanna';
  if (mode === 'charm') return 'charm';
  return 'γ';
}

/** Tick index do strike mais próximo do preço (chave inteira, O(1) no Map). */
function strikeIdxOf(price: number, step: number, tick: number): number {
  return tickIndex(Math.round(price / step) * step, tick);
}

/** Cor de heat (rgba) proporcional a value/max, ou undefined quando não há dado. */
function heatBg(
  value: number,
  max: number,
  rgb: string,
  minAlpha: number,
  maxAlpha: number,
): string | undefined {
  if (max <= 0 || value <= 0) return undefined;
  const a = Math.min(maxAlpha, minAlpha + (value / max) * (maxAlpha - minAlpha));
  return `rgba(${rgb},${a.toFixed(3)})`;
}

function ChromeBtn({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          type="button"
          aria-label={label}
          className="flex h-7 w-7 shrink-0 items-center justify-center rounded text-[#5d606b] transition-colors hover:bg-[#222226] hover:text-[#d1d4dc]"
        >
          {children}
        </button>
      </TooltipTrigger>
      <TooltipContent
        side="bottom"
        className="rounded border border-[#27272a] bg-[#1f1f23] px-2 py-1 text-[10px] text-[#d1d4dc]"
      >
        {label} · em breve
      </TooltipContent>
    </Tooltip>
  );
}

type DomSide = 'bid' | 'ask';

interface DomRowProps {
  price: number;
  side: DomSide;
  size: number;
  vol: number;
  delta: number;
  best: boolean;
  last: boolean;
  maxSize: number;
  maxVol: number;
  tick: number;
  sizeDecimals: number;
  /** ordem armada exatamente neste preço (qualquer papel) */
  order?: Order;
  /** posição aberta com preço médio neste nível → quantidade com sinal */
  posQty?: number;
  /** colunas MBO L3: pulling/stacking (EMA) + fila de ordens decomposta */
  mbo: boolean;
  pull: number;
  stack: number;
  queue: number[];
  onArmBid?: () => void;
  onArmAsk?: () => void;
  onCancelOrder?: () => void;
}

/** Badge compacto de ordem na escada (C=compra, V=venda, A=alvo, S=stop). */
function OrderBadge({ order }: { order: Order }) {
  const label =
    order.role === 'target'
      ? `A${order.qty}`
      : order.role === 'stop'
        ? `S${order.qty}`
        : `${order.side === 'buy' ? 'C' : 'V'}${order.qty}`;
  const cls =
    order.role === 'stop'
      ? 'bg-[#e8a854] text-[#1a1c20]'
      : order.side === 'buy'
        ? 'bg-[#089981] text-white'
        : 'bg-[#f2385a] text-white';
  return (
    <span
      className={cn(
        'inline-flex h-[14px] min-w-[16px] items-center justify-center rounded-sm px-0.5 text-[9px] font-bold leading-none',
        cls,
      )}
    >
      {label}
    </span>
  );
}

/**
 * Uma linha da escada do book (5 colunas: qtd bid | preço | qtd ask | vol | Δ).
 * Memoizada: só re-renderiza quando alguma primitiva muda (~5-10Hz no DOM).
 * Trading: clique na qtd bid arma COMPRA LMT, na qtd ask arma VENDA LMT
 * (toggle); clique no preço cancela a ordem armada naquele nível.
 */
const DomRow = memo(function DomRow({
  price,
  side,
  size,
  vol,
  delta,
  best,
  last,
  maxSize,
  maxVol,
  tick,
  sizeDecimals,
  order,
  posQty,
  mbo,
  pull,
  stack,
  queue,
  onArmBid,
  onArmAsk,
  onCancelOrder,
}: DomRowProps) {
  const isBid = side === 'bid';
  const prevSize = useRef(size);
  const rowRef = useRef<HTMLDivElement | null>(null);

  // Flash leve em atualização de quantidade: cor p/ aumento, opacidade p/ redução.
  // Aplicado direto no DOM (sistema externo) p/ evitar re-render cascata a ~5-10Hz;
  // mesmo contrato visual: ~250ms com cleanup.
  useEffect(() => {
    const prev = prevSize.current;
    prevSize.current = size;
    const el = rowRef.current;
    if (!el || prev === size) return;
    const up = size > prev;
    el.style.backgroundColor = up
      ? `rgba(${isBid ? BID_RGB : ASK_RGB},0.30)`
      : 'transparent';
    el.style.opacity = up ? '1' : '0.6';
    const timer = window.setTimeout(() => {
      el.style.backgroundColor = '';
      el.style.opacity = '';
    }, FLASH_MS);
    return () => {
      window.clearTimeout(timer);
      el.style.backgroundColor = '';
      el.style.opacity = '';
    };
  }, [size, isBid]);

  const sizeHeat = isBid
    ? heatBg(size, maxSize, BID_RGB, 0.06, 0.42)
    : heatBg(size, maxSize, ASK_RGB, 0.06, 0.42);
  const volHeat = heatBg(vol, maxVol, VOL_RGB, 0.04, 0.22);

  const strongPrice = best || last || posQty !== undefined;
  const bidOrder = order && order.side === 'buy' ? order : undefined;
  const askOrder = order && order.side === 'sell' ? order : undefined;

  return (
    <div
      ref={rowRef}
      className={cn(
        `grid h-6 shrink ${mbo ? GRID_COLS_MBO : GRID_COLS} border-l-2 px-2 font-num text-[11px] leading-none tabular-nums transition-[background-color,opacity] duration-150 ease-out`,
        best
          ? isBid
            ? 'border-l-[#089981]'
            : 'border-l-[#f2385a]'
          : posQty !== undefined
            ? 'border-l-[#e8a854]'
            : 'border-l-transparent',
        last && 'bg-[#222226]',
        posQty !== undefined && 'bg-[#e8a854]/[0.10]',
      )}
    >
      {/* quantidade bid (à esquerda do preço) — clique arma COMPRA LMT */}
      <div
        className="flex items-center justify-end"
        style={isBid && sizeHeat ? { backgroundColor: sizeHeat } : undefined}
      >
        {isBid && (
          <ArmCell
            order={bidOrder}
            fallbackSize={size}
            decimals={sizeDecimals}
            onClick={onArmBid}
            label={`Armar COMPRA LMT ${fmtPrice(price, tick)}`}
          />
        )}
      </div>
      {/* preço */}
      <button
        type="button"
        onClick={onCancelOrder}
        disabled={!order}
        title={order ? 'Cancelar ordem' : undefined}
        className={cn(
          'flex items-center justify-center gap-1 rounded-sm',
          order ? 'cursor-pointer hover:bg-[#222226]' : 'cursor-default',
          posQty !== undefined && 'ring-1 ring-inset ring-[#e8a854]/70',
        )}
      >
        {posQty !== undefined && (
          <span className="inline-flex h-[14px] items-center justify-center rounded-sm bg-[#e8a854] px-0.5 text-[9px] font-bold leading-none text-[#151515]">
            {posQty > 0 ? `+${posQty}` : posQty}
          </span>
        )}
        {last && (
          <span
            className="h-1 w-1 shrink-0 rounded-full bg-[#e8a854]"
            aria-hidden="true"
          />
        )}
        <span className={strongPrice ? 'font-bold text-white' : 'text-[#d1d4dc]'}>
          {fmtPrice(price, tick)}
        </span>
      </button>
      {/* quantidade ask (à direita do preço) — clique arma VENDA LMT */}
      <div
        className="flex items-center justify-start"
        style={!isBid && sizeHeat ? { backgroundColor: sizeHeat } : undefined}
      >
        {!isBid && (
          <ArmCell
            order={askOrder}
            fallbackSize={size}
            decimals={sizeDecimals}
            onClick={onArmAsk}
            label={`Armar VENDA LMT ${fmtPrice(price, tick)}`}
          />
        )}
      </div>
      {/* volume da sessão no nível */}
      <div
        className="flex items-center justify-end"
        style={volHeat ? { backgroundColor: volHeat } : undefined}
      >
        {vol > 0 && <span className="text-[10px] text-[#d1d4dc]">{fmtCompact(vol)}</span>}
      </div>
      {/* delta da sessão no nível */}
      <div
        className={cn(
          'flex items-center justify-end',
          delta > 0 ? 'text-[#089981]' : delta < 0 ? 'text-[#f2385a]' : '',
        )}
      >
        {delta !== 0 && <span>{fmtSignedCompact(delta)}</span>}
      </div>
      {/* ── MBO L3: pulling/stacking do nível (EMA ~3s) ── */}
      {mbo && (
        <div
          className="flex items-center justify-end gap-1 whitespace-nowrap text-[9px]"
          title={`Pulling ↓ ${fmtCompact(pull)} · Stacking ↑ ${fmtCompact(stack)} (últimos ~3s)`}
        >
          {pull > 0 || stack > 0 ? (
            <>
              <span className={pull > 0 ? 'text-[#f2385a]' : 'text-[#3f3f46]'}>
                ↓{fmtCompact(pull)}
              </span>
              <span className={stack > 0 ? 'text-[#089981]' : 'text-[#3f3f46]'}>
                ↑{fmtCompact(stack)}
              </span>
            </>
          ) : (
            <span className="text-[#3f3f46]">·</span>
          )}
        </div>
      )}
      {/* ── MBO L3: fila de ordens individuais do nível ── */}
      {mbo && (
        <div className="flex min-w-0 items-center pr-0.5">
          {queue.length > 0 ? (
            <div
              className="flex h-2 w-full min-w-0 gap-px"
              title={`Fila ${isBid ? 'bid' : 'ask'}: ${queue.map((q) => fmtSize(q, sizeDecimals)).join(' · ')}`}
            >
              {queue.map((q, qi) => (
                <span
                  key={qi}
                  className="h-full rounded-[1px]"
                  style={{
                    width: `${Math.max(3, (q / size) * 100)}%`,
                    backgroundColor: `rgba(${isBid ? BID_RGB : ASK_RGB},${Math.max(0.3, 0.88 - qi * 0.14).toFixed(2)})`,
                  }}
                />
              ))}
            </div>
          ) : (
            <span className="text-[9px] text-[#3f3f46]">·</span>
          )}
        </div>
      )}
    </div>
  );
});

/** Célula clicável da escada: mostra a qtd do book ou a ordem armada no nível. */
function ArmCell({
  order,
  fallbackSize,
  decimals,
  onClick,
  label,
}: {
  order?: Order;
  fallbackSize: number;
  decimals: number;
  onClick?: () => void;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={label}
      aria-label={label}
      className="flex h-6 min-w-0 flex-1 items-center gap-1 rounded-sm px-0.5 transition-colors hover:bg-[#222226]"
    >
      {order && <OrderBadge order={order} />}
      <span className={cn('truncate', order ? 'font-bold text-white' : 'text-[#d1d4dc]')}>
        {order ? order.qty : fmtSize(fallbackSize, decimals)}
      </span>
    </button>
  );
}

function DomSkeleton() {
  return (
    <div className="flex flex-col gap-px px-2 py-1">
      {Array.from({ length: SKELETON_ROWS }, (_, i) => (
        <div key={i} className="h-6 shrink animate-pulse bg-[#222226]" />
      ))}
    </div>
  );
}

// ── Rail de derivativos (γ / vanna / charm) — Task 3-a ──────────────────────

interface GexRailCellProps {
  tick: number;
  mode: DomGexMode;
  /** linha de GEX do strike mais próximo do preço (undefined = fora da cadeia) */
  row?: GexRow;
  /** parede de gamma cujo strike coincide com o da linha */
  wall?: GreekWall;
  maxAbs: number;
  isFlip: boolean;
  flip: number | null;
}

/**
 * Célula da rail: barra horizontal ancorada no eixo central — cresce p/ a
 * direita quando a métrica é positiva (dealer long) e p/ a esquerda quando
 * negativa. Memoizada: só refaz quando preço/métrica/perfil mudam.
 */
const GexRailCell = memo(function GexRailCell({
  tick,
  mode,
  row,
  wall,
  maxAbs,
  isFlip,
  flip,
}: GexRailCellProps) {
  const v = row ? gexMetric(row, mode) : 0;
  const frac =
    row !== undefined && maxAbs > 0 ? Math.min(1, Math.abs(v) / maxAbs) : 0;
  // meia-largura útil (barra ancorada no centro, até o padding da coluna;
  // −1px do offset do eixo central)
  const half = RAIL_W / 2 - RAIL_PAD - 1;
  const w = frac > 0 ? Math.max(2, Math.min(half, frac * half)) : 0;
  const color = v >= 0 ? GEX_POS : GEX_NEG;

  const parts: string[] = [];
  if (wall) {
    parts.push(`γ wall ${fmtPrice(wall.strike, tick)} ${fmtCompact(wall.netGamma)}`);
  }
  if (row) parts.push(`${gexLabel(mode)} ${fmtSignedCompact(v)}`);
  if (isFlip && flip !== null) parts.push(`γ flip ${fmtPrice(flip, tick)}`);
  const tip = parts.join(' · ');

  const body = (
    <div
      className={cn(
        'relative h-6 shrink overflow-hidden',
        isFlip && 'border-l-2 border-[#29b6f6]',
      )}
      aria-label={tip || undefined}
    >
      {/* eixo central (âncora zero das barras) */}
      <div
        className="absolute inset-y-0 left-1/2 w-px -translate-x-1/2 bg-[#27272a]"
        aria-hidden="true"
      />
      {w > 0 && (
        <div
          className="absolute top-1/2 h-3 -translate-y-1/2 rounded-[1px]"
          style={
            v >= 0
              ? {
                  left: 'calc(50% + 1px)',
                  width: `${w}px`,
                  backgroundColor: color,
                  opacity: 0.85,
                }
              : {
                  right: 'calc(50% + 1px)',
                  width: `${w}px`,
                  backgroundColor: color,
                  opacity: 0.85,
                }
          }
        />
      )}
      {isFlip && (
        <span
          className="absolute left-0 top-1/2 -translate-y-1/2 text-[8px] leading-none text-[#29b6f6]"
          aria-hidden="true"
        >
          ▸
        </span>
      )}
      {wall !== undefined && (
        <div
          className={cn(
            'pointer-events-none absolute inset-0',
            v >= 0
              ? 'ring-1 ring-inset ring-[#089981]/60'
              : 'ring-1 ring-inset ring-[#f2385a]/60',
          )}
        />
      )}
    </div>
  );

  if (!tip) return body;
  return (
    <Tooltip>
      <TooltipTrigger asChild>{body}</TooltipTrigger>
      <TooltipContent
        side="left"
        className="rounded border border-[#27272a] bg-[#1f1f23] px-2 py-1 font-num text-[10px] tabular-nums text-[#d1d4dc]"
      >
        {tip}
      </TooltipContent>
    </Tooltip>
  );
});

interface GexRailColumnProps {
  asks: DomLevel[];
  bids: DomLevel[];
  tick: number;
  /** passo de strike do símbolo */
  step: number;
  mode: DomGexMode;
  profile: DomGexProfile;
}

/**
 * Coluna rail alinhada às MESMAS linhas da escada (asks ↓ spread ↓ bids —
 * células h-6 shrink em coluna flex com a mesma altura natural, logo encolhem
 * na mesma proporção). Uma barra por linha com a métrica líquida do strike
 * mais próximo. Mapas strike→linha/wall reconstruídos só quando o perfil muda
 * (memo por [symbol, spot arredondado ao strike] — nunca a cada tick do DOM).
 */
const GexRailColumn = memo(function GexRailColumn({
  asks,
  bids,
  tick,
  step,
  mode,
  profile,
}: GexRailColumnProps) {
  const maxAbs = gexMaxAbs(profile, mode);

  const rowsByStrike = useMemo(() => {
    const m = new Map<number, GexRow>();
    for (const r of profile.rows) m.set(tickIndex(r.strike, tick), r);
    return m;
  }, [profile, tick]);

  const wallsByStrike = useMemo(() => {
    const m = new Map<number, GreekWall>();
    for (const w of profile.walls) m.set(tickIndex(w.strike, tick), w);
    return m;
  }, [profile, tick]);

  // linha da escada mais próxima do gamma flip → marcador ▸ ciano na rail
  const flip = profile.flip;
  let flipPrice: number | null = null;
  if (flip !== null) {
    let bestD = Infinity;
    for (const l of asks) {
      const d = Math.abs(l.p - flip);
      if (d < bestD) {
        bestD = d;
        flipPrice = l.p;
      }
    }
    for (const l of bids) {
      const d = Math.abs(l.p - flip);
      if (d < bestD) {
        bestD = d;
        flipPrice = l.p;
      }
    }
  }

  const cellProps = (l: DomLevel) => ({
    tick,
    mode,
    row: rowsByStrike.get(strikeIdxOf(l.p, step, tick)),
    wall: wallsByStrike.get(strikeIdxOf(l.p, step, tick)),
    maxAbs,
    isFlip: flipPrice !== null && l.p === flipPrice,
    flip,
  });

  return (
    <div
      className="flex shrink-0 flex-col overflow-hidden border-l border-[#27272a] bg-[#18181b]"
      style={{ width: RAIL_W }}
    >
      {asks.map((l) => (
        <GexRailCell key={`a${l.p}`} {...cellProps(l)} />
      ))}
      {/* linha central do spread — banda contínua com a escada */}
      <div className="h-6 shrink bg-[#101012]" />
      {bids.map((l) => (
        <GexRailCell key={`b${l.p}`} {...cellProps(l)} />
      ))}
    </div>
  );
});

// ── Strip de fluxo vivo (absorção / exaustão / iceberg) — Task 3-a ──────────

interface FlowStripCellProps {
  sig?: FlowSignal;
  tick: number;
}

/**
 * Célula do strip: pinta o nível com a cor do sinal e pulsa via CSS
 * (keyframe domFlowPulse, alpha ∝ strength) — sem JS por frame.
 * Memoizada: só refaz quando o sinal do nível muda.
 */
const FlowStripCell = memo(function FlowStripCell({ sig, tick }: FlowStripCellProps) {
  if (!sig) return <div className="h-6 shrink" />;
  const s = Math.min(1, Math.max(0, sig.strength));
  // alpha do spec: 0.25 + 0.55·s·(0.6 + 0.4·sin(t/220)) → lo (sen=−1), hi (sen=+1)
  const lo = 0.25 + 0.55 * s * 0.2;
  const hi = 0.25 + 0.55 * s;
  const price = priceOf(sig.priceIdx, tick);
  const tip = `${FLOW_KIND_LABEL[sig.kind]} ${sig.side === 'buy' ? 'comprada' : 'vendida'} · ${fmtPrice(price, tick)} · vol ${fmtCompact(sig.vol)}`;
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <div
          className="h-6 shrink"
          aria-label={tip}
          style={
            {
              backgroundColor: FLOW_COLOR[sig.kind],
              animation: `domFlowPulse ${FLOW_PULSE_MS}ms ease-in-out infinite`,
              '--flo': lo.toFixed(3),
              '--fhi': hi.toFixed(3),
            } as React.CSSProperties
          }
        />
      </TooltipTrigger>
      <TooltipContent
        side="right"
        className="rounded border border-[#27272a] bg-[#1f1f23] px-2 py-1 font-num text-[10px] tabular-nums text-[#d1d4dc]"
      >
        {tip}
      </TooltipContent>
    </Tooltip>
  );
});

interface FlowStripColumnProps {
  asks: DomLevel[];
  bids: DomLevel[];
  tick: number;
}

/**
 * Faixa fina à extrema esquerda da escada: um nível por linha, pintado quando
 * há sinal de fluxo vivo (until > agora). Interval de 250ms só para expirar
 * TTL — o pulse em si é CSS. Sem sinais → transparente, mas presente (mantém
 * o grid estável).
 */
const FlowStripColumn = memo(function FlowStripColumn({
  asks,
  bids,
  tick,
}: FlowStripColumnProps) {
  const signals = useTerminalStore((s) => s.flowSignals);
  const [ttlTick, setTtlTick] = useState(0);

  const hasSignals = signals.length > 0;
  useEffect(() => {
    if (!hasSignals) return;
    const id = window.setInterval(() => setTtlTick((n) => n + 1), FLOW_TICK_MS);
    return () => window.clearInterval(id);
  }, [hasSignals]);

  // sinal dominante por nível (mais forte; empate → mais recente), só vivos
  const liveByPriceIdx = useMemo(() => {
    const now = Date.now();
    const m = new Map<number, FlowSignal>();
    for (const s of signals) {
      if (s.until <= now) continue;
      const prev = m.get(s.priceIdx);
      if (
        prev === undefined ||
        s.strength > prev.strength ||
        (s.strength === prev.strength && s.t > prev.t)
      ) {
        m.set(s.priceIdx, s);
      }
    }
    return m;
    // ttlTick reavalia o TTL a cada FLOW_TICK_MS
  }, [signals, ttlTick]);

  return (
    <div
      className="flex shrink-0 flex-col overflow-hidden"
      style={{ width: FLOW_STRIP_W }}
    >
      {/* keyframe do pulse, injetado uma única vez */}
      <style>{FLOW_PULSE_CSS}</style>
      {asks.map((l) => (
        <FlowStripCell
          key={`a${l.p}`}
          sig={liveByPriceIdx.get(tickIndex(l.p, tick))}
          tick={tick}
        />
      ))}
      <div className="h-6 shrink bg-[#101012]" />
      {bids.map((l) => (
        <FlowStripCell
          key={`b${l.p}`}
          sig={liveByPriceIdx.get(tickIndex(l.p, tick))}
          tick={tick}
        />
      ))}
    </div>
  );
});

interface DomPanelProps {
  className?: string;
}

const QTIES = [1, 2, 5, 10, 25] as const;

/** Widget DOM estilo ATAS Web: escada 12×12 + click trading + rail de
 * derivativos (γ/vanna/charm) + strip de fluxo vivo. */
export default function DomPanel({ className }: DomPanelProps) {
  const dom = useTerminalStore((s) => s.dom);
  const session = useTerminalStore((s) => s.session);
  const symbol = useTerminalStore((s) => s.symbol);
  const replayActive = useTerminalStore((s) => s.replay.active);
  // rail de derivativos + strip de fluxo (Task 3-a)
  const showDomGex = useTerminalStore((s) => s.showDomGex);
  const domGexMode = useTerminalStore((s) => s.domGexMode);
  const showDomFlowStrip = useTerminalStore((s) => s.showDomFlowStrip);
  // colunas MBO L3 (pulling/stacking + fila de ordens)
  const showDomMbo = useTerminalStore((s) => s.showDomMbo);
  const domL3 = useTerminalStore((s) => s.domL3);
  const patchSettings = useTerminalStore((s) => s.patchSettings);

  // trading
  const orders = useTradingStore((s) => s.orders);
  const position = useTradingStore((s) => s.position);
  const realizedPnl = useTradingStore((s) => s.realizedPnl);
  const qty = useTradingStore((s) => s.qty);
  const atmTarget = useTradingStore((s) => s.atmTarget);
  const atmStop = useTradingStore((s) => s.atmStop);
  const { armLmt, placeMkt, cancelOrder, cancelAll, flatten, setQty, setAtm } =
    useTradingStore.getState();

  const { tick, sizeDecimals } = symbolMeta(symbol);

  const asks = useMemo<DomLevel[]>(() => (dom ? dom.asks.slice(0, LEVELS) : []), [dom]);
  const bids = useMemo<DomLevel[]>(() => (dom ? dom.bids.slice(0, LEVELS) : []), [dom]);

  // ── MBO L3: mapa idx → {pull, stack} + fila de ordens por nível ────────────
  const l3Map = useMemo(() => {
    const m = new Map<number, DomL3Row>();
    if (showDomMbo && domL3) for (const r of domL3.rows) m.set(r.idx, r);
    return m;
  }, [showDomMbo, domL3]);
  const queueByIdx = useMemo(() => {
    if (!showDomMbo || !dom) return null;
    const m = new Map<number, number[]>();
    for (const l of asks) m.set(tickIndex(l.p, tick), decomposeQueue(tickIndex(l.p, tick), 1, l.s, sizeDecimals));
    for (const l of bids) m.set(tickIndex(l.p, tick), decomposeQueue(tickIndex(l.p, tick), 0, l.s, sizeDecimals));
    return m;
  }, [showDomMbo, dom, asks, bids, tick, sizeDecimals]);

  const maxSize = useMemo(() => {
    let max = 0;
    for (const l of asks) if (l.s > max) max = l.s;
    for (const l of bids) if (l.s > max) max = l.s;
    return max;
  }, [asks, bids]);

  const maxVol = useMemo(() => {
    if (!dom) return 0;
    let max = 0;
    for (const l of asks) {
      const v = dom.vol[tickIndex(l.p, tick)] ?? 0;
      if (v > max) max = v;
    }
    for (const l of bids) {
      const v = dom.vol[tickIndex(l.p, tick)] ?? 0;
      if (v > max) max = v;
    }
    return max;
  }, [asks, bids, dom, tick]);

  // lados vêm ordenados DESC: melhor ask = menor preço (fim), melhor bid = maior preço (início)
  const bestBid = dom?.bids[0]?.p ?? null;
  const bestAsk = dom && dom.asks.length ? dom.asks[dom.asks.length - 1].p : null;
  const spreadTicks =
    bestBid !== null && bestAsk !== null
      ? Math.max(0, Math.round((bestAsk - bestBid) / tick))
      : null;

  const last = session?.last ?? null;
  const lastIdx = last !== null ? tickIndex(last, tick) : null;

  // ── rail de derivativos (γ/vanna/charm) ────────────────────────────────────
  // spot arredondado AO PASSO DE STRIKE: a cadeia só recalcula quando o último
  // preço cruza meio strike (~1Hz de chegada), nunca a cada tick do DOM.
  const gexStep = useMemo(() => strikeStep(symbol, tick), [symbol, tick]);
  const gexSpot =
    last !== null && Number.isFinite(last) && last > 0
      ? Math.round(last / gexStep) * gexStep
      : 0;
  const gexProfile = useMemo<DomGexProfile | null>(
    () =>
      gexSpot > 0
        ? domGexProfile(buildChain(symbol, gexSpot, 'flowterminal'), tick)
        : null,
    [symbol, gexSpot, tick],
  );
  // Σ do gamma líquido p/ o chip GEX± do chrome (O(strikes), barato)
  const gexNetSum = gexProfile ? netGex(gexProfile.rows) : 0;
  const sessionDeltaCls =
    session && session.delta > 0
      ? 'text-[#089981]'
      : session && session.delta < 0
        ? 'text-[#f2385a]'
        : 'text-[#d1d4dc]';

  // mapa preço (tick idx) → ordem armada nesse nível
  const orderByIdx = useMemo(() => {
    const m = new Map<number, Order>();
    for (const o of orders) {
      const p = o.role === 'stop' ? o.trigger : o.price;
      if (p === null) continue;
      m.set(tickIndex(p, tick), o);
    }
    return m;
  }, [orders, tick]);

  const posIdx = position.qty !== 0 ? tickIndex(position.avg, tick) : null;
  const open = unrealizedPnl(position, last);
  const openCls = open > 0 ? 'text-[#089981]' : open < 0 ? 'text-[#f2385a]' : 'text-[#d1d4dc]';
  const realCls =
    realizedPnl > 0 ? 'text-[#089981]' : realizedPnl < 0 ? 'text-[#f2385a]' : 'text-[#787b86]';

  return (
    <div
      className={cn(
        'flex h-full w-full flex-col overflow-hidden bg-[#18181b]',
        className,
      )}
    >
      {/* chrome do widget */}
      <div className="flex h-9 shrink-0 items-center gap-2 border-b border-[#27272a] bg-[#151515] px-2">
        <GripVertical className="h-3.5 w-3.5 shrink-0 text-[#5d606b]" aria-hidden="true" />
        <span className="whitespace-nowrap text-[12px] font-bold text-white">
          #{symbol}
        </span>
        <span className="whitespace-nowrap text-[10px] text-[#787b86]">DOM</span>
        {replayActive && (
          <span className="shrink-0 rounded bg-[#33291a] px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-wider text-[#e8a854]">
            replay · book ao vivo
          </span>
        )}
        {/* toggle MBO L3: colunas Pulling/Stacking + fila de ordens */}
        <button
          type="button"
          aria-pressed={showDomMbo}
          aria-label="Colunas MBO nível 3 (Pulling/Stacking e fila de ordens)"
          title="MBO L3: Pulling/Stacking + fila de ordens por nível"
          onClick={() => patchSettings({ showDomMbo: !showDomMbo })}
          className={cn(
            'shrink-0 rounded px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-wider transition-colors',
            showDomMbo
              ? 'bg-[#27272a] text-white'
              : 'bg-[#222226] text-[#787b86] hover:text-[#d1d4dc]',
          )}
        >
          MBO·L3
        </button>
        {/* chip GEX±: sinal do gamma líquido agregado (dealer long/short) */}
        {showDomGex && gexProfile !== null && gexProfile.rows.length > 0 && (
          <Tooltip>
            <TooltipTrigger asChild>
              <span
                className={cn(
                  'shrink-0 rounded px-1 py-0.5 text-[8px] font-bold uppercase tracking-wider',
                  gexNetSum > 0
                    ? 'bg-[#12241f] text-[#089981]'
                    : gexNetSum < 0
                      ? 'bg-[#2b161c] text-[#f2385a]'
                      : 'bg-[#222226] text-[#787b86]',
                )}
              >
                GEX{gexNetSum > 0 ? '+' : gexNetSum < 0 ? '−' : '±'}
              </span>
            </TooltipTrigger>
            <TooltipContent
              side="bottom"
              className="rounded border border-[#27272a] bg-[#1f1f23] px-2 py-1 font-num text-[10px] tabular-nums text-[#d1d4dc]"
            >
              GEX líquido {fmtSignedCompact(gexNetSum)} ·{' '}
              {gexNetSum > 0
                ? 'dealer long · mean revert'
                : gexNetSum < 0
                  ? 'dealer short · momentum'
                  : 'neutro'}
              {gexProfile.flip !== null && ` · flip ${fmtPrice(gexProfile.flip, tick)}`}
              {gexProfile.walls.length > 0 &&
                ` · walls ${gexProfile.walls
                  .map((w) => fmtPrice(w.strike, tick))
                  .join(' / ')}`}
            </TooltipContent>
          </Tooltip>
        )}
        <div className="min-w-0 flex-1" />
        <ChromeBtn label="Configurações">
          <Settings2 className="h-3.5 w-3.5" aria-hidden="true" />
        </ChromeBtn>
        <ChromeBtn label="Painel">
          <PanelRight className="h-3.5 w-3.5" aria-hidden="true" />
        </ChromeBtn>
        <ChromeBtn label="Maximizar">
          <Maximize2 className="h-3.5 w-3.5" aria-hidden="true" />
        </ChromeBtn>
        <ChromeBtn label="Fechar">
          <X className="h-3.5 w-3.5" aria-hidden="true" />
        </ChromeBtn>
      </div>

      {/* cabeçalho das colunas (+ strip | toggles γ/VN/CH da rail) — as três
          partes espelham exatamente as colunas do corpo abaixo */}
      <div className="flex h-6 shrink-0 bg-[#101012] text-[9px] uppercase leading-none text-[#787b86]">
        {showDomFlowStrip && (
          <div className="shrink-0" style={{ width: FLOW_STRIP_W }} aria-hidden="true" />
        )}
        <div className={`grid min-w-0 flex-1 ${showDomMbo ? GRID_COLS_MBO : GRID_COLS} px-2`}>
          <span className="flex items-center justify-end">Bid</span>
          <span className="flex items-center justify-center">Preço</span>
          <span className="flex items-center justify-start">Ask</span>
          <span className="flex items-center justify-end">Vol</span>
          <span className="flex items-center justify-end">Δ</span>
          {showDomMbo && (
            <>
              <span
                className="flex items-center justify-end"
                title="Pulling ↓ (cancelado) / Stacking ↑ (adicionado) — EMA ~3s"
              >
                P/S
              </span>
              <span className="flex items-center justify-start" title="Fila de ordens individuais do nível">
                Fila
              </span>
            </>
          )}
        </div>
        {showDomGex && (
          <div
            className="flex shrink-0 items-center justify-center"
            style={{ width: RAIL_W }}
          >
            <ToggleGroup
              type="single"
              value={domGexMode}
              onValueChange={(v) => {
                if (v === 'gamma' || v === 'vanna' || v === 'charm') {
                  patchSettings({ domGexMode: v });
                }
              }}
              className="gap-px"
              aria-label="Métrica do rail de derivativos"
            >
              <ToggleGroupItem value="gamma" aria-label="Gamma" className={RAIL_TOGGLE_CLS}>
                γ
              </ToggleGroupItem>
              <ToggleGroupItem value="vanna" aria-label="Vanna" className={RAIL_TOGGLE_CLS}>
                VN
              </ToggleGroupItem>
              <ToggleGroupItem value="charm" aria-label="Charm" className={RAIL_TOGGLE_CLS}>
                CH
              </ToggleGroupItem>
            </ToggleGroup>
          </div>
        )}
      </div>

      {/* corpo: strip de fluxo | asks ↓ spread ↓ bids | rail de derivativos */}
      <div className="flex min-h-0 flex-1 overflow-hidden">
        {showDomFlowStrip && dom !== null && (
          <FlowStripColumn asks={asks} bids={bids} tick={tick} />
        )}
        {/* escada original (colunas, flash, click trading) — intocada */}
        <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
          {dom === null ? (
            <DomSkeleton />
          ) : (
            <>
              {asks.map((l, i) => (
                <DomRow
                  key={`a${l.p}`}
                  price={l.p}
                  side="ask"
                  size={l.s}
                  vol={dom.vol[tickIndex(l.p, tick)] ?? 0}
                  delta={dom.delta[tickIndex(l.p, tick)] ?? 0}
                  best={i === asks.length - 1}
                  last={lastIdx !== null && tickIndex(l.p, tick) === lastIdx}
                  maxSize={maxSize}
                  maxVol={maxVol}
                  tick={tick}
                  sizeDecimals={sizeDecimals}
                  order={orderByIdx.get(tickIndex(l.p, tick))}
                  posQty={posIdx === tickIndex(l.p, tick) ? position.qty : undefined}
                  mbo={showDomMbo}
                  pull={l3Map.get(tickIndex(l.p, tick))?.pull ?? 0}
                  stack={l3Map.get(tickIndex(l.p, tick))?.stack ?? 0}
                  queue={queueByIdx?.get(tickIndex(l.p, tick)) ?? EMPTY_QUEUE}
                  onArmAsk={() => armLmt('sell', l.p)}
                  onCancelOrder={
                    orderByIdx.has(tickIndex(l.p, tick))
                      ? () => {
                          const o = orderByIdx.get(tickIndex(l.p, tick));
                          if (o) cancelOrder(o.id);
                        }
                      : undefined
                  }
                />
              ))}
              {/* linha central: spread + último preço da sessão */}
              <div className="flex h-6 shrink items-center justify-center gap-2 bg-[#101012] font-num tabular-nums text-[#787b86]">
                <span className="text-[10px]">
                  spread {spreadTicks !== null ? spreadTicks : '—'}
                </span>
                {last !== null && (
                  <span className="text-[11px] font-bold text-white">
                    últ {fmtPrice(last, tick)}
                  </span>
                )}
              </div>
              {bids.map((l, i) => (
                <DomRow
                  key={`b${l.p}`}
                  price={l.p}
                  side="bid"
                  size={l.s}
                  vol={dom.vol[tickIndex(l.p, tick)] ?? 0}
                  delta={dom.delta[tickIndex(l.p, tick)] ?? 0}
                  best={i === 0}
                  last={lastIdx !== null && tickIndex(l.p, tick) === lastIdx}
                  maxSize={maxSize}
                  maxVol={maxVol}
                  tick={tick}
                  sizeDecimals={sizeDecimals}
                  order={orderByIdx.get(tickIndex(l.p, tick))}
                  posQty={posIdx === tickIndex(l.p, tick) ? position.qty : undefined}
                  mbo={showDomMbo}
                  pull={l3Map.get(tickIndex(l.p, tick))?.pull ?? 0}
                  stack={l3Map.get(tickIndex(l.p, tick))?.stack ?? 0}
                  queue={queueByIdx?.get(tickIndex(l.p, tick)) ?? EMPTY_QUEUE}
                  onArmBid={() => armLmt('buy', l.p)}
                  onCancelOrder={
                    orderByIdx.has(tickIndex(l.p, tick))
                      ? () => {
                          const o = orderByIdx.get(tickIndex(l.p, tick));
                          if (o) cancelOrder(o.id);
                        }
                      : undefined
                  }
                />
              ))}
            </>
          )}
        </div>
        {showDomGex &&
          dom !== null &&
          (gexProfile !== null && gexProfile.rows.length > 0 ? (
            <GexRailColumn
              asks={asks}
              bids={bids}
              tick={tick}
              step={gexStep}
              mode={domGexMode}
              profile={gexProfile}
            />
          ) : (
            // coluna fantasma: preserva a largura da rail sem perfil (spot/rows)
            <div
              className="shrink-0 border-l border-[#27272a] bg-[#18181b]"
              style={{ width: RAIL_W }}
              aria-hidden="true"
            />
          ))}
      </div>

      {/* ── faixa de posição (só quando há posição ou PnL) ── */}
      {(position.qty !== 0 || realizedPnl !== 0 || orders.length > 0) && (
        <div className="flex h-7 shrink-0 items-center gap-2 border-t border-[#27272a] bg-[#18181b] px-2 text-[10px] font-num tabular-nums">
          <span
            className={cn(
              'inline-flex items-center gap-1 rounded-sm px-1.5 py-0.5 text-[10px] font-bold',
              position.qty > 0
                ? 'bg-[#12241f] text-[#089981]'
                : position.qty < 0
                  ? 'bg-[#2b161c] text-[#f2385a]'
                  : 'bg-[#222226] text-[#787b86]',
            )}
          >
            {position.qty !== 0
              ? `POS ${position.qty > 0 ? '+' : ''}${position.qty} @ ${fmtPrice(position.avg, tick)}`
              : 'sem posição'}
          </span>
          {position.qty !== 0 && (
            <span className={openCls}>
              aberto {open >= 0 ? '+' : ''}
              {Math.round(open)} pts
            </span>
          )}
          <span className={realCls}>
            real {realizedPnl >= 0 ? '+' : ''}
            {Math.round(realizedPnl)} pts
          </span>
          <div className="ml-auto flex items-center gap-1">
            {orders.length > 0 && (
              <button
                type="button"
                onClick={cancelAll}
                className="rounded border border-[#27272a] px-1.5 py-0.5 text-[9px] text-[#d1d4dc] transition-colors hover:bg-[#222226]"
              >
                cancelar ({orders.length})
              </button>
            )}
            {position.qty !== 0 && (
              <button
                type="button"
                onClick={flatten}
                className="rounded border border-[#e8a854] bg-[#2a2519] px-1.5 py-0.5 text-[9px] font-semibold text-[#e8a854] transition-colors hover:bg-[#352e1d]"
              >
                zerar
              </button>
            )}
          </div>
        </div>
      )}

      {/* ── controles de trading ── */}
      <div className="flex shrink-0 items-center gap-1.5 border-t border-[#27272a] bg-[#101012] px-2 py-1.5">
        <button
          type="button"
          onClick={() => placeMkt('buy')}
          aria-label="Comprar a mercado"
          className="h-7 flex-1 rounded bg-[#089981] text-[10px] font-bold uppercase text-white transition-colors hover:bg-[#0aa88e]"
        >
          compra
        </button>
        <select
          value={qty}
          onChange={(e) => setQty(Number(e.target.value))}
          aria-label="Quantidade (contratos)"
          className="h-7 w-[52px] rounded border border-[#27272a] bg-[#222226] px-1 text-center font-num text-[11px] text-[#d1d4dc] outline-none"
        >
          {QTIES.map((q) => (
            <option key={q} value={q}>
              {q}
            </option>
          ))}
        </select>
        <button
          type="button"
          onClick={() => placeMkt('sell')}
          aria-label="Vender a mercado"
          className="h-7 flex-1 rounded bg-[#f2385a] text-[10px] font-bold uppercase text-white transition-colors hover:bg-[#f34e6c]"
        >
          venda
        </button>
        <span className="h-5 w-px shrink-0 bg-[#27272a]" />
        <label className="flex items-center gap-0.5 text-[9px] uppercase text-[#787b86]">
          A
          <input
            type="number"
            min={0}
            value={atmTarget}
            onChange={(e) => setAtm({ atmTarget: Number(e.target.value) })}
            aria-label="Alvo ATM (ticks)"
            title="Alvo da estratégia ATM (ticks)"
            className="h-7 w-11 rounded border border-[#27272a] bg-[#222226] px-1 text-center font-num text-[11px] text-[#d1d4dc] outline-none"
          />
        </label>
        <label className="flex items-center gap-0.5 text-[9px] uppercase text-[#787b86]">
          S
          <input
            type="number"
            min={0}
            value={atmStop}
            onChange={(e) => setAtm({ atmStop: Number(e.target.value) })}
            aria-label="Stop ATM (ticks)"
            title="Stop da estratégia ATM (ticks)"
            className="h-7 w-11 rounded border border-[#27272a] bg-[#222226] px-1 text-center font-num text-[11px] text-[#d1d4dc] outline-none"
          />
        </label>
      </div>

      {/* rodapé: estatísticas da sessão */}
      <div className="flex h-7 shrink-0 items-center gap-3 border-t border-[#27272a] px-2 text-[10px]">
        <span className="text-[#787b86]">
          VOL{' '}
          <span className="font-num tabular-nums text-[#d1d4dc]">
            {session ? fmtCompact(session.volume) : '—'}
          </span>
        </span>
        <span className="text-[#787b86]">
          Δ{' '}
          <span className={`font-num tabular-nums ${sessionDeltaCls}`}>
            {session ? fmtSignedCompact(session.delta) : '—'}
          </span>
        </span>
        <span className="ml-auto whitespace-nowrap text-[#5d606b]">
          clique arma LMT · MKT executa
        </span>
      </div>
    </div>
  );
}
