'use client';

import { useEffect, useState } from 'react';
import { Download, FolderGit2, TerminalSquare } from 'lucide-react';

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useTerminalStore } from '@/store/terminal';

/** Fallback estático caso o manifest não possa ser buscado. */
const FALLBACK = { file: 'FlowTerminal-rodada-2.zip', round: 2, size: '~300 KB' };

interface RepoInfo {
  file: string;
  round: number;
  size?: string;
  files?: number;
  builtAt?: string;
}

/**
 * Dialog "Código-fonte" — download do repositório por rodada + instruções de
 * instalação local. O botão aponta para /api/repo/download, que serve o zip
 * estático ou o gera on-demand (nunca depende de fetch prévio para aparecer).
 */
export function DownloadDialog() {
  const dialog = useTerminalStore((s) => s.dialog);
  const setDialog = useTerminalStore((s) => s.setDialog);
  const [info, setInfo] = useState<RepoInfo>(FALLBACK);

  useEffect(() => {
    if (dialog !== 'download') return;
    let alive = true;
    fetch('/downloads/latest.json', { cache: 'no-store' })
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error(String(r.status)))))
      .then((j: RepoInfo) => {
        if (alive && j && j.file && j.round) setInfo(j);
      })
      .catch(() => {
        /* mantém o fallback */
      });
    return () => {
      alive = false;
    };
  }, [dialog]);

  return (
    <Dialog
      open={dialog === 'download'}
      onOpenChange={(o) => {
        if (!o) setDialog('none');
      }}
    >
      <DialogContent className="max-w-md rounded-md border-[#27272a] bg-[#1f1f23] p-4 sm:max-w-md">
        <DialogHeader className="gap-0.5">
          <DialogTitle className="flex items-center gap-2 text-[13px] font-bold text-white">
            <FolderGit2 className="h-4 w-4 text-[#a1a1aa]" aria-hidden="true" />
            Código-fonte · Rodada {info.round}
          </DialogTitle>
          <DialogDescription className="text-[10px] text-[#787b86]">
            repositório completo do FlowTerminal (.zip) para instalação local
          </DialogDescription>
        </DialogHeader>

        {/* botão principal — sempre visível */}
        <a
          href={`/api/repo/download?round=${info.round}`}
          download={info.file}
          className="mt-3 flex h-11 items-center justify-center gap-2 rounded bg-[#3f3f46] px-4 text-[13px] font-semibold text-white transition-colors hover:bg-[#52525b]"
          aria-label={`Baixar ${info.file}`}
        >
          <Download className="h-4 w-4" aria-hidden="true" />
          Baixar {info.file}
        </a>

        <div className="mt-2 flex items-center justify-between text-[10px] text-[#787b86]">
          <span>
            {info.size ?? FALLBACK.size}
            {typeof info.files === 'number' ? ` · ${info.files} arquivos` : ''}
          </span>
          <a
            className="underline decoration-[rgba(255,255,255,0.08)] underline-offset-2 hover:text-[#d1d4dc]"
            href={`/downloads/${info.file}`}
            download
          >
            link direto
          </a>
        </div>

        {/* instruções */}
        <div className="mt-4 rounded border border-[#27272a] bg-[#101012] p-3">
          <div className="mb-2 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wider text-[#787b86]">
            <TerminalSquare className="h-3.5 w-3.5" aria-hidden="true" />
            Instalação local
          </div>
          <ol className="list-decimal space-y-1.5 pl-4 text-[11px] leading-relaxed text-[#d1d4dc]">
            <li>
              Extraia o zip e entre na pasta:{' '}
              <code className="rounded bg-[#222226] px-1 py-0.5 font-num text-[10px] text-[#a3bdd4]">
                flowterminal
              </code>
            </li>
            <li>
              Instale as dependências:{' '}
              <code className="rounded bg-[#222226] px-1 py-0.5 font-num text-[10px] text-[#a3bdd4]">
                bun install
              </code>{' '}
              (ou <span className="font-num text-[10px]">npm install</span>)
            </li>
            <li>
              Terminal 1 — motor de mercado:{' '}
              <code className="rounded bg-[#222226] px-1 py-0.5 font-num text-[10px] text-[#a3bdd4]">
                cd mini-services/market-data && bun run dev
              </code>{' '}
              (porta 3003)
            </li>
            <li>
              Terminal 2 — app web:{' '}
              <code className="rounded bg-[#222226] px-1 py-0.5 font-num text-[10px] text-[#a3bdd4]">
                bun run dev
              </code>{' '}
              e abra <span className="font-num text-[10px]">http://localhost:3000</span>
            </li>
          </ol>
          <p className="mt-2 text-[10px] leading-relaxed text-[#787b86]">
            O terminal conecta sozinho ao motor (gateway com fallback direto na porta 3003). Sem
            chaves de API, sem banco de dados — dados 100% simulados.
          </p>
        </div>

        <div className="mt-3 flex items-center justify-between">
          <span className="text-[10px] text-[#787b86]">
            {info.builtAt ? `build ${info.builtAt}` : ''}
          </span>
          <button
            type="button"
            onClick={() => setDialog('none')}
            className="h-8 rounded bg-[#222226] px-3 text-[11px] text-[#d1d4dc] transition-colors hover:bg-[#27272a]"
          >
            Fechar
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
