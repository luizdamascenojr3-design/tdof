'use client';

import { type ComponentType, type ReactNode } from 'react';
import { Undo2 } from 'lucide-react';
import {
  AlignHorizontalDistributeCenter,
  ArrowDownWideNarrow,
  ArrowRight,
  ArrowRightToLine,
  BarChartHorizontal,
  Circle,
  Clock,
  Crosshair,
  Hexagon,
  Layers2,
  List,
  Lock,
  Minus,
  MoreHorizontal,
  MoveVertical,
  Percent,
  PenLine,
  RectangleHorizontal,
  Rows3,
  Ruler,
  Scan,
  Sparkles,
  Spline,
  Square,
  StickyNote,
  Target,
  Trash2,
  Triangle,
  Type,
  ZoomIn,
} from 'lucide-react';

import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { DRAW_TOOLS, useDrawingStore } from '@/lib/drawings';
import { useTerminalStore } from '@/store/terminal';
import { useIsMobile } from '@/hooks/use-mobile';

interface ToolDef {
  id: string;
  label: string;
  Icon: ComponentType<{ className?: string }>;
  /** id da ferramenta funcional no store de desenhos (quando implementada) */
  mapsTo?: (typeof DRAW_TOOLS)[number];
}

/** Ordem das ferramentas de desenho (nomes ATAS). */
const TOOLS: ToolDef[] = [
  { id: 'crosshair', label: 'Crosshair (navegação)', Icon: Crosshair },
  { id: 'trend', label: 'Tendência', Icon: PenLine, mapsTo: 'trend' },
  { id: 'hline', label: 'Linha horizontal', Icon: Minus, mapsTo: 'hline' },
  { id: 'hray', label: 'Raio horizontal', Icon: ArrowRightToLine, mapsTo: 'hray' },
  { id: 'vline', label: 'Linha vertical', Icon: MoveVertical, mapsTo: 'vline' },
  { id: 'rect', label: 'Retângulo', Icon: Square, mapsTo: 'rect' },
  { id: 'ellipse', label: 'Elipse', Icon: Circle, mapsTo: 'ellipse' },
  { id: 'triangle', label: 'Triângulo', Icon: Triangle, mapsTo: 'triangle' },
  { id: 'text', label: 'Texto', Icon: Type, mapsTo: 'text' },
  { id: 'ruler', label: 'Régua (medir)', Icon: Ruler, mapsTo: 'ruler' },
  { id: 'fib', label: 'Fibonacci (retração)', Icon: Layers2, mapsTo: 'fib' },
  { id: 'fibext', label: 'Fibonacci (extensão)', Icon: Percent, mapsTo: 'fibext' },
  { id: 'rrisk', label: 'Risco/Retorno (Long/Short)', Icon: Target, mapsTo: 'rrisk' },
  { id: 'arrow', label: 'Seta', Icon: ArrowRight, mapsTo: 'arrow' },
  { id: 'range', label: 'Canal de range', Icon: RectangleHorizontal, mapsTo: 'range' },
  { id: 'mlevel', label: 'Níveis matemáticos', Icon: AlignHorizontalDistributeCenter, mapsTo: 'mlevel' },
  { id: 'vprof', label: 'Volume Profile (range fixo)', Icon: Rows3, mapsTo: 'vprof' },
  { id: 'volume-h', label: 'Volume horizontal', Icon: BarChartHorizontal },
  { id: 'area', label: 'Seleção de área', Icon: Scan },
  { id: 'market-profile', label: 'Market profile', Icon: Hexagon },
  { id: 'note', label: 'Nota', Icon: StickyNote },
  { id: 'curve', label: 'Curva', Icon: Spline },
  { id: 'zoom', label: 'Lupa', Icon: ZoomIn },
  { id: 'patterns', label: 'Padrões', Icon: Sparkles },
];

/** Grupo inferior: desfcé/apaga desenhos; resto visual. */
const BOTTOM_TOOLS: ToolDef[] = [
  { id: 'sort-time', label: 'Ordenar por tempo', Icon: Clock },
  { id: 'sort-price', label: 'Ordenar por preço', Icon: ArrowDownWideNarrow },
  { id: 'lock', label: 'Bloquear', Icon: Lock },
  { id: 'objects', label: 'Lista de objetos', Icon: List },
  { id: 'more', label: 'Mais', Icon: MoreHorizontal },
  { id: 'remove', label: 'Remover desenhos', Icon: Trash2 },
];

function Hint({ children, label }: { children: ReactNode; label: string }) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>{children}</TooltipTrigger>
      <TooltipContent
        side="right"
        className="rounded border border-[#27272a] bg-[#1f1f23] px-2 py-1 text-[10px] text-[#d1d4dc]"
      >
        {label}
      </TooltipContent>
    </Tooltip>
  );
}

const BTN =
  'flex h-8 w-8 shrink-0 items-center justify-center rounded transition-colors';
const BTN_IDLE = 'text-[#787b86] hover:bg-[#222226] hover:text-[#d1d4dc]';
/* ferramenta ativa: destaque neutro sólido (cinza claro) — sem neon */
const BTN_ACTIVE =
  'bg-[#27272a] text-white hover:bg-[#3f3f46] hover:text-white';


/**
 * Barra vertical de ferramentas de desenho (estilo ATAS).
 * ENCAIXADA: coluna lateral fixa, opaca e com divisória sólida — não
 * flutua sobre o gráfico e não bloqueia nenhuma informação do canvas.
 * Ferramentas funcionais escrevem no store de desenhos (lib/drawings) e o
 * canvas do gráfico renderiza/cria os objetos; desfazer e limpar operam na
 * chave symbol|tf atual.
 */
export function DrawingToolbar() {
  const isMobile = useIsMobile();
  const tool = useDrawingStore((s) => s.tool);
  const setTool = useDrawingStore((s) => s.setTool);
  const items = useDrawingStore((s) => s.items);
  const symbol = useTerminalStore((s) => s.symbol);
  const tf = useTerminalStore((s) => s.tf);
  const count = items[`${symbol}|${tf}`]?.length ?? 0;

  if (isMobile) return null;

  return (
    <div
      role="toolbar"
      aria-label="Ferramentas de desenho"
      className="scrollbar-none flex w-11 shrink-0 flex-col items-center gap-0.5 overflow-y-auto border-r border-[#27272a] bg-[#151515] py-1.5"
    >
      {TOOLS.map(({ id, label, Icon, mapsTo }) => {
        const functional = id === 'crosshair' || mapsTo !== undefined;
        const active = functional && tool === (mapsTo ?? 'crosshair');
        return (
          <Hint key={id} label={functional ? label : `${label} · em breve`}>
            <button
              type="button"
              aria-label={label}
              aria-pressed={active}
              onClick={() => {
                if (mapsTo) setTool(mapsTo);
                else if (id === 'crosshair') setTool('crosshair');
              }}
              className={`${BTN} ${active ? BTN_ACTIVE : BTN_IDLE}`}
            >
              <Icon className="h-4 w-4" />
            </button>
          </Hint>
        );
      })}

      {/* empurra o grupo inferior para o fundo quando há espaço */}
      <div className="my-auto" />

      {BOTTOM_TOOLS.map(({ id, label, Icon }) => {
        if (id === 'objects') {
          return (
            <Hint key={id} label={`${label} (${count})`}>
              <button
                type="button"
                aria-label={`${label} (${count} desenhos)`}
                className="relative flex h-8 w-8 shrink-0 items-center justify-center rounded text-[#787b86] transition-colors hover:bg-[#222226] hover:text-[#d1d4dc]"
              >
                <Icon className="h-4 w-4" />
                {count > 0 && (
                  <span className="absolute right-0.5 top-0.5 flex h-3 min-w-3 items-center justify-center rounded-full bg-[#3f3f46] px-0.5 text-[8px] font-bold leading-none text-white">
                    {count}
                  </span>
                )}
              </button>
            </Hint>
          );
        }
        if (id === 'remove') {
          return (
            <Hint key={id} label={count > 0 ? `${label} (${count})` : `${label} · nenhum desenho`}>
              <button
                type="button"
                aria-label={label}
                onClick={() => useDrawingStore.getState().clear(`${symbol}|${tf}`)}
                className={`${BTN} ${BTN_IDLE} ${count > 0 ? 'hover:text-[#f2385a]' : 'opacity-40'}`}
              >
                <Icon className="h-4 w-4" />
              </button>
            </Hint>
          );
        }
        return (
          <Hint key={id} label={`${label} · em breve`}>
            <button
              type="button"
              aria-label={label}
              className={`${BTN} ${BTN_IDLE}`}
            >
              <Icon className="h-4 w-4" />
            </button>
          </Hint>
        );
      })}

      {/* desfazer: remove o último desenhado da chave atual */}
      <Hint label="Desfazer desenho">
        <button
          type="button"
          aria-label="Desfazer desenho"
          onClick={() => useDrawingStore.getState().undo(`${symbol}|${tf}`)}
          className={`${BTN} ${count > 0 ? BTN_IDLE : `${BTN_IDLE} opacity-40`}`}
        >
          <Undo2 className="h-4 w-4" />
        </button>
      </Hint>
    </div>
  );
}

