'use client';

import type { ReactNode } from 'react';

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { useTerminalStore } from '@/store/terminal';
import type { DisplayMode, DomGexMode, ProfileMode, TerminalSettings } from '@/store/terminal';

/** Padrões do motor de fluxo (idênticos ao store). */
const DEFAULTS: Partial<TerminalSettings> = {
  displayMode: 'bidask',
  showImbalances: true,
  imbalanceRatio: 3,
  showMaxLevels: true,
  minCellVolume: 0,
  showProfile: true,
  profileMode: 'session',
  showVwap: true,
  showVwapBands: true,
  showDeltaPane: true,
  showHeatBubbles: true,
  showDepthLadder: true,
  showDepthBubbles: true,
  depthBubbleMinPct: 55,
  showGexHeatmap: true,
  showGexFlip: true,
  bigTradeSize: 0,
  useMbo: true,
  useWebgl: true,
  showFlowSignals: true,
  showDomGex: true,
  domGexMode: 'gamma',
  showDomFlowStrip: true,
};

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mt-4 first:mt-1">
      <h3 className="mb-0.5 text-[10px] font-medium uppercase tracking-wider text-[#787b86]">
        {title}
      </h3>
      {children}
    </section>
  );
}

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-[#262a31] py-2 last:border-0">
      <span className="text-[11px] text-[#d1d4dc]">{label}</span>
      {children}
    </div>
  );
}

const SELECT_CLS =
  'h-8 border-[#27272a] bg-[#222226] px-2 text-[11px] dark:bg-[#222226]';
const ITEM_CLS = 'text-[11px] focus:bg-[#222226] focus:text-[#d1d4dc]';
const NUM_CLS =
  'h-8 w-24 border-[#27272a] bg-[#222226] px-2 text-[11px] dark:bg-[#222226]';

function parseNonNegative(raw: string): number {
  return Math.max(0, Math.floor(Number(raw) || 0));
}

/** Modal "Indicadores" estilo ATAS Web (store: dialog === 'indicators'). */
export function IndicatorsDialog() {
  const dialog = useTerminalStore((s) => s.dialog);
  const setDialog = useTerminalStore((s) => s.setDialog);
  const displayMode = useTerminalStore((s) => s.displayMode);
  const showImbalances = useTerminalStore((s) => s.showImbalances);
  const imbalanceRatio = useTerminalStore((s) => s.imbalanceRatio);
  const showMaxLevels = useTerminalStore((s) => s.showMaxLevels);
  const minCellVolume = useTerminalStore((s) => s.minCellVolume);
  const showProfile = useTerminalStore((s) => s.showProfile);
  const profileMode = useTerminalStore((s) => s.profileMode);
  const showVwap = useTerminalStore((s) => s.showVwap);
  const showVwapBands = useTerminalStore((s) => s.showVwapBands);
  const showDeltaPane = useTerminalStore((s) => s.showDeltaPane);
  const showHeatBubbles = useTerminalStore((s) => s.showHeatBubbles);
  const showDepthLadder = useTerminalStore((s) => s.showDepthLadder);
  const showDepthBubbles = useTerminalStore((s) => s.showDepthBubbles);
  const depthBubbleMinPct = useTerminalStore((s) => s.depthBubbleMinPct);
  const showGexHeatmap = useTerminalStore((s) => s.showGexHeatmap);
  const showGexFlip = useTerminalStore((s) => s.showGexFlip);
  const bigTradeSize = useTerminalStore((s) => s.bigTradeSize);
  const useMbo = useTerminalStore((s) => s.useMbo);
  const useWebgl = useTerminalStore((s) => s.useWebgl);
  const showFlowSignals = useTerminalStore((s) => s.showFlowSignals);
  const showDomGex = useTerminalStore((s) => s.showDomGex);
  const domGexMode = useTerminalStore((s) => s.domGexMode);
  const showDomFlowStrip = useTerminalStore((s) => s.showDomFlowStrip);
  const patchSettings = useTerminalStore((s) => s.patchSettings);

  return (
    <Dialog
      open={dialog === 'indicators'}
      onOpenChange={(o) => {
        if (!o) setDialog('none');
      }}
    >
      <DialogContent className="scrollbar-thin max-h-[80vh] max-w-lg gap-0 overflow-y-auto rounded-md border-[#27272a] bg-[#1f1f23] p-4 sm:max-w-lg">
        <DialogHeader className="gap-0.5">
          <DialogTitle className="text-[13px] font-bold text-white">
            Indicadores
          </DialogTitle>
          <DialogDescription className="text-[10px] text-[#787b86]">
            motor de fluxo · configurações do gráfico
          </DialogDescription>
        </DialogHeader>

        {/* Clusters */}
        <Section title="Clusters">
          <Row label="Exibição das células">
            <Select
              value={displayMode}
              onValueChange={(v) => patchSettings({ displayMode: v as DisplayMode })}
            >
              <SelectTrigger size="sm" className={`${SELECT_CLS} w-[120px]`}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="rounded-md border-[#27272a] bg-[#1f1f23]">
                <SelectItem value="bidask" className={ITEM_CLS}>
                  Bid × Ask
                </SelectItem>
                <SelectItem value="delta" className={ITEM_CLS}>
                  Delta
                </SelectItem>
                <SelectItem value="volume" className={ITEM_CLS}>
                  Volume
                </SelectItem>
              </SelectContent>
            </Select>
          </Row>

          <Row label="Desequilíbrios (imbalances)">
            <Switch
              checked={showImbalances}
              onCheckedChange={(c) => patchSettings({ showImbalances: c })}
            />
          </Row>

          {showImbalances && (
            <Row label="Razão mínima">
              <Select
                value={String(imbalanceRatio)}
                onValueChange={(v) => patchSettings({ imbalanceRatio: Number(v) })}
              >
                <SelectTrigger size="sm" className={`${SELECT_CLS} w-[100px]`}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="rounded-md border-[#27272a] bg-[#1f1f23]">
                  <SelectItem value="2" className={ITEM_CLS}>
                    200%
                  </SelectItem>
                  <SelectItem value="3" className={ITEM_CLS}>
                    300%
                  </SelectItem>
                  <SelectItem value="4" className={ITEM_CLS}>
                    400%
                  </SelectItem>
                </SelectContent>
              </Select>
            </Row>
          )}

          <Row label="Destacar máximo da vela (max levels)">
            <Switch
              checked={showMaxLevels}
              onCheckedChange={(c) => patchSettings({ showMaxLevels: c })}
            />
          </Row>

          <Row label="Volume mínimo da célula">
            <Input
              type="number"
              min={0}
              value={minCellVolume}
              onChange={(e) =>
                patchSettings({ minCellVolume: parseNonNegative(e.target.value) })
              }
              className={NUM_CLS}
            />
          </Row>
        </Section>

        {/* Overlays */}
        <Section title="Overlays">
          <Row label="Volume Profile">
            <div className="flex items-center gap-2">
              {showProfile && (
                <Select
                  value={profileMode}
                  onValueChange={(v) => patchSettings({ profileMode: v as ProfileMode })}
                >
                  <SelectTrigger size="sm" className={`${SELECT_CLS} w-[110px]`}>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="rounded-md border-[#27272a] bg-[#1f1f23]">
                    <SelectItem value="session" className={ITEM_CLS}>
                      Sessão
                    </SelectItem>
                    <SelectItem value="visible" className={ITEM_CLS}>
                      Visível
                    </SelectItem>
                  </SelectContent>
                </Select>
              )}
              <Switch
                checked={showProfile}
                onCheckedChange={(c) => patchSettings({ showProfile: c })}
              />
            </div>
          </Row>

          <Row label="VWAP da sessão">
            <Switch
              checked={showVwap}
              onCheckedChange={(c) => patchSettings({ showVwap: c })}
            />
          </Row>

          {showVwap && (
            <Row label="Bandas VWAP (±1σ / ±2σ)">
              <Switch
                checked={showVwapBands}
                onCheckedChange={(c) => patchSettings({ showVwapBands: c })}
              />
            </Row>
          )}

          <Row label="Painel de Delta + CVD">
            <Switch
              checked={showDeltaPane}
              onCheckedChange={(c) => patchSettings({ showDeltaPane: c })}
            />
          </Row>
        </Section>

        {/* Heatmap */}
        <Section title="Heatmap">
          <Row label="Bolhas de trades (raio ∝ volume)">
            <Switch
              checked={showHeatBubbles}
              onCheckedChange={(c) => patchSettings({ showHeatBubbles: c })}
            />
          </Row>

          <Row label="Ladder de profundidade (bid/ask atual)">
            <Switch
              checked={showDepthLadder}
              onCheckedChange={(c) => patchSettings({ showDepthLadder: c })}
            />
          </Row>
        </Section>

        {/* Bolhas de profundidade (rodada 6) */}
        <Section title="Bolhas de profundidade (heatmap)">
          <p className="mb-0.5 text-[10px] leading-relaxed text-[#787b86]">
            Círculos sobre o heatmap com raio ∝ profundidade restante do book por
            bucket (paredes de liquidez).
          </p>
          <Row label="Exibir bolhas de profundidade">
            <Switch
              checked={showDepthBubbles}
              onCheckedChange={(c) => patchSettings({ showDepthBubbles: c })}
            />
          </Row>

          <Row label="Profundidade mínima da bolha">
            <div className="flex items-center gap-2">
              <Slider
                value={[depthBubbleMinPct]}
                min={30}
                max={90}
                step={5}
                disabled={!showDepthBubbles}
                onValueChange={([v]) => patchSettings({ depthBubbleMinPct: v })}
                className="w-[110px]"
                aria-label="Profundidade mínima da bolha (% do máximo do book)"
              />
              <span
                className={`w-9 text-right font-num text-[11px] tabular-nums ${
                  showDepthBubbles ? 'text-[#d1d4dc]' : 'text-[#5d606b]'
                }`}
              >
                {depthBubbleMinPct}%
              </span>
            </div>
          </Row>
        </Section>

        {/* GEX */}
        <Section title="GEX (gamma exposure)">
          <Row label="Heatmap de gamma por strike">
            <Switch
              checked={showGexHeatmap}
              onCheckedChange={(c) => patchSettings({ showGexHeatmap: c })}
            />
          </Row>

          <Row label="Linha do gamma flip">
            <Switch
              checked={showGexFlip}
              onCheckedChange={(c) => patchSettings({ showGexFlip: c })}
            />
          </Row>
        </Section>

        {/* Motor MBO (rodada 5) */}
        <Section title="Motor MBO (TapeDelta)">
          <Row label="Stream binário FlatBuffers + WebWorker">
            <Switch checked={useMbo} onCheckedChange={(c) => patchSettings({ useMbo: c })} />
          </Row>

          {useMbo && (
            <Row label="Renderização WebGL do heatmap">
              <Switch checked={useWebgl} onCheckedChange={(c) => patchSettings({ useWebgl: c })} />
            </Row>
          )}

          {useMbo && (
            <Row label="Sinais de fluxo (absorção/exaustão/iceberg/spoofing)">
              <Switch
                checked={showFlowSignals}
                onCheckedChange={(c) => patchSettings({ showFlowSignals: c })}
              />
            </Row>
          )}
        </Section>

        {/* DOM · Derivativos (rodada 5) */}
        <Section title="DOM · Derivativos (GEX)">
          <Row label="Rail de gamma/vanna/charm na escada">
            <Switch checked={showDomGex} onCheckedChange={(c) => patchSettings({ showDomGex: c })} />
          </Row>

          {showDomGex && (
            <Row label="Métrica do rail">
              <Select
                value={domGexMode}
                onValueChange={(v) => patchSettings({ domGexMode: v as DomGexMode })}
              >
                <SelectTrigger size="sm" className={`${SELECT_CLS} w-[110px]`}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="rounded-md border-[#27272a] bg-[#1f1f23]">
                  <SelectItem value="gamma" className={ITEM_CLS}>
                    Gamma
                  </SelectItem>
                  <SelectItem value="vanna" className={ITEM_CLS}>
                    Vanna
                  </SelectItem>
                  <SelectItem value="charm" className={ITEM_CLS}>
                    Charm
                  </SelectItem>
                </SelectContent>
              </Select>
            </Row>
          )}

          {showDomGex && (
            <Row label="Strip de fluxo vivo (absorção)">
              <Switch
                checked={showDomFlowStrip}
                onCheckedChange={(c) => patchSettings({ showDomFlowStrip: c })}
              />
            </Row>
          )}
        </Section>

        {/* Tape */}
        <Section title="Tape">
          <Row label="Trade grande ≥">
            <Input
              type="number"
              min={0}
              value={bigTradeSize}
              onChange={(e) =>
                patchSettings({ bigTradeSize: parseNonNegative(e.target.value) })
              }
              className={NUM_CLS}
            />
          </Row>
        </Section>

        {/* rodapé */}
        <div className="mt-4 flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={() => patchSettings(DEFAULTS)}
            className="h-8 rounded bg-[#222226] px-3 text-[11px] text-[#d1d4dc] transition-colors hover:bg-[#27272a]"
          >
            Restaurar padrão
          </button>
          <button
            type="button"
            onClick={() => setDialog('none')}
            className="h-8 rounded bg-[#3f3f46] px-3 text-[11px] font-medium text-white transition-colors hover:bg-[#52525b]"
          >
            Fechar
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
