'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { Activity, GripVertical } from 'lucide-react';

import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { fmtCompact, fmtHm, fmtPrice, fmtSignedCompact } from '@/lib/market/format';
import { symbolMeta } from '@/lib/market/types';
import type { Candle, DomSnapshot, SessionStats } from '@/lib/market/types';
import {
  atr14,
  buildChain,
  flipSpot,
  gexPerStrike,
  maxPain,
  netGex,
  realizedVolPct,
} from '@/lib/quant/quant';
import type { GexRow, QuantChain } from '@/lib/quant/quant';
import {
  FLOW_GEX_REGIME_META,
  OfiTracker,
  cvdSeries,
  flowGexRegime,
  flowPressure,
} from '@/lib/quant/micro';
import type { CvdRow, FlowGexRegime } from '@/lib/quant/micro';
import { cn } from '@/lib/utils';
import { useTerminalStore } from '@/store/terminal';

type QuantView = 'flow' | 'gex' | 'skew' | 'stats';

const VIEW_ITEMS: Array<{ value: QuantView; label: string }> = [
  { value: 'flow', label: 'Flow' },
  { value: 'gex', label: 'GEX' },
  { value: 'skew', label: 'Skew' },
  { value: 'stats', label: 'Stats' },
];

const VIEW_CLS =
  'h-6 rounded px-1.5 text-[10px] text-[#787b86] hover:bg-[#222226] hover:text-[#d1d4dc] data-[state=on]:bg-[#27272a] data-[state=on]:text-white data-[state=on]:shadow-[inset_0_-2px_0_0_#4682b4]';

const TEAL = '#089981';
const RED = '#f2385a';

interface QuantStats {
  rows: GexRow[];
  net: number;
  flip: number | null;
  pain: number;
  atr: number;
  rv: number;
  pcRatio: number;
}

function Empty({ children }: { children: string }) {
  return (
    <div className="flex h-full min-h-24 items-center justify-center text-[10px] text-[#5d606b]">
      {children}
    </div>
  );
}

// ── Vista GEX: chips de resumo + barras horizontais por strike ───────────────

function GexView({
  chain,
  rows,
  net,
  flip,
  tick,
  ofi,
}: {
  chain: QuantChain;
  rows: GexRow[];
  net: number;
  flip: number | null;
  tick: number;
  /** OFI da janela — marca o strike mais próximo com a direção do fluxo */
  ofi: number;
}) {
  if (rows.length === 0) return <Empty>Aguardando dados de mercado…</Empty>;

  // escala comum e strike mais próximo do spot
  let maxAbs = 0;
  let nearestIdx = 0;
  let bestD = Infinity;
  rows.forEach((r, i) => {
    maxAbs = Math.max(maxAbs, Math.abs(r.callGex), Math.abs(r.putGex));
    const d = Math.abs(r.strike - chain.spot);
    if (d < bestD) {
      bestD = d;
      nearestIdx = i;
    }
  });

  // maior strike no topo
  const ordered = rows.map((r, i) => ({ r, i })).reverse();

  return (
    <div className="flex flex-col gap-0.5">
      {/* chips de resumo */}
      <div className="flex items-center gap-2 pb-1.5">
        <div className="flex h-6 items-center gap-1.5 rounded border border-[#27272a] bg-[#101012] px-2">
          <span className="whitespace-nowrap text-[9px] uppercase tracking-wide text-[#787b86]">
            GEX líquido
          </span>
          <span
            className={cn(
              'font-num text-[11px] font-bold tabular-nums',
              net >= 0 ? 'text-[#089981]' : 'text-[#f2385a]',
            )}
          >
            {fmtCompact(net)}
          </span>
          <span className="whitespace-nowrap text-[9px] text-[#5d606b]">· ciclo</span>
        </div>
        <div className="flex h-6 items-center gap-1.5 rounded border border-[#27272a] bg-[#101012] px-2">
          <span className="whitespace-nowrap text-[9px] uppercase tracking-wide text-[#787b86]">
            Flip
          </span>
          <span className="font-num text-[11px] font-bold tabular-nums text-[#e8a854]">
            {flip !== null ? fmtPrice(flip, tick) : '—'}
          </span>
        </div>
      </div>

      {/* barras: call teal → direita · put red → esquerda, a partir do divisor central */}
      {ordered.map(({ r, i }) => {
        const near = i === nearestIdx;
        const wCall = maxAbs > 0 ? (Math.abs(r.callGex) / maxAbs) * 50 : 0;
        const wPut = maxAbs > 0 ? (Math.abs(r.putGex) / maxAbs) * 50 : 0;
        // correlação OFI×GEX: direção do fluxo marcada no strike ATM
        const ofiUp = ofi > 1e-6;
        const ofiDown = ofi < -1e-6;
        return (
          <div
            key={r.strike}
            className={cn(
              'flex h-4 items-center gap-1.5 rounded-sm px-1',
              near && 'bg-[#222226]',
            )}
          >
            <span
              className={cn(
                'w-14 shrink-0 text-right font-num text-[10px] tabular-nums',
                near ? 'font-bold text-white' : 'text-[#787b86]',
              )}
            >
              {fmtPrice(r.strike, tick)}
              {near && (ofiUp || ofiDown) && (
                <span
                  className={cn('ml-1', ofiUp ? 'text-[#089981]' : 'text-[#f2385a]')}
                  title={`OFI ${fmtSignedCompact(ofi)} no strike ATM`}
                >
                  {ofiUp ? '▲' : '▼'}
                </span>
              )}
            </span>
            <div className="relative h-3 min-w-0 flex-1">
              <div className="absolute inset-y-0 left-1/2 w-px -translate-x-1/2 bg-[#27272a]" />
              <div
                className="absolute inset-y-0 right-1/2 rounded-sm bg-[#f2385a]"
                style={{ width: `${wPut}%` }}
              />
              <div
                className="absolute inset-y-0 left-1/2 rounded-sm bg-[#089981]"
                style={{ width: `${wCall}%` }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ── Vista Flow: OFI + CVD tabular + exaustão, correlacionados ao GEX ─────────

function Chip({
  label,
  value,
  cls = 'text-white',
  title,
}: {
  label: string;
  value: string;
  cls?: string;
  title?: string;
}) {
  return (
    <div
      className="flex h-6 items-center gap-1.5 rounded border border-[#27272a] bg-[#101012] px-2"
      title={title}
    >
      <span className="whitespace-nowrap text-[9px] uppercase tracking-wide text-[#787b86]">
        {label}
      </span>
      <span className={cn('font-num text-[11px] font-bold tabular-nums', cls)}>{value}</span>
    </div>
  );
}

/** Sparkline SVG compacta (histórico do OFI, baseline zero). */
function OfiSpark({ hist }: { hist: number[] }) {
  const W = 240;
  const H = 34;
  const n = hist.length;
  if (n < 2) {
    return (
      <div className="flex h-[34px] items-center justify-center text-[9px] text-[#5d606b]">
        coletando snapshots do book…
      </div>
    );
  }
  let maxAbs = 1e-9;
  for (const v of hist) maxAbs = Math.max(maxAbs, Math.abs(v));
  const xFor = (i: number) => (i / (n - 1)) * W;
  const yFor = (v: number) => H / 2 - (v / maxAbs) * (H / 2 - 2);
  const pts = hist.map((v, i) => `${xFor(i).toFixed(1)},${yFor(v).toFixed(1)}`).join(' ');
  const last = hist[n - 1] ?? 0;
  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      className="h-[34px] w-full"
      role="img"
      aria-label="Histórico do Order Flow Imbalance (janela de 8s)"
    >
      <line x1={0} x2={W} y1={H / 2} y2={H / 2} stroke="#27272a" strokeWidth={1} />
      <polyline
        points={pts}
        fill="none"
        stroke={last >= 0 ? '#089981' : '#f2385a'}
        strokeWidth={1.4}
      />
    </svg>
  );
}

function FlowView({
  ofiState,
  cvd,
  regime,
  pressure,
  flipDistTicks,
  netGexVal,
}: {
  ofiState: { ofi: number; windowMs: number; hist: number[] };
  cvd: { rows: CvdRow[]; total: number };
  regime: FlowGexRegime;
  pressure: ReturnType<typeof flowPressure>;
  /** distância do flip ao spot, em ticks (negativo = flip acima) */
  flipDistTicks: number | null;
  netGexVal: number;
}) {
  const meta = FLOW_GEX_REGIME_META[regime];
  const ofiCls = ofiState.ofi > 1e-6 ? 'text-[#089981]' : ofiState.ofi < -1e-6 ? 'text-[#f2385a]' : 'text-[#d1d4dc]';
  const cvdCls = cvd.total > 0 ? 'text-[#089981]' : cvd.total < 0 ? 'text-[#f2385a]' : 'text-[#d1d4dc]';

  return (
    <div className="flex flex-col gap-2">
      {/* chips: microestrutura + regime OFI×GEX */}
      <div className="flex flex-wrap items-center gap-2">
        <Chip
          label="OFI"
          value={fmtSignedCompact(ofiState.ofi)}
          cls={ofiCls}
          title={`Order Flow Imbalance (Δ profundidade bid−ask, janela ${Math.round(ofiState.windowMs / 1000)}s)`}
        />
        <Chip
          label="CVD"
          value={fmtSignedCompact(cvd.total)}
          cls={cvdCls}
          title="Cumulative Volume Delta da sessão (velas do timeframe)"
        />
        <Chip
          label="Exaustão"
          value={`${pressure.exhaustion}${pressure.dominantSide ? ` ${pressure.dominantSide === 'buy' ? '▲' : '▼'}` : ''}`}
          cls={pressure.exhaustion > 0 ? (pressure.dominantSide === 'buy' ? 'text-[#089981]' : 'text-[#f2385a]') : 'text-[#787b86]'}
          title={`Sinais de exaustão vivos · pressão líquida ${fmtSignedCompact(Number(pressure.netPressure.toFixed(2)))}`}
        />
        <Chip
          label="Absorção"
          value={String(pressure.absorption)}
          cls={pressure.absorption > 0 ? 'text-[#e8a854]' : 'text-[#787b86]'}
          title="Sinais de absorção vivos (agressão travada por limite)"
        />
        <Chip
          label="GEX"
          value={fmtCompact(netGexVal)}
          cls={netGexVal >= 0 ? 'text-[#089981]' : 'text-[#f2385a]'}
          title="GEX líquido (dealer convention) — contexto do regime"
        />
        <div
          className={cn(
            'flex h-6 items-center gap-1.5 rounded border border-[#27272a] bg-[#101012] px-2',
            meta.cls,
          )}
          title={meta.hint}
        >
          <Activity className="h-3 w-3" aria-hidden="true" />
          <span className="text-[9px] font-bold tracking-wider">{meta.label}</span>
          {flipDistTicks !== null && (
            <span className="whitespace-nowrap text-[9px] text-[#5d606b]">
              flip {flipDistTicks >= 0 ? '−' : '+'}
              {Math.abs(flipDistTicks)}t
            </span>
          )}
        </div>
      </div>

      {/* sparkline do OFI */}
      <div className="rounded border border-[#27272a] bg-[#101012] p-1.5">
        <div className="flex items-center justify-between px-0.5 pb-0.5">
          <span className="text-[9px] uppercase tracking-wide text-[#787b86]">
            OFI · janela {Math.round(ofiState.windowMs / 1000)}s
          </span>
          <span className="text-[9px] text-[#5d606b]">Δ profundidade bid−ask</span>
        </div>
        <OfiSpark hist={ofiState.hist} />
      </div>

      {/* CVD tabular */}
      <div className="rounded border border-[#27272a] bg-[#101012]">
        <div className="flex items-center justify-between border-b border-[#27272a] px-2 py-1">
          <span className="text-[9px] uppercase tracking-wide text-[#787b86]">
            CVD tabular
          </span>
          <span className="text-[9px] text-[#5d606b]">últimas {cvd.rows.length} velas</span>
        </div>
        <div className="grid grid-cols-[52px_1fr_1fr_1fr] gap-x-2 px-2 py-1 text-[9px] uppercase tracking-wide text-[#5d606b]">
          <span>hora</span>
          <span className="text-right">vol</span>
          <span className="text-right">Δ</span>
          <span className="text-right">cvd</span>
        </div>
        <div className="scrollbar-thin max-h-56 overflow-y-auto">
          {[...cvd.rows].reverse().map((r) => (
            <div
              key={r.t}
              className="grid grid-cols-[52px_1fr_1fr_1fr] gap-x-2 px-2 py-[3px] font-num text-[10px] tabular-nums"
            >
              <span className="text-[#787b86]">{fmtHm(r.t)}</span>
              <span className="text-right text-[#d1d4dc]">{fmtCompact(r.volume)}</span>
              <span
                className={cn(
                  'text-right',
                  r.delta > 0 ? 'text-[#089981]' : r.delta < 0 ? 'text-[#f2385a]' : 'text-[#787b86]',
                )}
              >
                {fmtSignedCompact(r.delta)}
              </span>
              <span
                className={cn(
                  'text-right font-semibold',
                  r.cvd > 0 ? 'text-[#089981]' : r.cvd < 0 ? 'text-[#f2385a]' : 'text-[#787b86]',
                )}
              >
                {fmtSignedCompact(r.cvd)}
              </span>
            </div>
          ))}
          {cvd.rows.length === 0 && (
            <div className="flex h-16 items-center justify-center text-[10px] text-[#5d606b]">
              Aguardando velas…
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ── Vista Skew: curvas de IV × strike (SVG inline) ───────────────────────────

function SkewView({ chain, tick }: { chain: QuantChain; tick: number }) {
  if (chain.strikes.length < 2) return <Empty>Aguardando dados de mercado…</Empty>;

  const W = 260;
  const H = 110;
  const padL = 36;
  const padR = 8;
  const padT = 10;
  const padB = 16;

  const n = chain.strikes.length;
  let lo = Infinity;
  let hi = -Infinity;
  for (let i = 0; i < n; i++) {
    const c = chain.callIV[i] ?? 0;
    const p = chain.putIV[i] ?? 0;
    lo = Math.min(lo, c, p);
    hi = Math.max(hi, c, p);
  }
  const span = Math.max(hi - lo, 0.01);
  const min = lo - span * 0.12;
  const max = hi + span * 0.12;

  const xFor = (i: number) => padL + (i / (n - 1)) * (W - padL - padR);
  const yFor = (iv: number) => padT + (1 - (iv - min) / (max - min)) * (H - padT - padB);

  const xs: number[] = [];
  const callYs: number[] = [];
  const putYs: number[] = [];
  for (let i = 0; i < n; i++) {
    xs.push(xFor(i));
    callYs.push(yFor(chain.callIV[i] ?? 0));
    putYs.push(yFor(chain.putIV[i] ?? 0));
  }
  const toPts = (ys: number[]) =>
    ys.map((y, i) => `${(xs[i] ?? 0).toFixed(1)},${y.toFixed(1)}`).join(' ');

  const midIdx = Math.floor((n - 1) / 2);
  const s0 = chain.strikes[0] ?? 0;
  const sMid = chain.strikes[midIdx] ?? 0;
  const sLast = chain.strikes[n - 1] ?? 0;
  const mid = (lo + hi) / 2;
  const ivLabels = [
    { v: lo, y: yFor(lo) },
    { v: mid, y: yFor(mid) },
    { v: hi, y: yFor(hi) },
  ];

  return (
    <div>
      <div className="flex items-center justify-between px-1 pb-1">
        <span className="text-[9px] uppercase tracking-wide text-[#787b86]">
          Vol. implícita × strike
        </span>
        <span className="flex items-center gap-2 text-[9px] text-[#787b86]">
          <span className="flex items-center gap-1">
            <span className="h-1.5 w-1.5 rounded-full bg-[#089981]" aria-hidden="true" />
            calls
          </span>
          <span className="flex items-center gap-1">
            <span className="h-1.5 w-1.5 rounded-full bg-[#f2385a]" aria-hidden="true" />
            puts
          </span>
        </span>
      </div>
      <svg
        viewBox={`0 0 ${W} ${H}`}
        className="w-full"
        role="img"
        aria-label="Curvas de volatilidade implícita por strike (calls e puts)"
      >
        {/* linhas de grade */}
        {ivLabels.map((l, i) => (
          <line
            key={i}
            x1={padL}
            x2={W - padR}
            y1={l.y}
            y2={l.y}
            stroke="rgba(255,255,255,0.08)"
            strokeWidth={0.5}
          />
        ))}
        {/* curvas */}
        <polyline points={toPts(callYs)} fill="none" stroke={TEAL} strokeWidth={1.5} />
        <polyline points={toPts(putYs)} fill="none" stroke={RED} strokeWidth={1.5} />
        {xs.map((x, i) => (
          <circle key={`c${i}`} cx={x} cy={callYs[i] ?? 0} r={2} fill={TEAL} />
        ))}
        {xs.map((x, i) => (
          <circle key={`p${i}`} cx={x} cy={putYs[i] ?? 0} r={2} fill={RED} />
        ))}
        {/* eixo X: primeiro / meio / último strike */}
        <text x={padL} y={H - 4} fontSize={9} fill="#787b86" textAnchor="middle">
          {fmtPrice(s0, tick)}
        </text>
        <text x={xFor(midIdx)} y={H - 4} fontSize={9} fill="#787b86" textAnchor="middle">
          {fmtPrice(sMid, tick)}
        </text>
        <text x={W - padR} y={H - 4} fontSize={9} fill="#787b86" textAnchor="end">
          {fmtPrice(sLast, tick)}
        </text>
        {/* eixo Y: IV% mín / meio / máx */}
        {ivLabels.map((l, i) => (
          <text
            key={`iv${i}`}
            x={padL - 5}
            y={l.y + 3}
            fontSize={9}
            fill="#787b86"
            textAnchor="end"
          >
            {Math.round(l.v * 100)}%
          </text>
        ))}
      </svg>
    </div>
  );
}

// ── Vista Stats: grid de stat cards ──────────────────────────────────────────

function StatsView({
  quant,
  session,
  tick,
}: {
  quant: QuantStats;
  session: SessionStats | null;
  tick: number;
}) {
  const cards: Array<{ label: string; value: string; amber?: boolean }> = [
    { label: 'ATR (14)', value: quant.atr > 0 ? fmtPrice(quant.atr, tick) : '—' },
    { label: 'Vol. realizada', value: quant.rv > 0 ? `${quant.rv.toFixed(1)}%` : '—' },
    { label: 'Max pain', value: quant.pain > 0 ? fmtPrice(quant.pain, tick) : '—' },
    { label: 'Put/Call OI', value: quant.pcRatio > 0 ? quant.pcRatio.toFixed(2) : '—' },
    { label: 'Volume sessão', value: session ? fmtCompact(session.volume) : '—' },
    { label: 'Negócios', value: session ? fmtCompact(session.trades) : '—' },
    { label: 'POC', value: session ? fmtPrice(session.poc, tick) : '—', amber: true },
    { label: 'VWAP', value: session ? fmtPrice(session.vwap, tick) : '—', amber: true },
  ];

  return (
    <div className="grid grid-cols-2 gap-2">
      {cards.map((c) => (
        <div key={c.label} className="rounded border border-[#27272a] bg-[#101012] p-2">
          <div className="text-[9px] uppercase tracking-wide text-[#787b86]">{c.label}</div>
          <div
            className={cn(
              'mt-0.5 font-num text-[12px] font-bold tabular-nums',
              c.amber ? 'text-[#e8a854]' : 'text-white',
            )}
          >
            {c.value}
          </div>
        </div>
      ))}
    </div>
  );
}

// ── Widget principal ─────────────────────────────────────────────────────────

interface QuantPanelProps {
  className?: string;
}

/** Widget Quant Dashboard estilo ATAS (Flow / GEX / Skew / Stats). */
export default function QuantPanel({ className }: QuantPanelProps) {
  const symbol = useTerminalStore((s) => s.symbol);
  const session = useTerminalStore((s) => s.session);
  const candles = useTerminalStore((s) => s.candles);
  const dom = useTerminalStore((s) => s.dom);
  const flowSignals = useTerminalStore((s) => s.flowSignals);

  const [view, setView] = useState<QuantView>('gex');

  const { tick } = symbolMeta(symbol);

  // spot quantizado (tick*10) p/ reduzir recomputes da cadeia
  const last = session?.last ?? 0;
  const spotKey =
    Number.isFinite(last) && last > 0 ? Math.round(last / (tick * 10)) : 0;

  const chain = useMemo<QuantChain>(
    () => buildChain(symbol, spotKey * tick * 10, symbol),
    [symbol, spotKey, tick],
  );

  // fatia de velas p/ ATR/vol. realizada (slice trivial; react-hooks/refs v6
  // proíbe "latest ref" em render, então dependemos do array diretamente)
  const recentCandles = useMemo<Candle[]>(() => candles.slice(-80), [candles]);

  const quant = useMemo<QuantStats>(() => {
    const rows = gexPerStrike(chain, tick);
    let callSum = 0;
    let putSum = 0;
    for (let i = 0; i < chain.callOI.length; i++) {
      callSum += chain.callOI[i] ?? 0;
      putSum += chain.putOI[i] ?? 0;
    }
    return {
      rows,
      net: netGex(rows),
      flip: flipSpot(chain, tick),
      pain: maxPain(chain, tick),
      atr: atr14(recentCandles),
      rv: realizedVolPct(recentCandles),
      pcRatio: callSum > 0 ? putSum / callSum : 0,
    };
  }, [chain, tick, recentCandles]);

  // ── microestrutura (OFI incremental sobre snapshots de DOM) ──
  // tracker vive em ref (inicialização lazy permitida por react-hooks);
  // push no useEffect — nunca em render (regra de pureza).
  const ofiRef = useRef<OfiTracker | null>(null);
  if (!ofiRef.current) ofiRef.current = new OfiTracker();
  const [ofiState, setOfiState] = useState<{ ofi: number; windowMs: number; hist: number[] }>({
    ofi: 0,
    windowMs: 8000,
    hist: [],
  });
  useEffect(() => {
    if (!dom) return;
    setOfiState(ofiRef.current!.push(dom, Date.now()));
  }, [dom]);
  // troca de símbolo: reinicia o tracker (book de outro instrumento)
  useEffect(() => {
    ofiRef.current?.reset();
    setOfiState({ ofi: 0, windowMs: 8000, hist: [] });
  }, [symbol]);

  // CVD tabular + pressão de fluxo + regime OFI×GEX (memoizados)
  const cvd = useMemo(() => cvdSeries(candles, 18), [candles]);
  const pressure = useMemo(() => flowPressure(flowSignals, Date.now()), [flowSignals]);
  const regime = useMemo(
    () => flowGexRegime(ofiState.ofi, quant.net),
    [ofiState.ofi, quant.net],
  );
  const flipDistTicks = useMemo(() => {
    if (quant.flip === null || !(last > 0)) return null;
    return Math.round((quant.flip - last) / tick);
  }, [quant.flip, last, tick]);

  return (
    <div
      className={cn(
        // tabular-nums na raiz: GEX/flip/stats com dígitos alinhados
        // verticalmente (font-variant-numeric: tabular-nums)
        'flex h-full w-full flex-col overflow-hidden bg-[#18181b] tabular-nums',
        className,
      )}
    >
      {/* chrome do widget */}
      <div className="flex h-9 shrink-0 items-center gap-2 border-b border-[#27272a] bg-[#151515] px-2">
        <GripVertical className="h-3.5 w-3.5 shrink-0 text-[#5d606b]" aria-hidden="true" />
        <span className="whitespace-nowrap text-[12px] font-bold text-white">Quant</span>
        <span className="hidden whitespace-nowrap text-[10px] text-[#787b86] lg:inline">
          dashboard
        </span>
        <div className="min-w-0 flex-1" />
        <ToggleGroup
          type="single"
          size="sm"
          value={view}
          onValueChange={(v) => {
            if (v) setView(v as QuantView);
          }}
          className="shrink-0 gap-0.5"
          aria-label="Vistas do painel Quant"
        >
          {VIEW_ITEMS.map((item) => (
            <ToggleGroupItem
              key={item.value}
              value={item.value}
              aria-label={`Vista ${item.label}`}
              className={VIEW_CLS}
            >
              {item.label}
            </ToggleGroupItem>
          ))}
        </ToggleGroup>
      </div>

      {/* corpo por vista */}
      <div className="scrollbar-thin min-h-0 flex-1 overflow-y-auto p-2">
        {view === 'flow' && (
          <FlowView
            ofiState={ofiState}
            cvd={cvd}
            regime={regime}
            pressure={pressure}
            flipDistTicks={flipDistTicks}
            netGexVal={quant.net}
          />
        )}
        {view === 'gex' && (
          <GexView
            chain={chain}
            rows={quant.rows}
            net={quant.net}
            flip={quant.flip}
            tick={tick}
            ofi={ofiState.ofi}
          />
        )}
        {view === 'skew' && <SkewView chain={chain} tick={tick} />}
        {view === 'stats' && <StatsView quant={quant} session={session} tick={tick} />}
      </div>

      {/* rodapé */}
      <div className="flex h-6 shrink-0 items-center border-t border-[#27272a] bg-[#101012] px-2 text-[9px] text-[#5d606b]">
        cadeia sintética · GEX dealer convention · OFI Δ profundidade · dados simulados
      </div>
    </div>
  );
}
