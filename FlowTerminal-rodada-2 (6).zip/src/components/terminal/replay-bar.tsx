'use client';

// ─────────────────────────────────────────────────────────────────────────────
// Barra de controle do REPLAY de mercado (estilo ATAS): play/pause, avanço/
// retrocesso de barra, velocidade (barras/s) e scrub sobre o histórico.
// Rodada 6: quando um replay de JOURNAL está ativo, a barra muda p/ os
// controles do journal (playhead temporal, velocidade 0.5–16×, seek ±5s).
// ─────────────────────────────────────────────────────────────────────────────

import { useEffect, useRef } from 'react';
import {
  ChevronFirst,
  ChevronLast,
  Pause,
  Play,
  SkipBack,
  SkipForward,
  X,
} from 'lucide-react';

import { JOURNAL_SPEEDS, REPLAY_SPEEDS, useTerminalStore } from '@/store/terminal';
import { journalPlay, journalSeek, journalSpeed, journalStop } from '@/lib/market/journal';
import { fmtHm } from '@/lib/market/format';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

const BTN =
  'flex h-6 w-6 items-center justify-center rounded text-[#b2b5be] transition-colors hover:bg-[#222226] hover:text-white';

/**
 * Controles do replay de JOURNAL: playhead temporal (ms do mercado),
 * velocidade em múltiplos do tempo real e seek reconstruído pelo serviço.
 */
function JournalBar() {
  const journal = useTerminalStore((s) => s.journal);
  const speedIdx = Math.max(
    0,
    JOURNAL_SPEEDS.indexOf(journal.speed as (typeof JOURNAL_SPEEDS)[number]),
  );

  if (journal.loading) {
    return (
      <div
        role="status"
        aria-label="Carregando replay"
        className="absolute bottom-2 left-1/2 z-20 flex w-[min(420px,calc(100%-16px))] -translate-x-1/2 items-center justify-center gap-2 rounded border border-[#6b532e] bg-[#151515] px-3 py-2 text-[11px] text-[#e8a854] shadow-xl"
      >
        <span className="h-2 w-2 animate-pulse rounded-full bg-[#e8a854]" />
        carregando replay do journal…
      </div>
    );
  }

  const span = Math.max(1, journal.endT - journal.startT);
  const ts = Math.min(journal.endT, Math.max(journal.startT, journal.ts));
  const pct = ((ts - journal.startT) / span) * 100;
  const step5s = (d: number) =>
    journalSeek(Math.min(journal.endT, Math.max(journal.startT, ts + d)));

  return (
    <div
      role="group"
      aria-label="Controles do replay do journal"
      className="absolute bottom-2 left-1/2 z-20 flex w-[min(620px,calc(100%-16px))] -translate-x-1/2 items-center gap-1.5 rounded border border-[#6b532e] bg-[#151515] px-2 py-1.5 shadow-xl"
    >
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            type="button"
            aria-label="Sair do replay"
            onClick={() => journalStop()}
            className={BTN}
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </TooltipTrigger>
        <TooltipContent side="top" className="text-[10px]">
          Sair do replay (voltar ao vivo)
        </TooltipContent>
      </Tooltip>

      <span className="h-4 w-px bg-[#27272a]" />

      <Tooltip>
        <TooltipTrigger asChild>
          <button type="button" aria-label="Voltar 5 segundos" onClick={() => step5s(-5000)} className={BTN}>
            <SkipBack className="h-3.5 w-3.5" />
          </button>
        </TooltipTrigger>
        <TooltipContent side="top" className="text-[10px]">−5s</TooltipContent>
      </Tooltip>

      <button
        type="button"
        aria-label={journal.playing ? 'Pausar replay' : 'Reproduzir replay'}
        onClick={() => journalPlay(!journal.playing)}
        className="flex h-7 w-7 shrink-0 items-center justify-center rounded bg-[#e8a854] text-[#1a1c20] transition-colors hover:bg-[#f0b96b] disabled:opacity-50"
        disabled={journal.ended && !journal.playing}
      >
        {journal.playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
      </button>

      <Tooltip>
        <TooltipTrigger asChild>
          <button type="button" aria-label="Avançar 5 segundos" onClick={() => step5s(5000)} className={BTN}>
            <SkipForward className="h-3.5 w-3.5" />
          </button>
        </TooltipTrigger>
        <TooltipContent side="top" className="text-[10px]">+5s</TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <button
            type="button"
            aria-label="Velocidade do replay"
            title="Velocidade (múltiplo do tempo real)"
            onClick={() => {
              const next = JOURNAL_SPEEDS[(speedIdx + 1) % JOURNAL_SPEEDS.length] ?? 1;
              journalSpeed(next);
            }}
            className="h-6 shrink-0 rounded bg-[#222226] px-1.5 font-num text-[10px] font-bold text-[#e8a854] transition-colors hover:bg-[#27272a]"
          >
            {journal.speed}×
          </button>
        </TooltipTrigger>
        <TooltipContent side="top" className="text-[10px]">
          velocidade do replay
        </TooltipContent>
      </Tooltip>

      {/* scrub temporal */}
      <input
        type="range"
        min={journal.startT}
        max={journal.endT}
        step={Math.max(100, Math.floor(span / 600))}
        value={ts}
        onChange={(e) => {
          journalSeek(Number(e.target.value));
        }}
        aria-label="Posição do replay (tempo)"
        className="h-1.5 min-w-0 flex-1 cursor-pointer appearance-none rounded-full outline-none [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-[#e8a854] [&::-webkit-slider-thumb]:shadow"
        style={{
          background: `linear-gradient(to right, #e8a854 ${pct}%, rgba(255,255,255,0.08) ${pct}%)`,
        }}
      />

      <span className="shrink-0 whitespace-nowrap font-num text-[10px] tabular-nums text-[#e8a854]">
        {fmtHm(ts)}
        {journal.ended ? ' · fim' : ''}
      </span>
    </div>
  );
}

export function ReplayBar() {
  const journalActive = useTerminalStore((s) => s.journal.active || s.journal.loading);
  return journalActive ? <JournalBar /> : <HistoryReplayBar />;
}

function HistoryReplayBar() {
  const replay = useTerminalStore((s) => s.replay);
  const liveLen = useTerminalStore((s) => s.candles.length);
  const patchReplay = useTerminalStore((s) => s.patchReplay);
  const exitReplay = useTerminalStore((s) => s.exitReplay);

  // loop de reprodução: avança 1 barra por tick (speed = barras/segundo)
  useEffect(() => {
    if (!replay.active || !replay.playing) return;
    const period = Math.max(40, Math.round(1000 / replay.speed));
    const id = window.setInterval(() => {
      const st = useTerminalStore.getState();
      const max = Math.max(0, st.candles.length - 1);
      if (st.replay.idx >= max) {
        st.patchReplay({ playing: false, idx: max });
        return;
      }
      st.patchReplay({ idx: st.replay.idx + 1 });
    }, period);
    return () => window.clearInterval(id);
  }, [replay.active, replay.playing, replay.speed]);

  if (!replay.active || liveLen === 0) return null;

  const max = liveLen - 1;
  const idx = Math.min(replay.idx, max);
  const pct = max > 0 ? (idx / max) * 100 : 0;

  const step = (d: number) =>
    patchReplay({
      idx: Math.max(0, Math.min(max, idx + d)),
      playing: false,
    });

  return (
    <div
      role="group"
      aria-label="Controles de replay"
      className="absolute bottom-2 left-1/2 z-20 flex w-[min(560px,calc(100%-16px))] -translate-x-1/2 items-center gap-1.5 rounded border border-[#6b532e] bg-[#151515] px-2 py-1.5 shadow-xl"
    >
      <Tooltip>
        <TooltipTrigger asChild>
          <button type="button" aria-label="Sair do replay" onClick={exitReplay} className={BTN}>
            <X className="h-3.5 w-3.5" />
          </button>
        </TooltipTrigger>
        <TooltipContent side="top" className="text-[10px]">
          Sair do replay (voltar ao vivo)
        </TooltipContent>
      </Tooltip>

      <span className="h-4 w-px bg-[#27272a]" />

      <Tooltip>
        <TooltipTrigger asChild>
          <button type="button" aria-label="Primeira barra" onClick={() => step(-idx)} className={BTN}>
            <ChevronFirst className="h-3.5 w-3.5" />
          </button>
        </TooltipTrigger>
        <TooltipContent side="top" className="text-[10px]">
          Início
        </TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <button type="button" aria-label="Barra anterior" onClick={() => step(-1)} className={BTN}>
            <SkipBack className="h-3.5 w-3.5" />
          </button>
        </TooltipTrigger>
        <TooltipContent side="top" className="text-[10px]">
          −1 barra
        </TooltipContent>
      </Tooltip>

      <button
        type="button"
        aria-label={replay.playing ? 'Pausar replay' : 'Reproduzir replay'}
        onClick={() => patchReplay({ playing: !replay.playing })}
        className="flex h-7 w-7 shrink-0 items-center justify-center rounded bg-[#e8a854] text-[#1a1c20] transition-colors hover:bg-[#f0b96b]"
      >
        {replay.playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
      </button>

      <Tooltip>
        <TooltipTrigger asChild>
          <button type="button" aria-label="Próxima barra" onClick={() => step(1)} className={BTN}>
            <SkipForward className="h-3.5 w-3.5" />
          </button>
        </TooltipTrigger>
        <TooltipContent side="top" className="text-[10px]">
          +1 barra
        </TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <button type="button" aria-label="Última barra" onClick={() => step(max - idx)} className={BTN}>
            <ChevronLast className="h-3.5 w-3.5" />
          </button>
        </TooltipTrigger>
        <TooltipContent side="top" className="text-[10px]">
          Fim
        </TooltipContent>
      </Tooltip>

      <button
        type="button"
        aria-label="Velocidade do replay"
        title="Velocidade (barras por segundo)"
        onClick={() => {
          const i = REPLAY_SPEEDS.indexOf(replay.speed as (typeof REPLAY_SPEEDS)[number]);
          const next = REPLAY_SPEEDS[(i + 1) % REPLAY_SPEEDS.length] ?? 2;
          patchReplay({ speed: next });
        }}
        className="h-6 shrink-0 rounded bg-[#222226] px-1.5 font-num text-[10px] font-bold text-[#e8a854] transition-colors hover:bg-[#27272a]"
      >
        {replay.speed}×
      </button>

      {/* scrub */}
      <input
        type="range"
        min={0}
        max={max}
        step={1}
        value={idx}
        onChange={(e) => patchReplay({ idx: Number(e.target.value) })}
        aria-label="Posição do replay"
        className="h-1.5 min-w-0 flex-1 cursor-pointer appearance-none rounded-full outline-none [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-[#e8a854] [&::-webkit-slider-thumb]:shadow"
        style={{
          background: `linear-gradient(to right, #e8a854 ${pct}%, rgba(255,255,255,0.08) ${pct}%)`,
        }}
      />

      <span className="shrink-0 whitespace-nowrap font-num text-[10px] tabular-nums text-[#e8a854]">
        {idx + 1}/{liveLen}
      </span>
    </div>
  );
}
