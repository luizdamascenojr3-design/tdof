'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { Play, RotateCw, Trash2, X } from 'lucide-react';

import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogTitle,
} from '@/components/ui/dialog';
import { toast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { fmtCompact, fmtHm } from '@/lib/market/format';
import {
  deleteJournalSession,
  fetchSessions,
  journalLoad,
  journalStop,
} from '@/lib/market/journal';
import type { JournalSessionMeta } from '@/lib/market/types';
import { useTerminalStore } from '@/store/terminal';

/** Duração legível a partir de um range em ms (ex.: '4m 30s', '1h 07m', '42s'). */
function fmtDur(ms: number): string {
  const s = Math.max(0, Math.round(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const p2 = (x: number) => String(x).padStart(2, '0');
  if (h > 0) return `${h}h ${p2(m)}m`;
  if (m > 0) return `${m}m ${p2(sec)}s`;
  return `${sec}s`;
}

/**
 * Dialog "Jornal de sessões" — navega, reproduz e exclui gravações do journal
 * (store: dialog === 'sessions'). Estrutura/estilo de symbol-dialog.tsx.
 */
export function SessionsDialog() {
  const dialog = useTerminalStore((s) => s.dialog);
  const setDialog = useTerminalStore((s) => s.setDialog);
  const journal = useTerminalStore((s) => s.journal);
  const patchJournal = useTerminalStore((s) => s.patchJournal);
  const clearJournal = useTerminalStore((s) => s.clearJournal);

  const [sessions, setSessions] = useState<JournalSessionMeta[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [reloadTick, setReloadTick] = useState(0);
  /** sessão com exclusão armada (confirmação em 2 passos, 3s) */
  const [armedId, setArmedId] = useState<number | null>(null);
  const [deletingId, setDeletingId] = useState<number | null>(null);
  const armTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const open = dialog === 'sessions';
  /** primeira carga em voo (lista ainda vazia) */
  const initialLoading = sessions === null && !error;

  // carrega a lista ao abrir o dialog (e a cada refresh) — setState só nos
  // callbacks assíncronos da promise
  useEffect(() => {
    if (!open) return;
    let alive = true;
    fetchSessions()
      .then((r) => {
        if (!alive) return;
        // mais novas primeiro (defensivo: o serviço já ordena por id desc)
        setSessions([...r.sessions].sort((a, b) => b.id - a.id));
        setError(null);
      })
      .catch((e: unknown) => {
        if (!alive) return;
        setError(e instanceof Error ? e.message : 'falha ao listar sessões');
      })
      .finally(() => {
        if (alive) setRefreshing(false);
      });
    return () => {
      alive = false;
    };
  }, [open, reloadTick]);

  // desmontar: cancela o timer da confirmação de exclusão
  useEffect(
    () => () => {
      if (armTimer.current) clearTimeout(armTimer.current);
    },
    [],
  );

  /** Fecha o dialog e reseta o estado local (recarrega ao reabrir). */
  const closeDialog = () => {
    setDialog('none');
    setSessions(null);
    setError(null);
    setRefreshing(false);
    setArmedId(null);
    if (armTimer.current) clearTimeout(armTimer.current);
  };

  /** (Re)carrega a lista a partir de um evento do usuário. */
  const reload = () => {
    setError(null);
    setRefreshing(true);
    setReloadTick((t) => t + 1);
  };

  const armDelete = useCallback((id: number) => {
    setArmedId(id);
    if (armTimer.current) clearTimeout(armTimer.current);
    armTimer.current = setTimeout(() => setArmedId(null), 3000);
  }, []);

  const handleDelete = (s: JournalSessionMeta) => {
    if (armedId !== s.id) {
      armDelete(s.id);
      return;
    }
    if (armTimer.current) clearTimeout(armTimer.current);
    setArmedId(null);
    setDeletingId(s.id);
    deleteJournalSession(s.id)
      .then(() => {
        reload();
      })
      .catch((e: unknown) => {
        toast({
          title: 'Falha ao excluir sessão',
          description: e instanceof Error ? e.message : String(e),
        });
      })
      .finally(() => setDeletingId(null));
  };

  /** Reproduz a sessão: marca o snapshot em trânsito e entra no replay. */
  const handlePlay = (s: JournalSessionMeta) => {
    patchJournal({ loading: true, ended: false });
    journalLoad(s.id, s.tf);
    closeDialog();
  };

  /** Encerra o replay e volta ao feed ao vivo. */
  const exitReplay = () => {
    journalStop();
    clearJournal();
    closeDialog();
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) closeDialog(); }}>
      <DialogContent
        showCloseButton={false}
        className="max-w-lg gap-0 rounded-md border-[#27272a] bg-[#1f1f23] p-0 sm:max-w-lg"
      >
        {/* título */}
        <div className="flex h-10 shrink-0 items-center justify-between border-b border-[#27272a] pl-3 pr-2">
          <DialogTitle className="text-[13px] font-bold text-white">
            Jornal de sessões
          </DialogTitle>
          <div className="flex items-center gap-0.5">
            <button
              type="button"
              onClick={reload}
              aria-label="Atualizar lista de sessões"
              className="flex h-7 w-7 items-center justify-center rounded text-[#5d606b] transition-colors hover:bg-[#222226] hover:text-[#d1d4dc]"
            >
              <RotateCw
                className={cn('h-3.5 w-3.5', (initialLoading || refreshing) && 'animate-spin')}
                aria-hidden="true"
              />
            </button>
            <DialogClose className="flex h-7 w-7 items-center justify-center rounded text-[#5d606b] transition-colors hover:bg-[#222226] hover:text-[#d1d4dc]">
              <X className="h-3.5 w-3.5" aria-hidden="true" />
              <span className="sr-only">Fechar</span>
            </DialogClose>
          </div>
        </div>

        {/* banner do replay em andamento */}
        {journal.loading ? (
          <div className="mx-2 mt-2 rounded border border-[#e8a854]/40 bg-[#e8a854]/10 px-2.5 py-1.5 text-[10px] text-[#e8a854]">
            <span className="animate-pulse">carregando replay…</span>
          </div>
        ) : journal.active ? (
          <div className="mx-2 mt-2 flex items-center justify-between gap-2 rounded border border-[#e8a854]/40 bg-[#e8a854]/10 px-2.5 py-1.5 text-[10px] text-[#e8a854]">
            <span className="min-w-0 truncate">
              Replay em andamento — sessão #{journal.sessionId ?? '—'}
            </span>
            <button
              type="button"
              onClick={exitReplay}
              className="shrink-0 rounded bg-[#e8a854]/15 px-2 py-1 font-medium text-[#e8a854] transition-colors hover:bg-[#e8a854]/25"
            >
              Sair do replay
            </button>
          </div>
        ) : null}

        {/* lista */}
        <div className="scrollbar-thin max-h-[50vh] overflow-y-auto p-2">
          {error ? (
            <div className="flex h-16 flex-col items-center justify-center gap-1.5 rounded border border-[#f2385a]/40 bg-[#f2385a]/10 px-4 text-center">
              <span className="text-[10px] text-[#f2385a]">
                Erro ao carregar sessões: {error}
              </span>
              <button
                type="button"
                onClick={reload}
                className="rounded bg-[#f2385a]/15 px-2 py-1 text-[10px] font-medium text-[#f2385a] transition-colors hover:bg-[#f2385a]/25"
              >
                Tentar novamente
              </button>
            </div>
          ) : initialLoading ? (
            <div className="flex h-16 items-center justify-center rounded border border-[#27272a] bg-[#101012]">
              <span className="animate-pulse text-[10px] text-[#5d606b]">
                carregando sessões…
              </span>
            </div>
          ) : sessions && sessions.length === 0 ? (
            <div className="flex min-h-[80px] items-center justify-center rounded border border-[#27272a] bg-[#101012] px-4 text-center text-[10px] leading-relaxed text-[#5d606b]">
              Nenhuma sessão gravada ainda. Use o botão REC (barra superior) para
              gravar o fluxo ao vivo e reproduzir depois.
            </div>
          ) : (
            sessions?.map((s) => (
              <div
                key={s.id}
                className="flex items-center gap-2 rounded px-2 py-1.5 transition-colors hover:bg-[#222226]"
              >
                <div className="flex min-w-0 flex-1 flex-col">
                  <div className="flex items-center gap-1.5">
                    <span className="whitespace-nowrap font-num text-[12px] font-bold text-white">
                      #{s.symbol}
                    </span>
                    <span className="shrink-0 rounded-sm bg-[#222226] px-1 py-px text-[9px] font-bold uppercase tracking-wider text-[#787b86]">
                      {s.tf}
                    </span>
                  </div>
                  <span className="truncate text-[10px] tabular-nums text-[#787b86]">
                    {fmtHm(s.start)} → {fmtHm(s.end)} · {fmtDur(s.end - s.start)} ·{' '}
                    {fmtCompact(s.events)} eventos
                  </span>
                </div>
                <div className="flex shrink-0 items-center gap-1">
                  <button
                    type="button"
                    onClick={() => handlePlay(s)}
                    disabled={deletingId === s.id}
                    aria-label={`Reproduzir sessão #${s.id}`}
                    className="flex h-7 items-center gap-1 rounded border border-[#e8a854]/40 bg-[#e8a854]/15 px-2 text-[10px] font-medium text-[#e8a854] transition-colors hover:bg-[#e8a854]/25 disabled:opacity-40"
                  >
                    <Play className="h-3 w-3" aria-hidden="true" />
                    Reproduzir
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDelete(s)}
                    disabled={deletingId === s.id}
                    aria-label={
                      armedId === s.id
                        ? `Confirmar exclusão da sessão #${s.id}`
                        : `Excluir sessão #${s.id}`
                    }
                    className={cn(
                      'flex h-7 items-center gap-1 rounded px-1.5 text-[10px] transition-colors disabled:opacity-40',
                      armedId === s.id
                        ? 'bg-[#f2385a]/15 text-[#f2385a]'
                        : 'text-[#5d606b] hover:bg-[#f2385a]/10 hover:text-[#f2385a]',
                    )}
                  >
                    <Trash2 className="h-3 w-3" aria-hidden="true" />
                    {armedId === s.id && (
                      <span className="whitespace-nowrap font-medium">Confirmar?</span>
                    )}
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
