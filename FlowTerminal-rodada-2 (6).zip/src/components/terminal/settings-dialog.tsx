'use client';

import type { ReactNode } from 'react';

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { useTerminalStore } from '@/store/terminal';

/** Padrões das configurações gerais (idênticos ao store). */
const DEFAULTS = {
  showSessionStrip: true,
  showStatusBar: true,
  showDrawingToolbar: true,
  chartCount: 1 as 1 | 2,
};

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mt-4 first:mt-1">
      <h3 className="mb-0.5 text-[10px] font-medium uppercase tracking-wider text-[#787b86]">
        {title}
      </h3>
      {children}
    </section>
  );
}

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-[#262a31] py-2 last:border-0">
      <span className="text-[11px] text-[#d1d4dc]">{label}</span>
      {children}
    </div>
  );
}

function Hint({ children }: { children: ReactNode }) {
  return <p className="pb-2 text-[10px] leading-relaxed text-[#787b86]">{children}</p>;
}

const SELECT_CLS = 'h-8 border-[#27272a] bg-[#222226] px-2 text-[11px] dark:bg-[#222226]';
const ITEM_CLS = 'text-[11px] focus:bg-[#222226] focus:text-[#d1d4dc]';

/**
 * Modal "Configurações gerais" do terminal (store: dialog === 'settings').
 * Interface do workspace (strips/barras) e layout dos gráficos (anexar).
 */
export function SettingsDialog() {
  const dialog = useTerminalStore((s) => s.dialog);
  const setDialog = useTerminalStore((s) => s.setDialog);
  const showSessionStrip = useTerminalStore((s) => s.showSessionStrip);
  const showStatusBar = useTerminalStore((s) => s.showStatusBar);
  const showDrawingToolbar = useTerminalStore((s) => s.showDrawingToolbar);
  const chartCount = useTerminalStore((s) => s.chartCount);
  const patchSettings = useTerminalStore((s) => s.patchSettings);

  return (
    <Dialog
      open={dialog === 'settings'}
      onOpenChange={(o) => {
        if (!o) setDialog('none');
      }}
    >
      <DialogContent className="scrollbar-thin max-h-[80vh] max-w-md gap-0 overflow-y-auto rounded-md border-[#27272a] bg-[#1f1f23] p-4 sm:max-w-md">
        <DialogHeader className="gap-0.5">
          <DialogTitle className="text-[13px] font-bold text-white">
            Configurações gerais
          </DialogTitle>
          <DialogDescription className="text-[10px] text-[#787b86]">
            interface do workspace · gráficos anexados
          </DialogDescription>
        </DialogHeader>

        {/* Interface */}
        <Section title="Interface">
          <Row label="Strip de sessão (rodapé do gráfico)">
            <Switch
              checked={showSessionStrip}
              onCheckedChange={(c) => patchSettings({ showSessionStrip: c })}
            />
          </Row>

          <Row label="Barra de status (rodapé do terminal)">
            <Switch
              checked={showStatusBar}
              onCheckedChange={(c) => patchSettings({ showStatusBar: c })}
            />
          </Row>

          <Row label="Barra de ferramentas de desenho">
            <Switch
              checked={showDrawingToolbar}
              onCheckedChange={(c) => patchSettings({ showDrawingToolbar: c })}
            />
          </Row>
        </Section>

        {/* Gráficos */}
        <Section title="Gráficos">
          <Row label="Gráficos anexados">
            <Select
              value={String(chartCount)}
              onValueChange={(v) => patchSettings({ chartCount: Number(v) === 2 ? 2 : 1 })}
            >
              <SelectTrigger size="sm" className={`${SELECT_CLS} w-[150px]`}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="rounded-md border-[#27272a] bg-[#1f1f23]">
                <SelectItem value="1" className={ITEM_CLS}>
                  1 · solo
                </SelectItem>
                <SelectItem value="2" className={ITEM_CLS}>
                  2 · anexado ao lado
                </SelectItem>
              </SelectContent>
            </Select>
          </Row>
          <Hint>
            O gráfico anexado compartilha o instrumento e os indicadores, com viewport
            independente (zoom/rolagem próprios) — ideal para acompanhar outro timeframe
            ou uma região do book. Atalho: ícone de link no header do gráfico.
            No workspace dockado você também pode ARRASTAR abas para anexar/tabar
            qualquer widget (gráficos, DOM, Tape, Quant) e flutuá-los fora da grade.
          </Hint>
        </Section>

        {/* rodapé */}
        <div className="mt-4 flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={() => patchSettings(DEFAULTS)}
            className="h-8 rounded bg-[#222226] px-3 text-[11px] text-[#d1d4dc] transition-colors hover:bg-[#27272a]"
          >
            Restaurar padrão
          </button>
          <button
            type="button"
            onClick={() => setDialog('none')}
            className="h-8 rounded bg-[#3f3f46] px-3 text-[11px] font-medium text-white transition-colors hover:bg-[#52525b]"
          >
            Fechar
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
