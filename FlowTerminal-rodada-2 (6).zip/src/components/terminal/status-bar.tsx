'use client';

import { memo, useEffect, useState } from 'react';

import { fmtTime } from '@/lib/market/format';
import { useTerminalStore } from '@/store/terminal';

const LINKS = ['Privacidade', 'Termos de uso', 'Licença', 'Parceria'] as const;

function Clock() {
  const [now, setNow] = useState<number | null>(null);
  useEffect(() => {
    const tick = () => setNow(Date.now());
    const t = setTimeout(tick, 0);
    const id = setInterval(tick, 1000);
    return () => {
      clearTimeout(t);
      clearInterval(id);
    };
  }, []);
  return (
    <span className="font-num tabular-nums text-[#d1d4dc]">
      {now === null ? '--:--:--' : fmtTime(now)}
    </span>
  );
}

/** Chip REC: gravação do journal em andamento (ponto vermelho pulsante). */
function RecChip() {
  const recording = useTerminalStore((s) => s.recording);
  if (!recording) return null;
  return (
    <span
      className="flex items-center gap-1.5 whitespace-nowrap"
      title="Gravando journal de mercado"
      aria-label="Gravando journal de mercado"
    >
      <span className="h-1.5 w-1.5 shrink-0 animate-pulse rounded-full bg-[#f2385a]" />
      <span className="font-bold text-[#f2385a]">REC</span>
    </span>
  );
}

/** Chip do replay do journal: progresso % ou snapshot em trânsito. */
function JournalChip() {
  const journal = useTerminalStore((s) => s.journal);
  if (journal.loading) {
    return (
      <span className="whitespace-nowrap text-[#e8a854]" title="Snapshot do journal em trânsito">
        carregando replay…
      </span>
    );
  }
  if (!journal.active) return null;
  return (
    <span className="whitespace-nowrap text-[#e8a854]" title="Replay de sessão gravada (journal)">
      JORNAL{' '}
      <span className="font-num tabular-nums">{Math.round(journal.pct)}%</span>
    </span>
  );
}

/** Chip do motor MBO: stream binário + worker/WASM + latência. */
function MboChip() {
  const useMbo = useTerminalStore((s) => s.useMbo);
  const stats = useTerminalStore((s) => s.mboStats);
  if (!useMbo) {
    return <span className="whitespace-nowrap text-[#5d606b]">MBO off</span>;
  }
  const live = !!stats && stats.frames > 0;
  const tip = !live
    ? 'aguardando frames…'
    : `Δbin · ${stats.frames} frames · ${stats.lastLatencyUs}µs · ${
        stats.wasm ? 'wasm' : 'js'
      }`;
  return (
    <span
      className="whitespace-nowrap"
      title={tip}
      aria-label={`Motor MBO ${tip}`}
    >
      <span className={live ? 'text-[#089981]' : 'text-[#5d606b]'}>MBO</span>{' '}
      <span className="font-num tabular-nums text-[#d1d4dc]">
        {live ? `${stats?.lastLatencyUs ?? 0}µs${stats?.wasm ? ' ·wasm' : ''}` : '…'}
      </span>
    </span>
  );
}

/** Contador de sinais de fluxo vivos (absorção/exaustão/iceberg). */
function FlowChip() {
  const show = useTerminalStore((s) => s.showFlowSignals);
  const signals = useTerminalStore((s) => s.flowSignals);
  if (!show) return null;
  const n = signals.length;
  return (
    <span className="whitespace-nowrap" title="Sinais de fluxo vivos (TTL 6s)">
      fluxo{' '}
      <span className={n > 0 ? 'font-num tabular-nums text-[#e8a854]' : 'text-[#5d606b]'}>{n}</span>
    </span>
  );
}

/** Rodapé estilo ATAS Web: copyright à esquerda, links + relógio à direita. */
export const StatusBar = memo(function StatusBar() {
  return (
    <footer className="flex h-7 shrink-0 items-center gap-3 border-t border-[#27272a] bg-[#151515] px-3 text-[10px] text-[#787b86]">
      <div className="flex min-w-0 items-center gap-2">
        <span className="truncate whitespace-nowrap">
          2010-2026 © Copyright · FlowTerminal
        </span>
        <span className="hidden whitespace-nowrap sm:inline" aria-hidden="true">
          ·
        </span>
        <span className="hidden truncate whitespace-nowrap sm:inline">
          Powered by motor de fluxo simulado (tempo real)
        </span>
      </div>

      <div className="ml-auto flex shrink-0 items-center gap-3">
        <RecChip />
        <JournalChip />
        <MboChip />
        <FlowChip />
        <nav className="hidden items-center gap-1.5 md:flex" aria-label="Links">
          {LINKS.map((label, i) => (
            <span key={label} className="flex items-center gap-1.5">
              {i > 0 && (
                <span className="text-[#5d606b]" aria-hidden="true">
                  ·
                </span>
              )}
              <button
                type="button"
                className="whitespace-nowrap transition-colors hover:text-[#d1d4dc]"
              >
                {label}
              </button>
            </span>
          ))}
        </nav>
        <Clock />
      </div>
    </footer>
  );
});
