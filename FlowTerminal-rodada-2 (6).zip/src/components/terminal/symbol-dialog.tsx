'use client';

import { useMemo, useState } from 'react';
import { X } from 'lucide-react';

import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { SYMBOLS } from '@/lib/market/types';
import type { SymbolMeta } from '@/lib/market/types';
import { useTerminalStore } from '@/store/terminal';

/** Instrumentos exibidos mas sem dados (não selecionáveis). */
const UNAVAILABLE: ReadonlyArray<{ symbol: string; label: string }> = [
  { symbol: 'WDOFUT', label: 'Mini Dólar' },
  { symbol: 'NQ', label: 'Nasdaq 100' },
  { symbol: 'DAX', label: 'Futuro Alemanha' },
];

/** Descrição curta do instrumento a partir do label "SYM · Descrição". */
function subLabel(meta: SymbolMeta): string {
  return meta.label.startsWith(`${meta.symbol} `)
    ? meta.label.slice(meta.symbol.length + 1).replace(/^·\s*/, '')
    : meta.label;
}

interface Entry {
  symbol: string;
  label: string;
  tick: number | null;
}

/** Busca de instrumentos estilo ATAS Web (store: dialog === 'symbol'). */
export function SymbolDialog() {
  const dialog = useTerminalStore((s) => s.dialog);
  const setDialog = useTerminalStore((s) => s.setDialog);
  const setSymbol = useTerminalStore((s) => s.setSymbol);
  const [query, setQuery] = useState('');

  const entries = useMemo<Entry[]>(() => {
    const available: Entry[] = SYMBOLS.map((m) => ({
      symbol: m.symbol,
      label: subLabel(m),
      tick: m.tick,
    }));
    const unavailable: Entry[] = UNAVAILABLE.map((u) => ({ ...u, tick: null }));
    const all = [...available, ...unavailable];
    const q = query.trim().toLowerCase();
    if (!q) return all;
    return all.filter(
      (e) => e.symbol.toLowerCase().includes(q) || e.label.toLowerCase().includes(q),
    );
  }, [query]);

  return (
    <Dialog
      open={dialog === 'symbol'}
      onOpenChange={(o) => {
        if (!o) setDialog('none');
      }}
    >
      <DialogContent
        showCloseButton={false}
        className="max-w-md gap-0 rounded-md border-[#27272a] bg-[#1f1f23] p-0 sm:max-w-md"
      >
        {/* título */}
        <div className="flex h-10 shrink-0 items-center justify-between border-b border-[#27272a] pl-3 pr-2">
          <DialogTitle className="text-[13px] font-bold text-white">Símbolo</DialogTitle>
          <DialogClose className="flex h-7 w-7 items-center justify-center rounded text-[#5d606b] transition-colors hover:bg-[#222226] hover:text-[#d1d4dc]">
            <X className="h-3.5 w-3.5" aria-hidden="true" />
            <span className="sr-only">Fechar</span>
          </DialogClose>
        </div>

        {/* busca */}
        <div className="p-2">
          <Input
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar instrumento…"
            className="h-9 border-[#27272a] bg-[#222226] text-[12px] dark:bg-[#222226] placeholder:text-[#5d606b] focus-visible:border-[#4682b4] focus-visible:ring-[#4682b4]/30"
          />

          {/* lista */}
          <div className="scrollbar-thin mt-2 max-h-[50vh] overflow-y-auto">
            {entries.length === 0 ? (
              <div className="flex h-16 items-center justify-center text-[10px] text-[#5d606b]">
                Nenhum instrumento
              </div>
            ) : (
              entries.map((e) =>
                e.tick !== null ? (
                  <button
                    key={e.symbol}
                    type="button"
                    onClick={() => {
                      setSymbol(e.symbol);
                      setDialog('none');
                    }}
                    className="flex h-11 w-full items-center justify-between gap-2 rounded px-2 text-left transition-colors hover:bg-[#222226]"
                  >
                    <span className="flex min-w-0 flex-col">
                      <span className="whitespace-nowrap font-num text-[12px] font-bold text-white">
                        #{e.symbol}
                      </span>
                      <span className="truncate text-[10px] text-[#787b86]">
                        {e.label}
                      </span>
                    </span>
                    <span className="shrink-0 text-[10px] tabular-nums text-[#787b86]">
                      tick {e.tick}
                    </span>
                  </button>
                ) : (
                  <div
                    key={e.symbol}
                    className="flex h-11 items-center justify-between gap-2 rounded px-2 opacity-40"
                    aria-disabled="true"
                  >
                    <span className="flex min-w-0 flex-col">
                      <span className="whitespace-nowrap font-num text-[12px] font-bold text-white">
                        #{e.symbol}
                      </span>
                      <span className="truncate text-[10px] text-[#787b86]">
                        {e.label}
                      </span>
                    </span>
                    <span className="shrink-0 rounded-sm bg-[#222226] px-1 py-px text-[9px] text-[#787b86]">
                      sem dados
                    </span>
                  </div>
                ),
              )
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
