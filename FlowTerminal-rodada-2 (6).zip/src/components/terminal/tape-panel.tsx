'use client';

import { memo, useEffect, useMemo, useRef, useState } from 'react';
import { GripVertical, X, Zap } from 'lucide-react';

import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import { fmtPrice, fmtSignedCompact, fmtSize, fmtTime } from '@/lib/market/format';
import { TF_MS, symbolMeta } from '@/lib/market/types';
import type { MboOp, Trade } from '@/lib/market/types';
import { useTerminalStore } from '@/store/terminal';

const MAX_ROWS = 120;
const ROW_HEIGHT = 24;
const SKELETON_ROWS = 15;

const GRID_COLS = 'grid-cols-[1.3fr_1fr_1fr]';
/** colunas do log MBO: Hora | Lado | Preço | Qt(Δ) */
const MBO_GRID_COLS = 'grid-cols-[1.1fr_0.9fr_1fr_1.1fr]';

type TapeFilter = 'all' | 'buy' | 'sell' | 'big';
type TapeTab = 'tape' | 'mbo';

/** "Grande" por tamanho mínimo configurado ou pela marcação do servidor por símbolo. */
function isBigTrade(trade: Trade, bigTradeSize: number): boolean {
  return bigTradeSize > 0 ? trade.s >= bigTradeSize : !!trade.big;
}

interface TapeRowProps {
  trade: Trade;
  big: boolean;
  tick: number;
  sizeDecimals: number;
}

/**
 * Uma linha do Time & Sales. Memoizada: o objeto Trade é estável no store,
 * então só a linha nova re-renderiza a cada trade (~10-20Hz).
 */
const TapeRow = memo(function TapeRow({ trade, big, tick, sizeDecimals }: TapeRowProps) {
  const buy = trade.side === 'buy';
  const sideCls = buy ? 'text-[#089981]' : 'text-[#f2385a]';

  return (
    <div
      className={cn(
        'grid h-6 shrink items-center border-l-2 px-2 font-num text-[11px] tabular-nums',
        big ? 'border-l-[#e8a854] bg-[#e8a854]/10' : 'border-l-transparent',
      )}
    >
      <span className="text-[10px] text-[#787b86]">{fmtTime(trade.t)}</span>
      <span className={`text-right ${sideCls}`}>{fmtPrice(trade.p, tick)}</span>
      <span className={`flex items-center justify-end gap-1 text-right ${sideCls}`}>
        {big && <Zap size={10} className="shrink-0 text-[#e8a854]" aria-hidden="true" />}
        <span className={cn('font-bold', big && 'text-[#e8a854]')}>
          {fmtSize(trade.s, sizeDecimals)}
        </span>
      </span>
    </div>
  );
});

/**
 * Uma linha do log MBO (operação de book decodificada no worker).
 * Memoizada — o objeto MboOp é estável no store entre frames.
 */
const MboRow = memo(function MboRow({ op, tick, sizeDecimals }: MboRowProps) {
  const bid = op.side === 0;
  const sideCls = bid ? 'text-[#089981]' : 'text-[#f2385a]';
  const removed = op.op === 1;
  const glyph = removed ? '×' : op.dq > 0 ? '+' : '·';
  const glyphCls = removed
    ? 'text-[#f2385a]'
    : op.dq > 0
      ? 'text-[#089981]'
      : 'text-[#5d606b]';
  const glyphTip = removed
    ? 'ordem removida do nível (cancelamento/execução)'
    : op.dq > 0
      ? 'liquidez adicionada ao nível'
      : 'atualização do nível (sem acréscimo)';

  return (
    <div
      className={cn(
        'grid h-6 shrink items-center border-l-2 border-l-transparent px-2 font-num text-[11px] tabular-nums',
      )}
    >
      <span className="text-[10px] text-[#787b86]">{fmtTime(op.t)}</span>
      <span className="flex items-center gap-1">
        <span title={glyphTip} className={cn('leading-none', glyphCls)}>
          {glyph}
        </span>
        <span className={cn('text-[9px] font-bold uppercase leading-none', sideCls)}>
          {bid ? 'BID' : 'ASK'}
        </span>
      </span>
      <span className={cn('text-right', sideCls)}>{fmtPrice(op.idx * tick, tick)}</span>
      <span className="flex items-center justify-end gap-1 text-right">
        <span className={sideCls}>{fmtSize(op.qty, sizeDecimals)}</span>
        <span className="text-[9px] text-[#5d606b]">{fmtSignedCompact(op.dq)}</span>
      </span>
    </div>
  );
});

function TapeSkeleton() {
  return (
    <div className="flex flex-col gap-px py-1">
      {Array.from({ length: SKELETON_ROWS }, (_, i) => (
        <div
          key={i}
          className="mx-2 h-6 shrink animate-pulse bg-[#222226]"
        />
      ))}
    </div>
  );
}

interface MboRowProps {
  op: MboOp;
  tick: number;
  sizeDecimals: number;
}

const FILTER_ITEMS: Array<{ value: TapeFilter; label: string }> = [
  { value: 'all', label: 'Todos' },
  { value: 'buy', label: 'Compras' },
  { value: 'sell', label: 'Vendas' },
  { value: 'big', label: 'Grandes' },
];

const ITEM_CLS =
  'h-6 rounded px-1.5 text-[10px] text-[#787b86] hover:bg-[#222226] hover:text-[#d1d4dc] data-[state=on]:bg-[#27272a] data-[state=on]:text-white data-[state=on]:shadow-[inset_0_-2px_0_0_#4682b4]';

interface TapePanelProps {
  className?: string;
}

/** Widget SMART TAPE estilo ATAS Web (time & sales). */
export default function TapePanel({ className }: TapePanelProps) {
  const tape = useTerminalStore((s) => s.tape);
  const symbol = useTerminalStore((s) => s.symbol);
  const session = useTerminalStore((s) => s.session);
  const bigTradeSize = useTerminalStore((s) => s.bigTradeSize);
  const mboLog = useTerminalStore((s) => s.mboLog);
  // replay: esconde impressões do "futuro" (depois do playhead)
  const replayActive = useTerminalStore((s) => s.replay.active);
  const replayIdx = useTerminalStore((s) => s.replay.idx);
  const tf = useTerminalStore((s) => s.tf);
  const candleT = useTerminalStore((s) => s.candles[s.replay.idx]?.t ?? 0);

  const { tick, sizeDecimals } = symbolMeta(symbol);

  const [filter, setFilter] = useState<TapeFilter>('all');
  const [tab, setTab] = useState<TapeTab>('tape');

  const rows = useMemo<Trade[]>(() => {
    const cutT = replayActive ? candleT + TF_MS[tf] : Infinity;
    const base = replayActive ? tape.filter((t) => t.t <= cutT) : tape;
    let list: readonly Trade[];
    switch (filter) {
      case 'buy':
        list = base.filter((t) => t.side === 'buy');
        break;
      case 'sell':
        list = base.filter((t) => t.side === 'sell');
        break;
      case 'big':
        list = base.filter((t) => isBigTrade(t, bigTradeSize));
        break;
      default:
        list = base;
    }
    return list.slice(0, MAX_ROWS);
  }, [tape, filter, bigTradeSize, replayActive, replayIdx, candleT, tf]);

  const replayCutEmpty = replayActive && rows.length === 0;

  const listRef = useRef<HTMLDivElement | null>(null);
  const prevTopId = useRef<number | undefined>(undefined);
  const topId = rows.length > 0 ? rows[0].id : undefined;

  // Newest-on-top com preservação de scroll: ao entrar linha nova no topo,
  // compensa o deslocamento apenas se o usuário estiver rolado para baixo.
  useEffect(() => {
    const el = listRef.current;
    if (!el || tab !== 'tape') return;
    if (topId === undefined) {
      prevTopId.current = undefined;
      return;
    }
    const prev = prevTopId.current;
    prevTopId.current = topId;
    if (prev === undefined || prev === topId) return;
    const added = rows.findIndex((t) => t.id === prev);
    if (added > 0 && el.scrollTop > 4) el.scrollTop += added * ROW_HEIGHT;
  }, [topId, rows, tab]);

  return (
    <div
      className={cn(
        // tabular-nums na raiz: dígitos de largura fixa em TODAS as linhas
        // (hora/preço/qt) — alinhamento vertical rígido da fita
        'flex h-full w-full flex-col overflow-hidden bg-[#18181b] tabular-nums',
        className,
      )}
    >
      {/* chrome do widget + filtros */}
      <div className="flex h-9 shrink-0 items-center gap-2 border-b border-[#27272a] bg-[#151515] px-2">
        <GripVertical className="h-3.5 w-3.5 shrink-0 text-[#5d606b]" aria-hidden="true" />
        <span className="whitespace-nowrap text-[12px] font-bold text-white">
          #{symbol}
        </span>
        <span className="hidden whitespace-nowrap text-[10px] text-[#787b86] lg:inline">
          SMART TAPE
        </span>
        {replayActive && (
          <span className="shrink-0 rounded bg-[#33291a] px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-wider text-[#e8a854]">
            replay
          </span>
        )}
        <div className="min-w-0 flex-1" />
        <ToggleGroup
          type="single"
          size="sm"
          value={tab}
          onValueChange={(v) => {
            if (v) setTab(v as TapeTab);
          }}
          className="shrink-0 gap-0.5"
          aria-label="Conteúdo do painel"
        >
          <ToggleGroupItem value="tape" className={ITEM_CLS}>
            TAPE
          </ToggleGroupItem>
          <ToggleGroupItem value="mbo" className={ITEM_CLS}>
            MBO LOG
          </ToggleGroupItem>
        </ToggleGroup>
        {tab === 'tape' && (
          <ToggleGroup
            type="single"
            size="sm"
            value={filter}
            onValueChange={(v) => {
              if (v) setFilter(v as TapeFilter);
            }}
            className="shrink-0 gap-0.5"
          >
            {FILTER_ITEMS.map((item) => (
              <ToggleGroupItem key={item.value} value={item.value} className={ITEM_CLS}>
                {item.label}
              </ToggleGroupItem>
            ))}
          </ToggleGroup>
        )}
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              type="button"
              aria-label="Fechar widget"
              className="flex h-7 w-7 shrink-0 items-center justify-center rounded text-[#5d606b] transition-colors hover:bg-[#222226] hover:text-[#d1d4dc]"
            >
              <X className="h-3.5 w-3.5" aria-hidden="true" />
            </button>
          </TooltipTrigger>
          <TooltipContent
            side="bottom"
            className="rounded border border-[#27272a] bg-[#1f1f23] px-2 py-1 text-[10px] text-[#d1d4dc]"
          >
            Fechar · em breve
          </TooltipContent>
        </Tooltip>
      </div>

      {/* cabeçalho das colunas */}
      {tab === 'tape' ? (
        <div
          className={`grid h-6 shrink-0 ${GRID_COLS} bg-[#101012] px-2 text-[9px] uppercase leading-none text-[#787b86]`}
        >
          <span className="flex items-center">Hora</span>
          <span className="flex items-center justify-end">Preço</span>
          <span className="flex items-center justify-end">Quant</span>
        </div>
      ) : (
        <div
          className={`grid h-6 shrink-0 ${MBO_GRID_COLS} bg-[#101012] px-2 text-[9px] uppercase leading-none text-[#787b86]`}
        >
          <span className="flex items-center">Hora</span>
          <span className="flex items-center">Lado</span>
          <span className="flex items-center justify-end">Preço</span>
          <span className="flex items-center justify-end">Qt(Δ)</span>
        </div>
      )}

      {/* lista */}
      <div
        ref={listRef}
        className="scrollbar-thin min-h-0 flex-1 overflow-y-auto"
      >
        {tab === 'mbo' ? (
          mboLog.length === 0 ? (
            <div className="flex h-16 flex-col items-center justify-center gap-1 px-3 text-center">
              <span className="text-[10px] text-[#5d606b]">
                aguardando operações do book (stream MBO)…
              </span>
            </div>
          ) : (
            mboLog.map((op) => (
              <MboRow
                key={`${op.t}-${op.side}-${op.idx}-${op.op}-${op.qty}`}
                op={op}
                tick={tick}
                sizeDecimals={sizeDecimals}
              />
            ))
          )
        ) : tape.length === 0 ? (
          <TapeSkeleton />
        ) : rows.length === 0 ? (
          <div className="flex h-16 flex-col items-center justify-center gap-1 px-3 text-center">
            <span className="text-[10px] text-[#5d606b]">
              {replayCutEmpty
                ? 'sem impressões até o playhead do replay'
                : 'Nenhum negócio neste filtro'}
            </span>
            {replayCutEmpty && (
              <span className="text-[9px] text-[#5d606b]/70">
                o tape continua registrando ao vivo
              </span>
            )}
          </div>
        ) : (
          rows.map((t) => (
            <TapeRow
              key={t.id}
              trade={t}
              big={isBigTrade(t, bigTradeSize)}
              tick={tick}
              sizeDecimals={sizeDecimals}
            />
          ))
        )}
      </div>

      {/* rodapé */}
      <div className="flex h-7 shrink-0 items-center gap-3 border-t border-[#27272a] px-2 text-[10px]">
        {tab === 'mbo' ? (
          <span className="truncate whitespace-nowrap text-[#5d606b]">
            delta de ordens por nível · motor MBO binário
          </span>
        ) : (
          <>
            <span className="text-[#787b86]">
              últ{' '}
              <span className="font-num tabular-nums text-[#d1d4dc]">
                {session ? fmtPrice(session.last, tick) : '—'}
              </span>
            </span>
            <span className="ml-auto whitespace-nowrap tabular-nums text-[#787b86]">
              {rows.length} negócios
            </span>
          </>
        )}
      </div>
    </div>
  );
}
