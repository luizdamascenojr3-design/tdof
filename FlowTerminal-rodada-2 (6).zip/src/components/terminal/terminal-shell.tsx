'use client';

import { useEffect, useState, type ReactNode } from 'react';
import { CandlestickChart, ListOrdered, ReceiptText, Sigma } from 'lucide-react';

import { DrawingToolbar } from './drawing-toolbar';
import { DownloadDialog } from './download-dialog';
import { IndicatorsDialog } from './indicators-dialog';
import { SessionsDialog } from './sessions-dialog';
import { SettingsDialog } from './settings-dialog';
import { SymbolDialog } from './symbol-dialog';
import { TopBar } from './topbar';
import { WorkspaceDock } from './dock-shell';
import { ChartWidget } from './chart-widget';
import DomPanel from './dom-panel';
import TapePanel from './tape-panel';
import QuantPanel from './quant-panel';
import { StatusBar } from './status-bar';
import { useTerminalConnection } from '@/lib/market/socket';
import { initTradingEngine } from '@/lib/trading/engine';
import { hydrateDrawings } from '@/lib/drawings';
import { useTerminalStore } from '@/store/terminal';
import { useIsMobile } from '@/hooks/use-mobile';

type MobileTab = 'chart' | 'dom' | 'tape' | 'quant';

function MobileTabBar({
  tab,
  onChange,
}: {
  tab: MobileTab;
  onChange: (t: MobileTab) => void;
}) {
  const items: { id: MobileTab; label: string; icon: ReactNode }[] = [
    { id: 'chart', label: 'Gráfico', icon: <CandlestickChart className="h-3.5 w-3.5" /> },
    { id: 'dom', label: 'DOM', icon: <ListOrdered className="h-3.5 w-3.5" /> },
    { id: 'tape', label: 'Tape', icon: <ReceiptText className="h-3.5 w-3.5" /> },
    { id: 'quant', label: 'Quant', icon: <Sigma className="h-3.5 w-3.5" /> },
  ];
  return (
    <nav className="flex h-11 shrink-0 items-stretch gap-1 border-t border-[#27272a] bg-[#151515] px-1">
      {items.map((it) => (
        <button
          key={it.id}
          type="button"
          onClick={() => onChange(it.id)}
          aria-current={tab === it.id}
          className={`flex flex-1 flex-col items-center justify-center gap-0.5 rounded px-0.5 text-[9px] font-medium transition-colors ${
            tab === it.id
              ? 'bg-[#27272a] text-white shadow-[inset_0_2px_0_0_#4682b4]'
              : 'text-[#787b86] hover:text-[#d1d4dc]'
          }`}
        >
          {it.icon}
          {it.label}
        </button>
      ))}
    </nav>
  );
}

/**
 * Casca do terminal estilo ATAS Web: topbar global, barra de ferramentas de
 * desenho, workspace DOCKADO (dockview — gráficos e widgets encaixáveis,
 * "anexar o gráfico no outro" por drag & drop), status bar e diálogos.
 * Mobile mantém abas simples; o motor de trading é ligado uma única vez aqui.
 */
export function TerminalShell() {
  useTerminalConnection();
  useEffect(() => {
    initTradingEngine();
    // desenhos persistidos: leitura do localStorage SÓ pós-montagem —
    // hidrata SSR e cliente com `items` vazios (zero mismatch)
    hydrateDrawings();
  }, []);

  // atalho MODO FOCO: tecla "F" — colapsa/restaura os painéis de dados.
  // Guards: sem modificadores, fora de inputs/editor de texto do canvas e
  // com diálogo fechado (evita toggle acidental ao digitar).
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== 'f' && e.key !== 'F') return;
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const t = e.target as HTMLElement | null;
      if (
        t &&
        (t.tagName === 'INPUT' ||
          t.tagName === 'TEXTAREA' ||
          t.tagName === 'SELECT' ||
          t.isContentEditable)
      ) {
        return;
      }
      const st = useTerminalStore.getState();
      if (st.dialog !== 'none') return;
      e.preventDefault();
      st.setFocusMode(!st.focusMode);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);
  const isMobile = useIsMobile();
  const showStatusBar = useTerminalStore((s) => s.showStatusBar);
  const showDrawingToolbar = useTerminalStore((s) => s.showDrawingToolbar);
  const [tab, setTab] = useState<MobileTab>('chart');

  return (
    <div className="dark flex h-[100dvh] min-h-0 flex-col overflow-hidden bg-[#18181b] text-[#d1d4dc]">
      <TopBar />

      {isMobile ? (
        <main className="flex min-h-0 flex-1 flex-col">
          <div className="flex min-h-0 flex-1 flex-col">
            {tab === 'chart' && <ChartWidget />}
            {tab === 'dom' && <DomPanel className="h-full w-full" />}
            {tab === 'tape' && <TapePanel className="h-full w-full" />}
            {tab === 'quant' && <QuantPanel className="h-full w-full" />}
          </div>
          <MobileTabBar tab={tab} onChange={setTab} />
        </main>
      ) : (
        <div className="flex min-h-0 flex-1">
          {/* barra de desenho ENCAIXADA: coluna lateral fixa e opaca com
              divisória sólida — não flutua nem bloqueia o canvas WebGL */}
          {showDrawingToolbar && <DrawingToolbar />}
          {/* workspace dockado (dockview): gráficos + DOM/Tape/Quant como
              painéis arrastáveis — anexar, tabar, flutuar, fechar */}
          <WorkspaceDock />
        </div>
      )}

      {showStatusBar && <StatusBar />}
      <SymbolDialog />
      <IndicatorsDialog />
      <SessionsDialog />
      <SettingsDialog />
      <DownloadDialog />
    </div>
  );
}
