'use client';

import { memo, type ReactNode } from 'react';
import {
  CandlestickChart,
  Circle,
  Clock,
  Download,
  Focus,
  Grid2x2,
  History,
  LayoutGrid,
  ListOrdered,
  Plus,
  ReceiptText,
  RotateCcw,
  Sigma,
} from 'lucide-react';

import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { setJournalRecording } from '@/lib/market/journal';
import { requestDockPanel, requestDockReset } from './dock-shell';
import { useTerminalStore } from '@/store/terminal';
import type { ConnStatus } from '@/store/terminal';
import { toast } from '@/hooks/use-toast';

/** Conteúdo do pill de conexão por status (cores da paleta ATAS). */
const STATUS_META: Record<ConnStatus, { dot: string; label: string }> = {
  live: { dot: '#089981', label: 'dados simulados · ao vivo' },
  connecting: { dot: '#e8a854', label: 'conectando' },
  offline: { dot: '#f2385a', label: 'offline' },
};

function Hint({
  children,
  label,
  side = 'bottom',
}: {
  children: ReactNode;
  label: string;
  side?: 'top' | 'bottom' | 'left' | 'right';
}) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>{children}</TooltipTrigger>
      <TooltipContent
        side={side}
        className="rounded border border-[#27272a] bg-[#1f1f23] px-2 py-1 text-[10px] text-[#d1d4dc]"
      >
        {label}
      </TooltipContent>
    </Tooltip>
  );
}

function HexLogo() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path
        d="M12 2 20.66 7v10L12 22 3.34 17V7L12 2Z"
        stroke="#a1a1aa"
        strokeWidth="1.8"
        strokeLinejoin="round"
      />
      <path d="M12 7 16.33 9.5v5L12 17l-4.33-2.5v-5L12 7Z" fill="#52525b" />
    </svg>
  );
}

export const TopBar = memo(function TopBar() {
  const status = useTerminalStore((s) => s.status);
  const setDialog = useTerminalStore((s) => s.setDialog);
  const symbol = useTerminalStore((s) => s.symbol);
  const tf = useTerminalStore((s) => s.tf);
  const recording = useTerminalStore((s) => s.recording);
  const journalActive = useTerminalStore((s) => s.journal.active);
  const chartCount = useTerminalStore((s) => s.chartCount);
  const dockPanelIds = useTerminalStore((s) => s.dockPanelIds);
  const focusMode = useTerminalStore((s) => s.focusMode);
  const setFocusMode = useTerminalStore((s) => s.setFocusMode);
  const patch = useTerminalStore((s) => s.patchSettings);
  const meta = STATUS_META[status];

  /** Liga/desliga a gravação do journal (REC) p/ o símbolo/tf correntes. */
  const toggleRec = async () => {
    const st = useTerminalStore.getState();
    if (st.journal.active) return; // em replay não se grava
    const on = !st.recording;
    st.setRecording(on); // otimista
    try {
      await setJournalRecording(on, symbol, tf);
      toast({
        title: on ? 'Gravação iniciada' : 'Gravação encerrada',
        description: on
          ? `${symbol} · ${tf} — o fluxo está sendo gravado no journal.`
          : 'A sessão gravada já pode ser reproduzida no jornal.',
      });
    } catch {
      useTerminalStore.getState().setRecording(false);
      toast({
        title: 'Falha na gravação',
        description: 'O serviço de journal não respondeu.',
        variant: 'destructive',
      });
    }
  };

  return (
    <header className="flex h-10 shrink-0 items-center gap-2 border-b border-[#27272a] bg-[#151515] px-2">
      {/* logo */}
      <div className="flex shrink-0 items-center gap-1.5">
        <HexLogo />
        <span className="text-[14px] font-bold text-white">ATAS</span>
      </div>

      {/* REC: gravação do journal de mercado */}
      <Hint
        label={
          journalActive
            ? 'Indisponível durante o replay'
            : recording
              ? 'Parar gravação do journal'
              : 'Gravar o fluxo ao vivo no journal (replay depois)'
        }
      >
        <button
          type="button"
          aria-label={recording ? 'Parar gravação' : 'Iniciar gravação'}
          aria-pressed={recording}
          onClick={() => void toggleRec()}
          disabled={journalActive}
          className={`flex h-7 shrink-0 items-center gap-1.5 rounded px-2 text-[11px] font-medium transition-colors disabled:opacity-40 ${
            recording
              ? 'border border-[#f2385a] bg-[#3a2026] text-[#ff8b9d] hover:bg-[#4a2830]'
              : 'bg-[#222226] text-[#d1d4dc] hover:bg-[#27272a]'
          }`}
        >
          <Circle
            className={`h-2.5 w-2.5 ${recording ? 'animate-pulse fill-[#f2385a] text-[#f2385a]' : 'text-[#787b86]'}`}
            aria-hidden="true"
          />
          REC
        </button>
      </Hint>

      {/* Jornal de sessões (replay com journal) — icon-only, carga visual limpa */}
      <Hint label="Jornal: sessões gravadas + replay">
        <button
          type="button"
          aria-label="Abrir jornal de sessões"
          onClick={() => setDialog('sessions')}
          className={`flex h-7 w-7 shrink-0 items-center justify-center rounded transition-colors ${
            journalActive
              ? 'border border-[#e8a854] bg-[#3a3020] text-[#e8a854] hover:bg-[#4a3a26]'
              : 'bg-[#222226] text-[#d1d4dc] hover:bg-[#27272a]'
          }`}
        >
          <History className="h-3.5 w-3.5" aria-hidden="true" />
        </button>
      </Hint>

      {/* + adicionar widget (workspace dockado — dockview) — icon-only */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button
            type="button"
            aria-label="Adicionar widget"
            className="flex h-7 w-7 shrink-0 items-center justify-center rounded bg-[#222226] text-[#d1d4dc] transition-colors hover:bg-[#27272a]"
          >
            <Plus className="h-3.5 w-3.5" aria-hidden="true" />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent
          align="start"
          className="border-[#27272a] bg-[#1f1f23] text-[#d1d4dc]"
        >
          <DropdownMenuLabel className="text-[9px] uppercase tracking-wider text-[#787b86]">
            Widgets do workspace
          </DropdownMenuLabel>
          <DropdownMenuItem
            onClick={() => requestDockPanel('chart-1')}
            disabled={dockPanelIds.includes('chart-1')}
            className="gap-2 text-[11px] data-[highlighted]:bg-[#27272a] data-[disabled]:opacity-50"
          >
            <CandlestickChart className="h-3.5 w-3.5" />
            Gráfico (principal)
            {dockPanelIds.includes('chart-1') && <span className="ml-auto text-[#d1d4dc]">●</span>}
          </DropdownMenuItem>
          <DropdownMenuItem
            onClick={() => patch({ chartCount: 2 })}
            disabled={chartCount === 2}
            className="gap-2 text-[11px] data-[highlighted]:bg-[#27272a] data-[disabled]:opacity-50"
          >
            <Grid2x2 className="h-3.5 w-3.5" />
            Gráfico (anexar ao lado)
            {chartCount === 2 && <span className="ml-auto text-[#d1d4dc]">●</span>}
          </DropdownMenuItem>
          <DropdownMenuItem
            onClick={() => requestDockPanel('chart', { tf: '5m' })}
            className="gap-2 text-[11px] data-[highlighted]:bg-[#27272a]"
          >
            <Clock className="h-3.5 w-3.5" />
            Gráfico (M5 pinado)
            <span className="ml-auto text-[9px] text-[#5d606b]">novo painel</span>
          </DropdownMenuItem>
          <DropdownMenuItem
            onClick={() => requestDockPanel('chart', { barType: 'tick', barParam: 50 })}
            className="gap-2 text-[11px] data-[highlighted]:bg-[#27272a]"
          >
            <Sigma className="h-3.5 w-3.5" />
            Gráfico (Tick 50 pinado)
            <span className="ml-auto text-[9px] text-[#5d606b]">novo painel</span>
          </DropdownMenuItem>
          <DropdownMenuSeparator className="bg-[#27272a]" />
          <DropdownMenuItem
            onClick={() => requestDockPanel('dom')}
            disabled={dockPanelIds.includes('dom')}
            className="gap-2 text-[11px] data-[highlighted]:bg-[#27272a] data-[disabled]:opacity-50"
          >
            <ListOrdered className="h-3.5 w-3.5" />
            DOM · profundidade
            {dockPanelIds.includes('dom') && <span className="ml-auto text-[#d1d4dc]">●</span>}
          </DropdownMenuItem>
          <DropdownMenuItem
            onClick={() => requestDockPanel('tape')}
            disabled={dockPanelIds.includes('tape')}
            className="gap-2 text-[11px] data-[highlighted]:bg-[#27272a] data-[disabled]:opacity-50"
          >
            <ReceiptText className="h-3.5 w-3.5" />
            SMART TAPE · fita
            {dockPanelIds.includes('tape') && <span className="ml-auto text-[#d1d4dc]">●</span>}
          </DropdownMenuItem>
          <DropdownMenuItem
            onClick={() => requestDockPanel('quant')}
            disabled={dockPanelIds.includes('quant')}
            className="gap-2 text-[11px] data-[highlighted]:bg-[#27272a] data-[disabled]:opacity-50"
          >
            <Sigma className="h-3.5 w-3.5" />
            Quant · GEX
            {dockPanelIds.includes('quant') && <span className="ml-auto text-[#d1d4dc]">●</span>}
          </DropdownMenuItem>
          <DropdownMenuSeparator className="bg-[#27272a]" />
          <DropdownMenuItem
            onClick={requestDockReset}
            className="gap-2 text-[11px] data-[highlighted]:bg-[#27272a]"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            Redefinir layout
            <span className="ml-auto text-[9px] text-[#5d606b]">arraste abas p/ anexar</span>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* workspace (decorativo) — icon-only */}
      <div className="hidden shrink-0 items-center gap-0.5 md:flex">
        <Hint label="Workspace 1 · em breve">
          <button
            type="button"
            aria-label="Workspace 1"
            aria-pressed={true}
            className="flex h-7 w-7 items-center justify-center rounded bg-[#27272a] text-[#e8e8ea] shadow-[inset_0_-2px_0_0_#4682b4]"
          >
            <LayoutGrid className="h-3.5 w-3.5" aria-hidden="true" />
          </button>
        </Hint>
        <Hint label="Novo workspace em breve">
          <button
            type="button"
            aria-label="Novo workspace"
            className="flex h-7 w-7 items-center justify-center rounded text-[#787b86] hover:bg-[#222226] hover:text-[#d1d4dc]"
          >
            <Plus className="h-3.5 w-3.5" aria-hidden="true" />
          </button>
        </Hint>
      </div>

      {/* MODO FOCO: colapsa DOM/Tape/Quant (setVisible — sem desmontar) */}
      <Hint
        label={
          focusMode
            ? 'Sair do modo foco (restaurar painéis) · F'
            : 'Modo foco: gráfico em tela cheia (oculta DOM/Tape/Quant) · F'
        }
      >
        <button
          type="button"
          aria-label={focusMode ? 'Sair do modo foco' : 'Ativar modo foco'}
          aria-pressed={focusMode}
          onClick={() => setFocusMode(!focusMode)}
          className={`flex h-7 w-7 shrink-0 items-center justify-center rounded transition-colors ${
            focusMode
              ? 'bg-[#27272a] text-[#e8e8ea] shadow-[inset_0_-2px_0_0_#4682b4]'
              : 'bg-[#222226] text-[#d1d4dc] hover:bg-[#27272a]'
          }`}
        >
          <Focus className="h-3.5 w-3.5" aria-hidden="true" />
        </button>
      </Hint>

      <div className="min-w-0 flex-1" />

      {/* download do código-fonte (sempre visível) */}
      <Hint label="Baixar código-fonte (.zip) para instalação local">
        <button
          type="button"
          onClick={() => setDialog('download')}
          aria-label="Baixar código-fonte (.zip)"
          className="flex h-7 shrink-0 items-center gap-1.5 rounded bg-[#3f3f46] px-2 text-[11px] font-medium text-white transition-colors hover:bg-[#52525b]"
        >
          <Download className="h-3.5 w-3.5" aria-hidden="true" />
          <span className="hidden sm:inline">Código .zip</span>
          <span className="sm:hidden">.zip</span>
        </button>
      </Hint>

      {/* conexão */}
      <div className="flex h-7 shrink-0 items-center gap-1.5 rounded bg-[#222226] px-2">
        <span
          className="h-1.5 w-1.5 shrink-0 rounded-full"
          style={{ backgroundColor: meta.dot }}
        />
        <span className="max-w-[130px] truncate text-[10px] uppercase tracking-wide text-[#787b86] sm:max-w-none">
          {meta.label}
        </span>
      </div>

      {/* idioma (decorativo) */}
      <Hint label="Idioma em breve">
        <button
          type="button"
          className="hidden h-7 shrink-0 items-center rounded bg-[#222226] px-2 text-[11px] text-[#d1d4dc] hover:bg-[#27272a] sm:flex"
        >
          PT
        </button>
      </Hint>

      {/* versão completa (decorativo) */}
      <Hint label="Versão completa em breve">
        <button
          type="button"
          className="hidden h-7 shrink-0 items-center rounded bg-[#3f3f46] px-2.5 text-[11px] font-medium text-white hover:bg-[#52525b] md:flex"
        >
          Versão completa
        </button>
      </Hint>

      {/* entrar (decorativo) */}
      <Hint label="Login em breve">
        <button
          type="button"
          className="hidden h-7 shrink-0 items-center rounded px-2.5 text-[11px] text-[#d1d4dc] hover:bg-[#222226] lg:flex"
        >
          Entrar
        </button>
      </Hint>
    </header>
  );
});
