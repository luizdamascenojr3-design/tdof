// ─────────────────────────────────────────────────────────────────────────────
// Store de desenhos do gráfico (ferramentas estilo ATAS).
// Coordenadas em espaço de DADOS: { i: índice da barra, p: preço } — pan/zoom
// preservam os desenhos. Chave = `${symbol}|${tf}`; trocar símbolo/TF mostra
// outro conjunto. Persistência em localStorage (best effort).
// ─────────────────────────────────────────────────────────────────────────────

import { create } from 'zustand';

export type DrawKind =
  | 'trend'
  | 'hline'
  | 'hray'
  | 'vline'
  | 'rect'
  | 'ellipse'
  | 'triangle'
  | 'arrow'
  | 'fib'
  | 'fibext'
  | 'rrisk'
  | 'vprof'
  | 'ruler'
  | 'text'
  | 'range'
  | 'mlevel';

/** Ferramentas que efetivamente desenham no canvas. */
export const DRAW_TOOLS: DrawKind[] = [
  'trend',
  'hline',
  'hray',
  'vline',
  'rect',
  'ellipse',
  'triangle',
  'arrow',
  'fib',
  'fibext',
  'rrisk',
  'vprof',
  'ruler',
  'text',
  'range',
  'mlevel',
];

/** Ponto-âncora em espaço de dados (índice da barra + preço). */
export interface DrawPt {
  i: number;
  p: number;
}

export interface DrawObj {
  id: string;
  kind: DrawKind;
  /** 1 ponto (hline/vline/text) ou 2 pontos (demais) */
  pts: DrawPt[];
  /** texto do tool "Texto" */
  text?: string;
  /** range/mlevel/vprof: estende o canal/níveis/perfil até a borda direita do gráfico */
  extend?: boolean;
  /** mlevel: nº de níveis equidistantes para cada lado (default 3) */
  levels?: number;
  /**
   * rrisk (Risco/Retorno): direção da projeção. Default inferido do sinal de
   * b−a (b abaixo de a = stop abaixo do preço = long). 'long' projeta alvos
   * ACIMA da entrada; 'short' projeta ABAIXO.
   */
  dir?: 'long' | 'short';
  /** rrisk: múltiplo de risco do alvo destacado (default 2 → 1:2) */
  rr?: number;
}

/** Handles de manipulação de um desenho (hit-test → drag). */
export type DrawHandle = 'a' | 'b' | 'body';

interface DrawingState {
  /** ferramenta ativa (crosshair = navegação/pan normal) */
  tool: 'crosshair' | DrawKind;
  /** desenhos por chave symbol|tf */
  items: Record<string, DrawObj[]>;
  setTool: (t: DrawingState['tool']) => void;
  /** confirma um desenho na chave atual */
  add: (key: string, obj: DrawObj) => void;
  /**
   * Manipulação (drag): substitui os pontos de um objeto existente.
   * Chamado no pointerup (commit único) — durante o arrasto o canvas usa os
   * pontos locais do drag (ref) e redesenha via rAF, sem tocar no store.
   */
  update: (key: string, id: string, pts: DrawPt[]) => void;
  /** remove o último desenhado da chave */
  undo: (key: string) => void;
  /** apaga todos os desenhos da chave */
  clear: (key: string) => void;
  /** versão (incrementada a cada mutação de items — útil p/ redraw) */
  version: number;
}

const LS_KEY = 'flowterminal.drawings.v1';

function loadPersisted(): Record<string, DrawObj[]> {
  if (typeof window === 'undefined') return {};
  try {
    const raw = window.localStorage.getItem(LS_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as Record<string, DrawObj[]>;
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

function persist(items: Record<string, DrawObj[]>) {
  try {
    window.localStorage.setItem(LS_KEY, JSON.stringify(items));
  } catch {
    /* quota/SSR — best effort */
  }
}

/**
 * O store nasce com `items` VAZIO em servidor E cliente: ler localStorage
 * aqui (na criação do módulo) fazia o 1º render do cliente divergir do SSR
 * (badge de contagem da toolbar) → erro de hidratação. A leitura do storage
 * agora é explícita e pós-montagem via `hydrateDrawings()`.
 */
export const useDrawingStore = create<DrawingState>((set, get) => {
  return {
    tool: 'crosshair',
    items: {},
    version: 0,

    setTool: (tool) => set({ tool }),

    add: (key, obj) => {
      const items = { ...get().items };
      const list = items[key] ? items[key].slice() : [];
      list.push(obj);
      items[key] = list;
      persist(items);
      set({ items, version: get().version + 1 });
    },

    update: (key, id, pts) => {
      const list = get().items[key];
      if (!list) return;
      const idx = list.findIndex((o) => o.id === id);
      if (idx === -1) return;
      const next = list.slice();
      next[idx] = { ...next[idx], pts };
      const items = { ...get().items, [key]: next };
      persist(items);
      set({ items, version: get().version + 1 });
    },

    undo: (key) => {
      const cur = get().items[key];
      if (!cur || cur.length === 0) return;
      const items = { ...get().items, [key]: cur.slice(0, -1) };
      persist(items);
      set({ items, version: get().version + 1 });
    },

    clear: (key) => {
      if (!get().items[key]) return;
      const items = { ...get().items, [key]: [] };
      persist(items);
      set({ items, version: get().version + 1 });
    },
  };
});

/**
 * Carrega os desenhos persistidos APÓS a montagem (chamar dentro de
 * `useEffect`). Rodando pós-hidratação, o localStorage nunca participa do
 * 1º render — sem divergência SSR/cliente. Incrementa `version` p/ o canvas
 * redesenhar com os objetos carregados (subscribe no cluster-chart).
 */
export function hydrateDrawings(): void {
  if (typeof window === 'undefined') return;
  const persisted = loadPersisted();
  if (Object.keys(persisted).length === 0) return;
  useDrawingStore.setState({
    items: persisted,
    version: useDrawingStore.getState().version + 1,
  });
}

/** Número de desenhos da chave (p/ badge da toolbar). */
export function drawingCount(items: Record<string, DrawObj[]>, key: string): number {
  return items[key]?.length ?? 0;
}

// ── Geometria de manipulação (motor de desenhos) ─────────────────────────────
// Hit-test em ESPAÇO DE DADOS (índice da barra + preço), executado apenas no
// pointerdown e no pointermove durante o drag — custo O(n) sobre poucos
// objetos, fora do caminho do render (rAF mantém o desenho sem bloqueios).

/** Tolerância de hit em unidades de dados (barras × preço em ticks). */
const HIT_TOL_I = 0.6;
const HIT_TOL_P_TICKS = 4;

/** Kinds que o hit-test manipula (render base de geometria customizada). */
const HIT_KINDS: ReadonlySet<DrawKind> = new Set([
  'hline', 'hray', 'vline', 'trend', 'arrow', 'rect', 'ellipse',
  'triangle', 'fib', 'fibext', 'rrisk', 'vprof', 'range', 'mlevel',
]);

/** Mapa de um ponto de tela (espaço de dados) para as âncoras do objeto. */
export function hitTestDraw(
  obj: DrawObj,
  pt: DrawPt,
  tick: number,
): DrawHandle | null {
  if (!HIT_KINDS.has(obj.kind)) return null;
  const a = obj.pts[0];
  const b = obj.pts[1];
  const tolP = HIT_TOL_P_TICKS * tick;
  const nearP = (p1: number, p2: number) => Math.abs(p1 - p2) <= tolP;
  const nearI = (i1: number, i2: number) => Math.abs(i1 - i2) <= HIT_TOL_I;

  // âncoras primeiro (prioridade sobre o corpo)
  if (a) {
    if (obj.kind === 'hline' || obj.kind === 'hray') {
      if (nearP(pt.p, a.p)) return 'a';
    } else if (obj.kind === 'vline') {
      if (nearI(pt.i, a.i)) return 'a';
    } else if (
      (a && b && ((nearP(pt.p, a.p) && nearI(pt.i, a.i)) ||
        (nearP(pt.p, b.p) && nearI(pt.i, b.i))))
    ) {
      return nearP(pt.p, a.p) && nearI(pt.i, a.i) ? 'a' : 'b';
    }
  }
  if (!a) return null;

  switch (obj.kind) {
    case 'hline':
    case 'hray':
      return nearP(pt.p, a.p) ? 'body' : null;
    case 'vline':
      return nearI(pt.i, a.i) ? 'body' : null;
    case 'range': {
      // corpo = faixa entre os dois preços (qualquer índice)
      if (!b) return null;
      const lo = Math.min(a.p, b.p);
      const hi = Math.max(a.p, b.p);
      return pt.p >= lo - tolP && pt.p <= hi + tolP ? 'body' : null;
    }
    case 'mlevel': {
      // corpo = qualquer nível equidistante (±tol do passo)
      if (!b) return null;
      const step = Math.abs(b.p - a.p);
      if (step <= 0) return null;
      const k = (pt.p - a.p) / step;
      const near = Math.abs(k - Math.round(k)) * step <= tolP;
      return near ? 'body' : null;
    }
    case 'rect': {
      if (!b) return null;
      const iLo = Math.min(a.i, b.i);
      const iHi = Math.max(a.i, b.i);
      const pLo = Math.min(a.p, b.p);
      const pHi = Math.max(a.p, b.p);
      return pt.i >= iLo && pt.i <= iHi && pt.p >= pLo && pt.p <= pHi ? 'body' : null;
    }
    case 'vprof': {
      // corpo = retângulo do range fixo (perfil desenhado dentro dele)
      if (!b) return null;
      const iLo = Math.min(a.i, b.i);
      const iHi = Math.max(a.i, b.i);
      const pLo = Math.min(a.p, b.p);
      const pHi = Math.max(a.p, b.p);
      return pt.i >= iLo - HIT_TOL_I && pt.i <= iHi + HIT_TOL_I && pt.p >= pLo && pt.p <= pHi
        ? 'body'
        : null;
    }
    case 'rrisk': {
      // corpo = zona de risco (entrada ↔ stop), qualquer índice (projeção)
      if (!b) return null;
      const pLo = Math.min(a.p, b.p);
      const pHi = Math.max(a.p, b.p);
      return pt.p >= pLo - tolP && pt.p <= pHi + tolP ? 'body' : null;
    }
    case 'trend':
    case 'arrow':
    case 'fib':
    case 'fibext': {
      if (!b) return null;
      // corpo = segmento a→b com tolerância (distância ponto-reta aproximada)
      const di = b.i - a.i;
      const dp = b.p - a.p;
      const len2 = di * di + (dp / tick) * (dp / tick);
      if (len2 === 0) return null;
      const t =
        ((pt.i - a.i) * di + ((pt.p - a.p) / tick) * (dp / tick)) / len2;
      if (t < 0 || t > 1) return null;
      const pi = a.i + t * di;
      const pp = a.p + t * dp;
      return nearI(pt.i, pi) && nearP(pt.p, pp) ? 'body' : null;
    }
    default:
      return null;
  }
}

/**
 * Move um desenho durante o drag: `handle` define âncora arrastada; `body`
 * translada o objeto inteiro. `pt` = cursor em espaço de dados; `orig` =
 * pontos originais (no início do drag). Retorna os novos pontos.
 */
export function moveDraw(
  obj: DrawObj,
  handle: DrawHandle,
  orig: DrawPt[],
  pt: DrawPt,
): DrawPt[] {
  const a = orig[0];
  const b = orig[1];
  const clampI = (i: number) => Math.max(0, i);
  const clampP = (p: number) => Math.max(tickPriceFloor(obj), p);

  switch (obj.kind) {
    case 'hline':
    case 'hray':
      return [{ i: 0, p: pt.p }];
    case 'vline':
      return [{ i: clampI(pt.i), p: 0 }];
    case 'range': {
      if (!a || !b) return orig;
      if (handle === 'a') return [{ ...pt }, b];
      if (handle === 'b') return [a, { ...pt }];
      // body: translada os dois preços (índices preservados — canal horizontal)
      const dp = pt.p - ((a.p + b.p) / 2);
      return [
        { i: a.i, p: a.p + dp },
        { i: b.i, p: b.p + dp },
      ];
    }
    case 'rrisk': {
      // body: translada entrada+stop juntos (índices preservados — zonas horizontais)
      if (!a || !b) return orig;
      if (handle === 'a') return [{ i: a.i, p: pt.p }, b];
      if (handle === 'b') return [a, { i: b.i, p: pt.p }];
      const dp = pt.p - a.p;
      return [
        { i: a.i, p: a.p + dp },
        { i: b.i, p: b.p + dp },
      ];
    }
    case 'vprof': {
      // body: translada o range inteiro (temporal + preço)
      if (!a || !b) return orig;
      const di = clampI(pt.i) - clampI(a.i);
      const dp = pt.p - a.p;
      return [
        { i: clampI(a.i + di), p: clampP(a.p + dp) },
        { i: clampI(b.i + di), p: clampP(b.p + dp) },
      ];
    }
    case 'mlevel': {
      if (!a || !b) return orig;
      if (handle === 'a') return [{ i: a.i, p: pt.p }, b];
      if (handle === 'b') {
        // handle b = passo: mantém a âncora, move só o segundo nível
        return [a, { i: pt.i, p: pt.p }];
      }
      const dp = pt.p - a.p;
      return [
        { i: a.i, p: a.p + dp },
        { i: b.i, p: b.p + dp },
      ];
    }
    default: {
      // 2 pontos genéricos: âncora move o ponto; corpo translada ambos
      if (!a || !b) return orig;
      if (handle === 'a') return [{ ...pt, i: clampI(pt.i) }, b];
      if (handle === 'b') return [a, { ...pt, i: clampI(pt.i) }];
      const di = clampI(pt.i) - clampI(a.i);
      const dp = pt.p - a.p;
      return [
        { i: clampI(a.i + di), p: clampP(a.p + dp) },
        { i: clampI(b.i + di), p: clampP(b.p + dp) },
      ];
    }
  }
}

/** piso de preço p/ clamps (evita níveis negativos no drag) */
function tickPriceFloor(_obj: DrawObj): number {
  return 0;
}
