// ─────────────────────────────────────────────────────────────────────────────
// Construtor de barras NÃO-temporais (estilo ATAS): Range, Reversão, Tick e
// Volume. A partir das velas do timeframe (com clusters por nível), percorre o
// caminho de preço O→L→H→C (ou O→H→L→C) e fecha barras conforme o critério:
//
//   range    : (máx−mín) da barra ≥ param ticks
//   reversal : recuo de param ticks a partir do extremo na direção da barra
//   tick     : param negócios na barra
//   volume   : param de volume na barra
//
// Volumes/delta/negócios são distribuídos por etapa do caminho e os níveis
// (clusters) redistribuídos por preço, preservando o footprint.
// ─────────────────────────────────────────────────────────────────────────────

import { TF_MS, type Candle, type Timeframe } from './types';

export type BarType = 'time' | 'range' | 'reversal' | 'tick' | 'volume';

type Level = { a: number; b: number };

/** Barra em construção (mesma forma de Candle + direção p/ reversão). */
interface WalkBar {
  t: number;
  o: number;
  h: number;
  l: number;
  c: number;
  v: number;
  d: number;
  n: number;
  lv: Record<number, Level>;
  /** direção: 1 subindo, −1 caindo, 0 indefinida */
  dir: 1 | -1 | 0;
}

function freshBar(price: number, t: number): WalkBar {
  return { t, o: price, h: price, l: price, c: price, v: 0, d: 0, n: 0, lv: {}, dir: 0 };
}

function cloneOpen(bar: WalkBar | null): WalkBar | null {
  if (!bar) return null;
  const lv: Record<number, Level> = {};
  for (const k in bar.lv) lv[k] = { a: bar.lv[k].a, b: bar.lv[k].b };
  return { ...bar, lv };
}

/** assinatura barata de uma vela p/ memoização incremental. */
function sig(c: Candle | undefined): string {
  if (!c) return '';
  return `${c.t}|${c.o}|${c.h}|${c.l}|${c.c}|${c.v}|${c.n}`;
}

function step(
  bar: WalkBar,
  idx: number,
  price: number,
  a: number,
  b: number,
  v: number,
  n: number,
  t: number,
) {
  bar.t = t;
  bar.c = price;
  if (price > bar.h) bar.h = price;
  if (price < bar.l) bar.l = price;
  bar.v += v;
  bar.d += a - b;
  bar.n += n;
  if (bar.dir === 0 && price > bar.o) bar.dir = 1;
  else if (bar.dir === 0 && price < bar.o) bar.dir = -1;
  const cur = bar.lv[idx];
  if (cur) {
    cur.a += a;
    cur.b += b;
  } else {
    bar.lv[idx] = { a, b };
  }
}

/**
 * Percorre uma vela do timeframe e emite barras FECHADAS em `bars`;
 * devolve a barra em construção (aberta) para continuidade entre velas.
 */
function walkCandle(
  c: Candle,
  bars: Candle[],
  type: Exclude<BarType, 'time'>,
  param: number,
  tick: number,
  tfMs: number,
  open: WalkBar | null,
): WalkBar {
  // caminho de preço em passos de 1 tick (convenção clássica)
  const legs = c.c >= c.o ? [c.o, c.l, c.h, c.c] : [c.o, c.h, c.l, c.c];
  const steps: number[] = [];
  for (let i = 0; i < legs.length - 1; i++) {
    const from = legs[i];
    const to = legs[i + 1];
    const dist = Math.round(Math.abs(to - from) / tick);
    const dir = Math.sign(to - from);
    const start = Math.round(from / tick);
    for (let s = 1; s <= dist; s++) steps.push(start + dir * s);
  }
  // doji total: um passo parado no preço
  if (steps.length === 0) steps.push(Math.round(c.o / tick));

  const S = steps.length;
  const vStep = c.v / S;
  const nStep = c.n / S;
  const tStep = tfMs / S;

  // quantos passos caem em cada tick index (p/ ratear os níveis)
  const stepsAt = new Map<number, number>();
  for (const idx of steps) stepsAt.set(idx, (stepsAt.get(idx) ?? 0) + 1);

  let bar: WalkBar = open ?? freshBar(steps[0] * tick, c.t);

  for (let i = 0; i < S; i++) {
    const idx = steps[i];
    const price = idx * tick;
    const share = stepsAt.get(idx) ?? 1;
    const lvl = c.lv[idx];
    const a = lvl ? lvl.a / share : 0;
    const b = lvl ? lvl.b / share : 0;
    const t = c.t + i * tStep;
    step(bar, idx, price, a, b, vStep, nStep, t);

    const closed =
      (type === 'range' && bar.h - bar.l >= param * tick) ||
      (type === 'tick' && bar.n >= param) ||
      (type === 'volume' && bar.v >= param) ||
      (type === 'reversal' &&
        bar.dir !== 0 &&
        (bar.dir === 1 ? bar.h - bar.c >= param * tick : bar.c - bar.l >= param * tick));

    if (closed) {
      bars.push(bar as Candle);
      bar = freshBar(price, t);
    }
  }
  return bar;
}

// ── memoização incremental (a cada trade só a última vela muda) ─────────────
let cacheKey = '';
let cacheBars: Candle[] = [];
let cacheOpen: WalkBar | null = null;

/**
 * Constrói barras do tipo escolhido a partir das velas do timeframe.
 * Memoizado: o cabeçalho (velas 0..N-2) só é reconstruído quando muda; a
 * última vela (que muda a cada trade) é reprocessada sozinha sobre uma cópia
 * da barra aberta — objetos do cache nunca são mutados.
 */
export function buildBars(
  candles: Candle[],
  type: BarType,
  param: number,
  tick: number,
  tf: Timeframe,
): Candle[] {
  if (type === 'time') return candles;
  if (candles.length === 0) return [];
  const tfMs = TF_MS[tf];
  const t = type as Exclude<BarType, 'time'>;
  const p = Math.max(1, param);

  const N = candles.length;
  const key = `${sig(candles[N - 2])}|${N - 1}|${t}|${p}|${tick}`;
  if (key !== cacheKey) {
    const bars: Candle[] = [];
    let open: WalkBar | null = null;
    for (let i = 0; i < N - 1; i++) {
      open = walkCandle(candles[i], bars, t, p, tick, tfMs, open);
    }
    cacheKey = key;
    cacheBars = bars;
    cacheOpen = open;
  }

  const bars = cacheBars.slice();
  const tail = walkCandle(candles[N - 1], bars, t, p, tick, tfMs, cloneOpen(cacheOpen));
  if (tail.v > 0 || tail.n > 0) bars.push(tail as Candle);
  return bars;
}

// ── agregação de timeframe (cliente) ─────────────────────────────────────────
// Multi-chart: painéis com tf pinado MAIOR que o do stream derivam as velas
// localmente (ex.: stream 1m → M5 local). Não há nova subscrição de socket;
// a derivação é memoizada por (t inicial, tf alvo).

let aggKey = '';
let aggCache: Candle[] = [];

/** Combina velas consecutivas em buckets do tf alvo (merge OHLCV + níveis). */
export function aggregateCandles(
  candles: Candle[],
  fromTf: Timeframe,
  toTf: Timeframe,
): Candle[] {
  if (toTf === fromTf) return candles;
  const fromMs = TF_MS[fromTf];
  const toMs = TF_MS[toTf];
  const ratio = toMs / fromMs;
  // só agregamos para CIMA (inteiros): tf menor não é derivável localmente
  if (!Number.isFinite(ratio) || ratio < 1 || !Number.isInteger(ratio)) return candles;
  const k = Math.round(ratio);
  if (candles.length === 0) return candles;

  // invalidação barata: t do primeiro + tamanho + tf (cabeça é estável)
  const key = `${candles.length}|${candles[0]?.t ?? 0}|${fromTf}|${toTf}`;
  if (key !== aggKey) {
    const out: Candle[] = [];
    let cur: Candle | null = null;
    let curBucket = -1;
    for (const c of candles) {
      const bucket = Math.floor(c.t / toMs);
      if (!cur || bucket !== curBucket) {
        if (cur) out.push(cur);
        curBucket = bucket;
        cur = { ...c, t: bucket * toMs, lv: { ...c.lv } };
      } else {
        cur.h = Math.max(cur.h, c.h);
        cur.l = Math.min(cur.l, c.l);
        cur.c = c.c;
        cur.v += c.v;
        cur.d += c.d;
        cur.n += c.n;
        // níveis: somatório de agressões por tick (mesma semântica da vela)
        for (const idx in c.lv) {
          const i = Number(idx);
          const add = c.lv[i];
          if (!add) continue;
          const dst = cur.lv[i] ?? { b: 0, a: 0 };
          dst.b += add.b;
          dst.a += add.a;
          cur.lv[i] = dst;
        }
      }
    }
    if (cur) out.push(cur);
    aggKey = key;
    aggCache = out;
  }
  return aggCache;
}
