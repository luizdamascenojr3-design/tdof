// ─────────────────────────────────────────────────────────────────────────────
// Codec binário estilo FlatBuffers para o delta do order book (MBO) em tempo
// real. Objetivo: zero-copy na leitura (DataView sobre o ArrayBuffer bruto,
// sem desserialização de objetos) e payload mínimo no WebSocket.
//
// Frame (little-endian):
// ┌ off  size  campo ────────────────────────────────────────────────────────┐
// │  0    4    magic u32 = 0x314F424D ('MBO1')                              │
// │  4    1    version u8 = 1                                               │
// │  5    1    flags u8  (bit0 = full snapshot, 0 = delta)                   │
// │  6    2    symbolId u16 (índice em SYMBOL_CONFIGS)                       │
// │  8    4    seq u32 (monotônico por símbolo)                              │
// │ 12    8    serverTime f64 (ms)                                           │
// │ 20    4    bestBidIdx i32 (tick index do melhor bid)                     │
// │ 24    4    bestAskIdx i32 (tick index do melhor ask)                     │
// │ 28    8    cvd f64 (delta acumulado da sessão)                           │
// │ 36    4    lastPriceIdx i32                                              │
// │ 40    2    nTrades u16                                                   │
// │ 42    2    nDeltas u16                                                   │
// │ 44    4    reserved u32 (zero)                                           │
// │ 48   24×N  trades: [f64 t, i32 p, f32 s, u8 side, u8 big, u16pad u32pad] │
// │      12×M  deltas: [i32 idx, u8 side, u8 op, u16pad, f32 qty]           │
// └──────────────────────────────────────────────────────────────────────────┘
// op: 0 = upsert (semântica de máximo visto no bucket), 1 = delete.
// side: 0 = bid, 1 = ask. side do trade: 0 = venda (agressão no bid), 1 = compra.
//
// Fonte de verdade para o cliente; réplica em mini-services/market-data/flatbuf.ts.
// Alterações no contrato devem ser replicadas lá.
// ─────────────────────────────────────────────────────────────────────────────

export const MBO_MAGIC = 0x314f424d;
export const MBO_VERSION = 1;
/** tamanho do cabeçalho fixo */
export const MBO_HEADER = 48;
export const MBO_TRADE_STRIDE = 24;
export const MBO_DELTA_STRIDE = 12;

export const MBO_OP_UPSERT = 0;
export const MBO_OP_DELETE = 1;

/** Mensagem do evento `terminal:mbo` (payload binário). */
export interface MboFrameMeta {
  full: boolean;
  symbolId: number;
  seq: number;
  serverTime: number;
  bestBidIdx: number;
  bestAskIdx: number;
  cvd: number;
  lastPriceIdx: number;
  nTrades: number;
  nDeltas: number;
}

/**
 * Visor zero-copy de um frame MBO: nenhum campo é materializado até ser lido.
 * Instancie uma vez por frame e leia trades/deltas via os acessores numéricos.
 */
export class MboFrameView {
  private dv: DataView;
  private base: number;

  constructor(buf: ArrayBuffer | Uint8Array) {
    const ab = buf instanceof ArrayBuffer ? buf : buf.buffer;
    this.dv = new DataView(ab);
    this.base = 0;
  }

  /** Frame com magic/version válidos. */
  get valid(): boolean {
    try {
      return this.dv.getUint32(0, true) === MBO_MAGIC && this.dv.getUint8(4) === MBO_VERSION;
    } catch {
      return false;
    }
  }

  get flags(): number {
    return this.dv.getUint8(5);
  }
  /** true = snapshot completo (todos os níveis), false = delta incremental. */
  get full(): boolean {
    return (this.flags & 1) !== 0;
  }
  get symbolId(): number {
    return this.dv.getUint16(6, true);
  }
  get seq(): number {
    return this.dv.getUint32(8, true);
  }
  get serverTime(): number {
    return this.dv.getFloat64(12, true);
  }
  get bestBidIdx(): number {
    return this.dv.getInt32(20, true);
  }
  get bestAskIdx(): number {
    return this.dv.getInt32(24, true);
  }
  get cvd(): number {
    return this.dv.getFloat64(28, true);
  }
  get lastPriceIdx(): number {
    return this.dv.getInt32(36, true);
  }
  get nTrades(): number {
    return this.dv.getUint16(40, true);
  }
  get nDeltas(): number {
    return this.dv.getUint16(42, true);
  }

  // ── trades (offset 48, stride 24) ──────────────────────────────────────────
  private tradeOff(i: number): number {
    return MBO_HEADER + i * MBO_TRADE_STRIDE;
  }
  tradeT(i: number): number {
    return this.dv.getFloat64(this.tradeOff(i), true);
  }
  tradeP(i: number): number {
    return this.dv.getInt32(this.tradeOff(i) + 8, true);
  }
  tradeS(i: number): number {
    return this.dv.getFloat32(this.tradeOff(i) + 12, true);
  }
  /** 0 = venda (agressão no bid), 1 = compra (agressão no ask) */
  tradeSide(i: number): number {
    return this.dv.getUint8(this.tradeOff(i) + 16);
  }
  tradeBig(i: number): boolean {
    return this.dv.getUint8(this.tradeOff(i) + 17) !== 0;
  }

  // ── deltas de book (após os trades, stride 12) ─────────────────────────────
  private deltaOff(i: number): number {
    return MBO_HEADER + this.nTrades * MBO_TRADE_STRIDE + i * MBO_DELTA_STRIDE;
  }
  deltaIdx(i: number): number {
    return this.dv.getInt32(this.deltaOff(i), true);
  }
  /** 0 = bid, 1 = ask */
  deltaSide(i: number): number {
    return this.dv.getUint8(this.deltaOff(i) + 4);
  }
  /** 0 = upsert (máximo visto), 1 = delete */
  deltaOp(i: number): number {
    return this.dv.getUint8(this.deltaOff(i) + 5);
  }
  deltaQty(i: number): number {
    return this.dv.getFloat32(this.deltaOff(i) + 8, true);
  }
}

/** Input do encoder (usado pelo mini-serviço). */
export interface MboTradeInput {
  t: number;
  /** tick index */
  p: number;
  s: number;
  /** 'buy' = agressão no ask, 'sell' = agressão no bid */
  side: 'buy' | 'sell';
  big?: boolean;
}
export interface MboDeltaInput {
  idx: number;
  side: 0 | 1;
  op: 0 | 1;
  qty: number;
}

/** Tamanho total do frame para nTrades/nDeltas. */
export function mboFrameSize(nTrades: number, nDeltas: number): number {
  return MBO_HEADER + nTrades * MBO_TRADE_STRIDE + nDeltas * MBO_DELTA_STRIDE;
}

/**
 * Codifica um frame MBO num ArrayBuffer novo (encoder do mini-serviço).
 * Campos reservados ficam zerados; trades e deltas são gravados em sequência.
 */
export function encodeMboFrame(
  meta: {
    full: boolean;
    symbolId: number;
    seq: number;
    serverTime: number;
    bestBidIdx: number;
    bestAskIdx: number;
    cvd: number;
    lastPriceIdx: number;
  },
  trades: MboTradeInput[],
  deltas: MboDeltaInput[],
): ArrayBuffer {
  const buf = new ArrayBuffer(mboFrameSize(trades.length, deltas.length));
  const dv = new DataView(buf);
  dv.setUint32(0, MBO_MAGIC, true);
  dv.setUint8(4, MBO_VERSION);
  dv.setUint8(5, meta.full ? 1 : 0);
  dv.setUint16(6, meta.symbolId & 0xffff, true);
  dv.setUint32(8, meta.seq >>> 0, true);
  dv.setFloat64(12, meta.serverTime, true);
  dv.setInt32(20, meta.bestBidIdx | 0, true);
  dv.setInt32(24, meta.bestAskIdx | 0, true);
  dv.setFloat64(28, meta.cvd, true);
  dv.setInt32(36, meta.lastPriceIdx | 0, true);
  dv.setUint16(40, trades.length & 0xffff, true);
  dv.setUint16(42, deltas.length & 0xffff, true);

  let off = MBO_HEADER;
  for (const tr of trades) {
    dv.setFloat64(off, tr.t, true);
    dv.setInt32(off + 8, tr.p | 0, true);
    dv.setFloat32(off + 12, tr.s, true);
    dv.setUint8(off + 16, tr.side === 'buy' ? 1 : 0);
    dv.setUint8(off + 17, tr.big ? 1 : 0);
    off += MBO_TRADE_STRIDE;
  }
  for (const d of deltas) {
    dv.setInt32(off, d.idx | 0, true);
    dv.setUint8(off + 4, d.side);
    dv.setUint8(off + 5, d.op);
    dv.setFloat32(off + 8, d.qty, true);
    off += MBO_DELTA_STRIDE;
  }
  return buf;
}
