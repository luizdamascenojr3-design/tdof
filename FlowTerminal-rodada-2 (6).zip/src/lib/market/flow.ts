// ─────────────────────────────────────────────────────────────────────────────
// Contratos do motor de fluxo MBO (rodada 5): sinais de order flow
// (absorção / exaustão / iceberg), anel de heatmap empacotado p/ WebGL e
// estatísticas do stream binário.
// ─────────────────────────────────────────────────────────────────────────────

/** Tipos de divergência detectados pelo rastreador (base ATAS X / MMT). */
export type FlowSignalKind =
  /** agressão travada por limite passivo: volume entra e o preço não anda */
  | 'absorption'
  /** aceleração do CVD sem progresso de preço — agressão se esgotando */
  | 'exhaustion'
  /** nível que se auto-reabastece sob fogo contínuo (ordem oculta) */
  | 'iceberg'
  /** liquidez grande perto do BBO cancelada sem execução relevante (trap) */
  | 'spoof';

/**
 * Sinal de fluxo emitido pelo worker MBO.
 * `side` = lado da agressão travada/oculta ('buy' = compradores sendo
 * absorvidos no ask, 'sell' = vendedores sendo absorvidos no bid).
 */
export interface FlowSignal {
  id: number;
  /** timestamp do evento (ms) */
  t: number;
  kind: FlowSignalKind;
  side: 'buy' | 'sell';
  /** tick index do nível onde ocorreu */
  priceIdx: number;
  /** volume negociado durante o evento */
  vol: number;
  /** 0..1 (normalizado pela liquidez típica do símbolo) */
  strength: number;
  /** ms em que o sinal expira para renderização (TTL) */
  until: number;
}

/**
 * Anel de heatmap de liquidez empacotado (colunas temporais × linhas de preço),
 * transferido do WebWorker para o renderer WebGL.
 * Célula (col c, row r, side s) → data[(c * rows + r) * 4 + (s === 'bid' ? 1 : 0)]
 * = fração q/maxQ quantizada em 8 bits (layout RGBA8 pronto p/ textura GL;
 * canal R = ask, G = bid). Row 0 = tick index `colBase`. Coluna 0 = t `firstT`
 * (ms), cada coluna dura `tfMs`.
 */
export interface HeatRingPayload {
  cols: number;
  rows: number;
  colBase: number;
  firstT: number;
  tfMs: number;
  /** maior quantidade viva no anel (normalização dos bytes) */
  maxQ: number;
  data: Uint8Array;
  version: number;
}

// ── DOM MBO Nível 3 (pulling/stacking por nível) ─────────────────────────────

/**
 * Acúmulo de cancelamento/adição de liquidez de um nível de preço (EMA sobre
 * os deltas do book — janela efetiva de ~3s, publicada a cada 500ms).
 * `pull` = volume cancelado; `stack` = volume adicionado; `pulls`/`stacks` =
 * nº de eventos correspondentes.
 */
export interface DomL3Row {
  /** tick index do nível */
  idx: number;
  pull: number;
  stack: number;
  pulls: number;
  stacks: number;
}

/** Snapshot do rastreamento pulling/stacking próximo ao BBO. */
export interface DomL3Snapshot {
  /** ms do servidor no momento da publicação */
  t: number;
  /** linhas ordenadas por idx, dentro de ±16 ticks do BBO */
  rows: DomL3Row[];
}

/** Estatísticas do stream MBO binário (exibidas na status bar). */
export interface MboStats {
  /** delta acumulado (worker) */
  cvd: number;
  /** inclinação do CVD (contratos/s) */
  cvdSlope: number;
  /** ms desde a última mudança do BBO (inércia do limit order book) */
  bboInertiaMs: number;
  /** negócios por segundo (janela ~5s) */
  tradesPerSec: number;
  /** frames binários recebidos */
  frames: number;
  /** bytes acumulados do stream binário */
  frameBytes: number;
  /** latência transport→worker do último frame (µs) */
  lastLatencyUs: number;
  /** kernel WASM carregado com sucesso */
  wasm: boolean;
  /** motivo do fallback JS (quando wasm = false) */
  kernelErr: string | null;
}
