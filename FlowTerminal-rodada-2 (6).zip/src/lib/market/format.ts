// Formatação numérica compartilhada do terminal.

export function tickIndex(price: number, tick: number): number {
  return Math.round(price / tick);
}

export function priceOf(idx: number, tick: number): number {
  return idx * tick;
}

/** Casas decimais derivadas do tick (0.25→2, 5→0, 0.5→1, 0.01→2). */
export function decimalsFor(tick: number): number {
  const s = tick.toString();
  const dot = s.indexOf('.');
  return dot === -1 ? 0 : s.length - dot - 1;
}

export function fmtPrice(p: number, tick: number): string {
  return p.toFixed(decimalsFor(tick));
}

/** Preço com dígitos "pequenos" (última casa em tamanho menor, estilo terminal). */
export function fmtPriceParts(p: number, tick: number): { head: string; tail: string } {
  const dec = decimalsFor(tick);
  const s = p.toFixed(dec);
  if (dec === 0) return { head: s, tail: '' };
  return { head: s.slice(0, -1), tail: s.slice(-1) };
}

export function fmtSize(s: number, decimals = 0): string {
  if (decimals > 0) return s.toFixed(decimals);
  return String(Math.round(s));
}

/** Volume compacto: 1.2K, 3.4M… */
export function fmtCompact(n: number): string {
  const abs = Math.abs(n);
  if (abs >= 1_000_000) return (n / 1_000_000).toFixed(abs >= 10_000_000 ? 0 : 1) + 'M';
  if (abs >= 1_000) return (n / 1_000).toFixed(abs >= 10_000 ? 0 : 1) + 'K';
  if (abs >= 100) return String(Math.round(n));
  if (Number.isInteger(n)) return String(n);
  return n.toFixed(1);
}

export function fmtSignedCompact(n: number): string {
  return (n > 0 ? '+' : '') + fmtCompact(n);
}

export function fmtTime(t: number): string {
  const d = new Date(t);
  const p = (x: number) => String(x).padStart(2, '0');
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

export function fmtTimeMs(t: number): string {
  const d = new Date(t);
  const p = (x: number, l = 2) => String(x).padStart(l, '0');
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}.${p(d.getMilliseconds(), 3)}`;
}

export function fmtHm(t: number): string {
  const d = new Date(t);
  const p = (x: number) => String(x).padStart(2, '0');
  return `${p(d.getHours())}:${p(d.getMinutes())}`;
}
