// ─────────────────────────────────────────────────────────────────────────────
// Indicadores clássicos sobre as velas do terminal (puros, sem React).
// Todos recebem arrays de candles e devolvem arrays alinhados ao input
// (NaN onde o indicador ainda não tem períodos suficientes).
// ─────────────────────────────────────────────────────────────────────────────

import type { Candle } from './types';

/** EMA clássica: semente = SMA do primeiro período; depois fator 2/(period+1). */
export function ema(candles: Candle[], period: number): number[] {
  const out = new Array<number>(candles.length).fill(NaN);
  if (candles.length < period || period < 1) return out;
  const k = 2 / (period + 1);
  let seed = 0;
  for (let i = 0; i < period; i++) seed += candles[i].c;
  let prev = seed / period;
  out[period - 1] = prev;
  for (let i = period; i < candles.length; i++) {
    prev = candles[i].c * k + prev * (1 - k);
    out[i] = prev;
  }
  return out;
}

/** SMA simples: janela móvel de `period` closes. */
export function sma(candles: Candle[], period: number): number[] {
  const out = new Array<number>(candles.length).fill(NaN);
  if (period < 1) return out;
  let sum = 0;
  for (let i = 0; i < candles.length; i++) {
    sum += candles[i].c;
    if (i >= period) sum -= candles[i - period].c;
    if (i >= period - 1) out[i] = sum / period;
  }
  return out;
}

/**
 * RSI de Wilder (14 por padrão). Semeia com a média simples dos primeiros
 * `period` deltas e depois suaviza; NaN antes do primeiro valor válido.
 */
export function rsi(candles: Candle[], period = 14): number[] {
  const out = new Array<number>(candles.length).fill(NaN);
  if (candles.length <= period || period < 1) return out;

  let gain = 0;
  let loss = 0;
  for (let i = 1; i <= period; i++) {
    const d = candles[i].c - candles[i - 1].c;
    if (d >= 0) gain += d;
    else loss -= d;
  }
  let avgG = gain / period;
  let avgL = loss / period;
  out[period] = avgL === 0 ? 100 : 100 - 100 / (1 + avgG / avgL);

  for (let i = period + 1; i < candles.length; i++) {
    const d = candles[i].c - candles[i - 1].c;
    const g = d > 0 ? d : 0;
    const l = d < 0 ? -d : 0;
    avgG = (avgG * (period - 1) + g) / period;
    avgL = (avgL * (period - 1) + l) / period;
    out[i] = avgL === 0 ? 100 : 100 - 100 / (1 + avgG / avgL);
  }
  return out;
}
