// ─────────────────────────────────────────────────────────────────────────────
// Cliente do JOURNAL de mercado (mini-serviço market-data, porta 3003).
//
// Gravação: POST /journal/rec liga/desliga a captura de eventos do engine
// (trades, velas, DOM, sessão, buckets de heatmap e frames MBO binários) em
// SQLite (bun:sqlite). Replay: eventos reconstruídos pelo serviço e transmitidos
// via socket.io com playhead, velocidade e seek — o feed ao vivo é suspenso
// (terminal:unsubscribe) enquanto o journal está ativo.
// ─────────────────────────────────────────────────────────────────────────────

import {
  EV_J_LOAD,
  EV_J_PLAY,
  EV_J_SEEK,
  EV_J_SPEED,
  EV_J_STOP,
  EV_UNSUBSCRIBE,
  EV_SUBSCRIBE,
  type JournalSessionMeta,
  type Timeframe,
} from './types';
import { getTerminalSocket } from './socket';
import { useTerminalStore } from '@/store/terminal';

/** URL REST: proxy interno do Next (route handler /api/journal → serviço 3003). */
function svc(path: string): string {
  return `/api/journal${path}`;
}

async function req<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(svc(path), {
    ...init,
    headers: { 'content-type': 'application/json', ...(init?.headers ?? {}) },
  });
  if (!res.ok) throw new Error(`journal ${path}: HTTP ${res.status}`);
  return (await res.json()) as T;
}

/** Lista as sessões gravadas (mais recentes primeiro). */
export function fetchSessions(): Promise<{ sessions: JournalSessionMeta[] }> {
  return req<{ sessions: JournalSessionMeta[] }>('/sessions');
}

/** Liga/desliga a gravação do journal p/ {symbol, tf}. */
export async function setJournalRecording(
  on: boolean,
  symbol: string,
  tf: Timeframe,
): Promise<{ ok: boolean; sessionId?: number }> {
  return req('/rec', {
    method: 'POST',
    body: JSON.stringify({ on, symbol, tf }),
  });
}

/** Exclui uma sessão gravada. */
export function deleteJournalSession(id: number): Promise<{ ok: boolean }> {
  return req(`/sessions/${id}`, { method: 'DELETE' });
}

// ── controle do replay via socket ────────────────────────────────────────────

/**
 * Carrega uma sessão do journal no modo replay: suspende o feed ao vivo,
 * recebe o snapshot reconstruído no início e passa a receber eventos.
 */
export function journalLoad(sessionId: number, tf: Timeframe): void {
  const s = getTerminalSocket();
  if (!s) return;
  if (s.connected) s.emit(EV_UNSUBSCRIBE);
  s.emit(EV_J_LOAD, { sessionId, tf });
}

export function journalPlay(playing: boolean): void {
  getTerminalSocket()?.emit(EV_J_PLAY, { playing });
}

export function journalSpeed(speed: number): void {
  getTerminalSocket()?.emit(EV_J_SPEED, { speed });
}

export function journalSeek(ts: number): void {
  getTerminalSocket()?.emit(EV_J_SEEK, { ts });
}

/** Encerra o replay e volta ao feed ao vivo. */
export function journalStop(): void {
  const s = getTerminalSocket();
  if (s) s.emit(EV_J_STOP, {});
  useTerminalStore.getState().clearJournal();
  if (s?.connected) {
    const st = useTerminalStore.getState();
    s.emit(EV_SUBSCRIBE, { symbol: st.symbol, tf: st.tf });
  }
}
