'use client';

import { useEffect } from 'react';
import { io, type Socket } from 'socket.io-client';
import { mboClient } from '@/lib/mbo/client';
import { useTerminalStore } from '@/store/terminal';
import {
  CandleMsg,
  DomSnapshot,
  EV_CANDLE,
  EV_DOM,
  EV_HEATMAP,
  EV_J_EVENT,
  EV_J_SNAPSHOT,
  EV_J_STATUS,
  EV_MBO,
  EV_SESSION,
  EV_SNAPSHOT,
  EV_SUBSCRIBE,
  EV_UNSUBSCRIBE,
  EV_TRADE,
  HeatmapMsg,
  JournalEventMsg,
  JournalSnapshotMsg,
  JournalStatusMsg,
  SessionStats,
  SnapshotPayload,
  SubscribeMsg,
  Timeframe,
  Trade,
} from '@/lib/market/types';

let socket: Socket | null = null;

/**
 * Socket singleton do terminal.
 *
 * Estratégia de transporte (2 tentativas):
 *  1. Gateway do preview: '/?XTransformPort=3003' (funciona no sandbox).
 *  2. Fallback direto: '{proto}//{host}:3003' (instalação local sem gateway).
 *
 * Um watchdog de 4,5 s troca para a URL direta se a primeira não conectar.
 * Handlers são sempre vinculados ao socket ativo (this.socket !== s protege
 * contra trocas concorrentes durante a reconexão).
 */
export function getTerminalSocket(): Socket | null {
  if (typeof window === 'undefined') return null;
  if (socket) return socket;

  const store = () => useTerminalStore.getState();

  const makeSocket = (url: string): Socket =>
    io(url, {
      transports: ['websocket', 'polling'],
      forceNew: true,
      reconnection: true,
      reconnectionAttempts: Infinity,
      reconnectionDelay: 800,
      reconnectionDelayMax: 4000,
      timeout: 10000,
    });

  const bindSocket = (s: Socket) => {
    s.on('connect', () => {
      store().setStatus('live');
      const { symbol, tf } = store();
      s.emit(EV_SUBSCRIBE, { symbol, tf } satisfies SubscribeMsg);
    });

    s.on('disconnect', () => store().setStatus('offline'));
    s.io.on('reconnect_attempt', () => store().setStatus('connecting'));
    s.on('connect_error', () => {
      if (store().status !== 'offline') store().setStatus('connecting');
    });

    s.on(EV_SNAPSHOT, (p: SnapshotPayload) => {
      const cur = store();
      if (p.symbol !== cur.symbol || p.tf !== cur.tf) return;
      cur.applySnapshot(p);
      // prefill do anel do worker MBO (heatmap JSON + âncora do best bid)
      mboClient.initSnapshot(p);
    });

    s.on(EV_TRADE, (t: Trade) => store().applyTrade(t));

    s.on(EV_CANDLE, (msg: CandleMsg) => {
      const cur = store();
      if (msg.tf !== cur.tf) return;
      cur.applyCandle(msg.candle);
    });

    s.on(EV_DOM, (d: DomSnapshot) => store().applyDom(d));
    s.on(EV_SESSION, (st: SessionStats) => store().applySession(st));
    s.on(EV_HEATMAP, (m: HeatmapMsg) => {
      const cur = store();
      if (m.tf !== cur.tf) return;
      cur.applyHeatBucket(m.bucket);
    });

    // stream binário MBO (FlatBuffers-style): frames vão direto pro worker
    s.on(EV_MBO, (buf: ArrayBuffer) => {
      if (buf instanceof ArrayBuffer) mboClient.pushFrame(buf);
    });

    // ── journal: replay de sessões gravadas ──────────────────────────────────
    s.on(EV_J_SNAPSHOT, (m: JournalSnapshotMsg) => {
      const st = useTerminalStore.getState();
      st.resetData();
      st.applySnapshot(m.snapshot);
      st.patchJournal({
        active: true,
        loading: false,
        sessionId: m.sessionId,
        ts: m.ts,
        startT: m.range.start,
        endT: m.range.end,
        pct: m.range.end > m.range.start ? ((m.ts - m.range.start) / (m.range.end - m.range.start)) * 100 : 0,
        ended: false,
      });
      // pré-aquece o anel do worker MBO com o heatmap reconstruído
      mboClient.initSnapshot(m.snapshot);
    });

    s.on(EV_J_EVENT, (m: JournalEventMsg) => {
      const st = useTerminalStore.getState();
      if (!st.journal.active) return;
      switch (m.k) {
        case 'trade':
          st.applyTrade(m.d as Trade);
          break;
        case 'candle':
          if ((m.d as CandleMsg).tf === st.tf) st.applyCandle((m.d as CandleMsg).candle);
          break;
        case 'dom':
          st.applyDom(m.d as DomSnapshot);
          break;
        case 'session':
          st.applySession(m.d as SessionStats);
          break;
        case 'heat': {
          const hm = m.d as HeatmapMsg;
          if (hm.tf === st.tf) st.applyHeatBucket(hm.bucket);
          break;
        }
        case 'mbo':
          if (m.d instanceof ArrayBuffer) mboClient.pushFrame(m.d, m.t);
          break;
        default:
          break;
      }
      st.patchJournal({ ts: m.t });
    });

    s.on(EV_J_STATUS, (m: JournalStatusMsg) => {
      const st = useTerminalStore.getState();
      if (!st.journal.active || st.journal.sessionId !== m.sessionId) return;
      st.patchJournal({
        playing: m.playing,
        speed: m.speed,
        ts: m.ts,
        startT: m.start,
        endT: m.end,
        pct: m.pct,
        ended: m.ended,
      });
    });
  };

  const urls = [
    '/?XTransformPort=3003',
    `${window.location.protocol}//${window.location.hostname}:3003`,
  ];
  let urlIdx = 0;

  const openNext = () => {
    if (urlIdx >= urls.length) return;
    const url = urls[urlIdx++];
    const s = makeSocket(url);
    bindSocket(s);
    if (socket && socket !== s) socket.close(); // troca de transporte
    socket = s;
  };

  openNext();
  // watchdog: se o gateway não conectar em 4,5 s, tenta o transporte direto
  setTimeout(() => {
    if (socket && !socket.connected && urlIdx < urls.length) {
      socket.close();
      openNext();
    }
  }, 4500);

  return socket;
}

/** (Re)inscreve o cliente para { symbol, tf }. */
export function subscribeTerminal(symbol: string, tf: Timeframe) {
  const s = getTerminalSocket();
  if (!s) return;
  if (s.connected) s.emit(EV_SUBSCRIBE, { symbol, tf });
}

/** Suspende o feed ao vivo (usado ao entrar no replay do journal). */
export function unsubscribeTerminal() {
  const s = getTerminalSocket();
  if (!s || !s.connected) return;
  s.emit(EV_UNSUBSCRIBE, {});
}

/**
 * Hook de ciclo de vida: conecta o socket e re-inscreve quando
 * símbolo/timeframe mudam.
 */
export function useTerminalConnection() {
  const symbol = useTerminalStore((s) => s.symbol);
  const tf = useTerminalStore((s) => s.tf);
  const journalActive = useTerminalStore((s) => s.journal.active);

  // troca de símbolo/tf durante o replay: encerra o replay (volta ao vivo)
  useEffect(() => {
    const st = useTerminalStore.getState();
    if (!st.journal.active) return;
    st.clearJournal();
    // import dinâmico: journal.ts importa este módulo (evita ciclo)
    import('./journal').then((m) => m.journalStop());
  }, [symbol, tf]);

  useEffect(() => {
    const s = getTerminalSocket();
    const st = useTerminalStore.getState();
    // replay do journal ativo: o feed é o journal; não mexe em subscrição
    if (journalActive) return;
    // status reflete o estado real do socket (não força 'connecting' se já conectado)
    if (!s || !s.connected) st.setStatus('connecting');
    st.resetData();
    subscribeTerminal(symbol, tf);
    // motor MBO: worker + kernel WASM seguem símbolo/tf
    mboClient.ensure(symbol, tf);

    // liga/desliga o motor MBO pela setting useMbo
    const unsubMbo = useTerminalStore.subscribe((state, prev) => {
      if (state.useMbo === prev.useMbo) return;
      if (state.useMbo) {
        const cur = useTerminalStore.getState();
        mboClient.ensure(cur.symbol, cur.tf);
      } else {
        mboClient.dispose();
      }
    });
    return () => {
      unsubMbo();
    };
    // quando o replay termina (journalActive → false), re-executa p/ voltar ao vivo
  }, [symbol, tf, journalActive]);
}
