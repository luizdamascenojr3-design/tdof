// ─────────────────────────────────────────────────────────────────────────────
// Contrato compartilhado de dados de mercado (cliente ⇄ mini-serviço).
// Fonte única de verdade: alterações aqui devem ser replicadas no serviço.
// ─────────────────────────────────────────────────────────────────────────────

export type Aggressor = 'buy' | 'sell';

/** Um negócio (trade) impresso no tape. */
export interface Trade {
  id: number;
  /** timestamp em ms */
  t: number;
  /** preço do negócio */
  p: number;
  /** quantidade negociada */
  s: number;
  /** agressor: 'buy' compra pelo ask, 'sell' vende pelo bid */
  side: Aggressor;
  /** trade grande (marcado pelo servidor por símbolo) */
  big?: boolean;
}

/** Volumes por nível de preço dentro de uma vela (cluster). */
export interface CandleLevel {
  /** volume agressor de venda (executado no bid) */
  b: number;
  /** volume agressor de compra (executado no ask) */
  a: number;
}

/** Vela com clusters por nível (chave = índice do tick: Math.round(price / tick)). */
export interface Candle {
  /** abertura da vela em ms (alinhado ao bucket do timeframe) */
  t: number;
  o: number;
  h: number;
  l: number;
  c: number;
  /** volume total */
  v: number;
  /** delta (ask volume − bid volume) */
  d: number;
  /** número de negócios */
  n: number;
  /** mapa nível→volumes; chave = tick index */
  lv: Record<number, CandleLevel>;
}

export interface DomLevel {
  /** preço do nível */
  p: number;
  /** quantidade ofertada */
  s: number;
}

export interface DomSnapshot {
  /** lados ordenados do maior para o menor preço (12 níveis por lado) */
  bids: DomLevel[];
  asks: DomLevel[];
  /** volume negociado na sessão por tick index (coluna Volume do DOM) */
  vol: Record<number, number>;
  /** delta da sessão por tick index (coluna Delta do DOM) */
  delta: Record<number, number>;
}

export interface SessionStats {
  symbol: string;
  open: number;
  high: number;
  low: number;
  last: number;
  volume: number;
  delta: number;
  trades: number;
  vwap: number;
  /** preço do POC da sessão */
  poc: number;
}

/**
 * Bucket do heatmap de liquidez: book RESTANTE (limit orders) agregado por
 * timeframe. Para cada tick index guarda o MÁXIMO de quantidade visto no
 * bucket separado por lado [bid, ask].
 */
export interface HeatmapBucket {
  /** abertura do bucket em ms (alinhado ao bucket do timeframe) */
  t: number;
  /** tick index → [bid, ask] */
  lv: Record<number, [number, number]>;
}

export interface SnapshotPayload {
  symbol: string;
  tf: Timeframe;
  serverTime: number;
  candles: Candle[];
  dom: DomSnapshot;
  tape: Trade[];
  session: SessionStats;
  /** histórico recente de liquidez do book (buckets alinhados ao tf) */
  heatmap: HeatmapBucket[];
}

/**
 * Operação de book decodificada no worker MBO (para o log de ordens).
 * `op`: 0 = upsert, 1 = delete. `side`: 0 = bid, 1 = ask.
 * `dq` = variação de quantidade vs. o valor anterior do nível (−q em delete).
 */
export interface MboOp {
  /** ms do frame (serverTime) */
  t: number;
  side: 0 | 1;
  op: 0 | 1;
  /** tick index do nível */
  idx: number;
  /** quantidade resultante no nível */
  qty: number;
  /** variação vs. quantidade anterior */
  dq: number;
}

export const TIMEFRAMES = ['5s', '15s', '1m', '5m'] as const;
export type Timeframe = (typeof TIMEFRAMES)[number];

export const TF_MS: Record<Timeframe, number> = {
  '5s': 5_000,
  '15s': 15_000,
  '1m': 60_000,
  '5m': 300_000,
};

export interface SymbolMeta {
  symbol: string;
  label: string;
  /** tamanho do tick (incremento mínimo de preço) */
  tick: number;
  /** casas decimais para exibir preço */
  priceDecimals: number;
  /** casas decimais para exibir quantidade */
  sizeDecimals: number;
}

export const SYMBOLS: SymbolMeta[] = [
  { symbol: 'WINFUT', label: 'WINFUT · Mini Índice', tick: 5, priceDecimals: 0, sizeDecimals: 0 },
  { symbol: 'ES', label: 'ES · S&P 500 Fut', tick: 0.25, priceDecimals: 2, sizeDecimals: 0 },
  { symbol: 'BTCUSDT', label: 'BTC/USDT', tick: 0.5, priceDecimals: 1, sizeDecimals: 2 },
  { symbol: 'PETR4', label: 'PETR4 · B3', tick: 0.01, priceDecimals: 2, sizeDecimals: 0 },
];

export function symbolMeta(symbol: string): SymbolMeta {
  return SYMBOLS.find((s) => s.symbol === symbol) ?? SYMBOLS[0];
}

// ── Eventos socket.io ────────────────────────────────────────────────────────
export const EV_SUBSCRIBE = 'terminal:subscribe';
export const EV_UNSUBSCRIBE = 'terminal:unsubscribe';
export const EV_SNAPSHOT = 'terminal:snapshot';
export const EV_TRADE = 'terminal:trade';
export const EV_CANDLE = 'terminal:candle';
export const EV_DOM = 'terminal:dom';
export const EV_SESSION = 'terminal:session';
export const EV_HEATMAP = 'terminal:heatmap';
/** delta binário do order book (FlatBuffers-style, payload = ArrayBuffer) */
export const EV_MBO = 'terminal:mbo';

// ── Eventos do journal (replay de sessões gravadas) ─────────────────────────
export const EV_J_LOAD = 'journal:load';
export const EV_J_PLAY = 'journal:play';
export const EV_J_SPEED = 'journal:speed';
export const EV_J_SEEK = 'journal:seek';
export const EV_J_STOP = 'journal:stop';
export const EV_J_SNAPSHOT = 'journal:snapshot';
export const EV_J_EVENT = 'journal:event';
export const EV_J_STATUS = 'journal:status';

/** Sessão gravada no journal (listagem REST). */
export interface JournalSessionMeta {
  id: number;
  symbol: string;
  tf: Timeframe;
  start: number;
  end: number;
  /** nº de eventos capturados (trades, velas, dom, frames MBO…) */
  events: number;
}

/** kinds de evento capturados no journal. `base` = snapshot completo no início. */
export type JournalEventKind = 'base' | 'trade' | 'candle' | 'dom' | 'session' | 'heat' | 'mbo';

/** Estado reconstruído pelo serviço em um ts do journal. */
export interface JournalSnapshotMsg {
  sessionId: number;
  snapshot: SnapshotPayload;
  /** range temporal da sessão gravada (ms) */
  range: { start: number; end: number };
  ts: number;
}

/** Evento individual transmitido durante o replay do journal. */
export interface JournalEventMsg {
  k: JournalEventKind;
  /** tf quando aplicável (candle/heat) */
  tf?: Timeframe;
  /** ms do evento (tempo do mercado) */
  t: number;
  /** payload (Trade / CandleMsg / DomSnapshot / SessionStats / HeatmapMsg / ArrayBuffer) */
  d: unknown;
}

/** Status periódico do replay do journal (500ms). */
export interface JournalStatusMsg {
  sessionId: number;
  playing: boolean;
  speed: number;
  /** playhead em ms (tempo do mercado) */
  ts: number;
  start: number;
  end: number;
  /** 0..100 */
  pct: number;
  /** todos os eventos já transmitidos */
  ended: boolean;
}

export interface SubscribeMsg {
  symbol: string;
  tf: Timeframe;
}

export interface CandleMsg {
  tf: Timeframe;
  candle: Candle;
}

export interface HeatmapMsg {
  tf: Timeframe;
  bucket: HeatmapBucket;
}
