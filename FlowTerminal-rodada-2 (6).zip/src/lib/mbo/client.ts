// ─────────────────────────────────────────────────────────────────────────────
// Ponte main-thread ⇄ WebWorker MBO (singleton do terminal).
//
// O worker mantém o HeatMapRing e o detector de fluxo; esta ponte:
//  - cria/encerra o worker conforme a setting `useMbo`;
//  - repassa frames binários (transferable) e snapshots JSON;
//  - expõe o anel mais recente (lido direto pelo renderer WebGL, sem passar
//    pelo Zustand — arrays grandes não pertencem ao estado React);
//  - entrega sinais e estatísticas ao store.
// ─────────────────────────────────────────────────────────────────────────────

import type { DomL3Snapshot, FlowSignal, HeatRingPayload, MboStats } from '@/lib/market/flow';
import type { MboOp } from '@/lib/market/types';
import { symbolMeta, type HeatmapBucket, type SnapshotPayload, type Timeframe } from '@/lib/market/types';
import { useTerminalStore } from '@/store/terminal';

interface PendingInit {
  symbol: string;
  tf: Timeframe;
  heatmap?: HeatmapBucket[];
  bestBidTick?: number;
}

class MboClient {
  /** anel mais recente publicado pelo worker (imutável p/ o leitor) */
  ring: HeatRingPayload | null = null;
  /** worker criado e publicando? */
  ready = false;
  /** worker já recebeu pelo menos um frame do socket */
  active = false;
  /** renderer WebGL anexado ao gráfico (setado pelo ClusterChart) */
  glOk = false;

  private worker: Worker | null = null;
  private initSymbol = '';
  private initTf = '';
  private ringListeners: (() => void)[] = [];

  onRing(fn: () => void): () => void {
    this.ringListeners.push(fn);
    return () => {
      this.ringListeners = this.ringListeners.filter((f) => f !== fn);
    };
  }

  /** Garante o worker para {symbol, tf} (idempotente). */
  ensure(symbol: string, tf: Timeframe): void {
    if (typeof window === 'undefined') return;
    if (!useTerminalStore.getState().useMbo) {
      this.dispose();
      return;
    }
    if (this.worker) {
      if (symbol !== this.initSymbol || tf !== this.initTf) {
        this.initSymbol = symbol;
        this.initTf = tf;
        this.ring = null;
        this.active = false;
        this.worker.postMessage({ type: 'init', symbol, tf });
      }
      return;
    }
    this.initSymbol = symbol;
    this.initTf = tf;
    this.active = false;
    const w = new Worker(new URL('../../workers/mbo-worker.ts', import.meta.url));
    w.onmessage = (e: MessageEvent) => this.onWorkerMsg(e);
    w.onerror = () => {
      this.ready = false;
      this.active = false;
    };
    this.worker = w;
    // auto-recuperação: se o store já tem snapshot (worker recriado pós-HMR /
    // reconexão), repõe o prefill do anel na hora — sem esperar um novo
    // EV_SNAPSHOT (que só chega no resubscribe).
    const st = useTerminalStore.getState();
    if (st.heatmap.length > 0 && st.dom && st.symbol === symbol && st.tf === tf) {
      this.initSnapshot({
        symbol,
        tf,
        serverTime: Date.now(),
        candles: st.candles,
        tape: st.tape,
        dom: st.dom,
        session:
          st.session ?? {
            symbol,
            open: 0,
            high: 0,
            low: 0,
            last: 0,
            volume: 0,
            delta: 0,
            trades: 0,
            vwap: 0,
            poc: 0,
          },
        heatmap: st.heatmap,
      });
    } else {
      w.postMessage({ type: 'init', symbol, tf });
    }
  }

  /** Aplica o snapshot JSON (prefill do anel + âncora inicial). */
  initSnapshot(p: SnapshotPayload): void {
    if (!this.worker || !useTerminalStore.getState().useMbo) return;
    const bestBid = p.dom?.bids?.[0]?.p;
    const tick = symbolMeta(p.symbol).tick;
    const msg: PendingInit & { type: 'init' } = {
      type: 'init',
      symbol: p.symbol,
      tf: p.tf,
      heatmap: p.heatmap,
      bestBidTick: bestBid !== undefined ? Math.round(bestBid / tick) : undefined,
    };
    this.worker.postMessage(msg);
  }

  /** Repassa um frame binário (transferable). `clientT` = epoch ms do relógio
   *  "consumidor" — no replay do journal passamos o próprio serverTime do frame
   *  p/ não poluir a métrica de latência. */
  pushFrame(buf: ArrayBuffer, clientT?: number): void {
    if (!this.worker || !useTerminalStore.getState().useMbo) return;
    this.active = true;
    // epoch float ms (timeOrigin + now) — mesmo relógio do worker (latência µs)
    const t = clientT ?? performance.timeOrigin + performance.now();
    this.worker.postMessage({ type: 'frame', buf, clientT: t }, [buf]);
  }

  /** Limpa o anel local (troca de símbolo/tf). */
  reset(): void {
    this.ring = null;
    this.worker?.postMessage({ type: 'reset' });
  }

  dispose(): void {
    this.worker?.terminate();
    this.worker = null;
    this.ring = null;
    this.ready = false;
    this.active = false;
  }

  private onWorkerMsg(e: MessageEvent): void {
    const msg = e.data as
      | { type: 'ring'; ring: HeatRingPayload }
      | { type: 'signals'; signals: FlowSignal[] }
      | { type: 'stats'; stats: MboStats }
      | { type: 'ops'; ops: MboOp[] }
      | { type: 'doml3'; snapshot: DomL3Snapshot };
    if (msg.type === 'ring') {
      this.ring = msg.ring;
      for (const fn of this.ringListeners) fn();
      return;
    }
    const st = useTerminalStore.getState();
    if (msg.type === 'signals') st.applyFlowSignals(msg.signals);
    else if (msg.type === 'stats') st.setMboStats(msg.stats);
    else if (msg.type === 'ops') st.applyMboOps(msg.ops);
    else if (msg.type === 'doml3') st.setDomL3(msg.snapshot);
    if (!this.ready) this.ready = true;
  }
}

/** Singleton do terminal. */
export const mboClient = new MboClient();

// probe de desenvolvimento: inspeção do anel pelo console (não entra em prod)
if (typeof window !== 'undefined' && process.env.NODE_ENV !== 'production') {
  (window as unknown as Record<string, unknown>).__mboClient = mboClient;
}
