// ─────────────────────────────────────────────────────────────────────────────
// DOM MBO Nível 3 — decomposição da fila de ordens por nível de preço.
//
// O stream binário MBO entrega a quantidade AGREGADA por nível (lote total).
// A fila de ordens individuais (Order Queue) é reconstruída aqui com
// decomposição DETERMINÍSTICA: mesma (nível, lado, quantidade) → mesma
// partição. Assim a fila é estável entre frames (ordens "persistem") e só se
// re-embaralha quando o lote do nível muda — sem estado, sem custo no store.
//
// Memoizada por (idx, side, qty) com teto de entradas: o DOM renderiza ≤24
// níveis e as chaves repetem a cada frame — cache hit é o caminho quente.
// ─────────────────────────────────────────────────────────────────────────────

/** PRNG rápido (mulberry32) — determinístico por seed. */
function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const CACHE_CAP = 512;
const cache = new Map<string, number[]>();

/**
 * Decompõe o lote total `qty` do nível (tick `idx`, lado `side`) em ordens
 * individuais (2–5 partes; 1 quando o lote é mínimo). Soma exata = qty.
 * `decimals` preserva a granularidade do símbolo (BTCUSDT = 2 casas).
 */
export function decomposeQueue(
  idx: number,
  side: 0 | 1,
  qty: number,
  decimals = 0,
): number[] {
  if (!(qty > 0)) return [];
  const key = `${idx}:${side}:${qty}:${decimals}`;
  const hit = cache.get(key);
  if (hit) return hit;

  const p = Math.pow(10, decimals);
  const total = Math.round(qty * p);
  // nº de ordens: lote pequeno = 1; depois 2–5 conforme o tamanho relativo
  const rnd = mulberry32(Math.imul(idx + 0x9e37, 2654435761) ^ Math.imul(side + 1, 40503) ^ total);
  const unit = Math.max(1, Math.round(p)); // 1 unidade inteira na granularidade
  const n = total <= unit * 2 ? 1 : Math.min(5, 2 + Math.floor(rnd() * 4));
  const parts: number[] = [];
  if (n === 1) {
    parts.push(qty);
  } else {
    // pesos aleatórios normalizados, mínimo de 1 unidade por ordem
    let acc = 0;
    const w: number[] = [];
    for (let i = 0; i < n; i++) {
      const v = 0.35 + rnd() * 1.3;
      w.push(v);
      acc += v;
    }
    let used = 0;
    for (let i = 0; i < n - 1; i++) {
      const share = Math.max(unit, Math.round((w[i] / acc) * total));
      const take = Math.min(share, total - used - unit * (n - 1 - i));
      used += take;
      parts.push(take / p);
    }
    parts.push((total - used) / p);
  }
  // ordena do maior p/ o menor (fila "na frente" primeiro) — leitura estável
  parts.sort((a, b) => b - a);

  if (cache.size >= CACHE_CAP) {
    // evicção FIFO simples (Map preserva a ordem de inserção)
    const first = cache.keys().next().value;
    if (first !== undefined) cache.delete(first);
  }
  cache.set(key, parts);
  return parts;
}
