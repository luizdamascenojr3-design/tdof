// ─────────────────────────────────────────────────────────────────────────────
// Carregador do kernel WASM do motor MBO (hot-path numérico do WebWorker).
//
// O módulo (public/wasm/mbo-kernel.wasm, fonte em tools/mbo-kernel.wat) expõe:
//   memory: WebAssembly.Memory
//   applyBook(colPtr, rows, colBase, deltasPtr, nDeltas)   → máx. visto/bucket
//   accTrades(outPtr, rows, colBase, tradesPtr, nTrades, statsPtr) → exec + CVD
// Layouts na memória linear estão documentados em tools/mbo-kernel.wat.
//
// Se o fetch/instantiate falhar, um gêmeo em JS (mesma semântica, DataView)
// entra no lugar — o terminal degrada sem interrupção.
// ─────────────────────────────────────────────────────────────────────────────

export interface MboKernel {
  /** memória linear compartilhada (worker escreve inputs, kernel escreve saídas) */
  memory: WebAssembly.Memory;
  applyBook(colPtr: number, rows: number, colBase: number, deltasPtr: number, nDeltas: number): void;
  accTrades(
    outPtr: number,
    rows: number,
    colBase: number,
    tradesPtr: number,
    nTrades: number,
    statsPtr: number,
  ): void;
}

/** Instancia o kernel real (WASM). Lança se indisponível. */
async function loadWasmKernel(): Promise<MboKernel> {
  // workers podem rodar em blob: URL (bundler) — resolve contra a origem
  const url = new URL('/wasm/mbo-kernel.wasm', self.location.origin).href;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`kernel wasm HTTP ${res.status}`);
  const bytes = await res.arrayBuffer();
  const { instance } = await WebAssembly.instantiate(bytes, {});
  const ex = instance.exports as unknown as {
    memory: WebAssembly.Memory;
    applyBook: MboKernel['applyBook'];
    accTrades: MboKernel['accTrades'];
  };
  if (!ex.memory || !ex.applyBook || !ex.accTrades) throw new Error('exports ausentes');
  return ex;
}

/** Fallback JS com semântica idêntica (usado quando WASM não carrega). */
function makeJsKernel(): MboKernel {
  const memory = new WebAssembly.Memory({ initial: 4 });
  const u8 = new Uint8Array(memory.buffer);
  const dv = new DataView(memory.buffer);
  return {
    memory,
    applyBook(colPtr, rows, colBase, deltasPtr, nDeltas) {
      for (let i = 0; i < nDeltas; i++) {
        const o = deltasPtr + i * 12;
        const idx = dv.getInt32(o, true);
        const side = u8[o + 4];
        const op = u8[o + 5];
        const qty = dv.getFloat32(o + 8, true);
        const row = idx - colBase;
        if (row < 0 || row >= rows) continue;
        const addr = colPtr + row * 8 + side * 4;
        if (op === 0) {
          const cur = dv.getFloat32(addr, true);
          dv.setFloat32(addr, Math.max(cur, qty), true);
        } else {
          dv.setFloat32(addr, 0, true);
        }
      }
    },
    accTrades(outPtr, rows, colBase, tradesPtr, nTrades, statsPtr) {
      let cvd = dv.getFloat64(statsPtr, true);
      let volume = dv.getFloat64(statsPtr + 8, true);
      let buyVol = dv.getFloat64(statsPtr + 16, true);
      let sellVol = dv.getFloat64(statsPtr + 24, true);
      let count = dv.getFloat64(statsPtr + 32, true);
      for (let j = 0; j < nTrades; j++) {
        const o = tradesPtr + j * 24;
        const p = dv.getInt32(o + 8, true);
        const s = dv.getFloat32(o + 12, true);
        const side = u8[o + 16];
        const row = p - colBase;
        if (row >= 0 && row < rows) {
          const addr = outPtr + row * 8 + side * 4;
          dv.setFloat32(addr, dv.getFloat32(addr, true) + s, true);
        }
        if (side === 1) {
          cvd += s;
          buyVol += s;
        } else {
          cvd -= s;
          sellVol += s;
        }
        volume += s;
        count += 1;
      }
      dv.setFloat64(statsPtr, cvd, true);
      dv.setFloat64(statsPtr + 8, volume, true);
      dv.setFloat64(statsPtr + 16, buyVol, true);
      dv.setFloat64(statsPtr + 24, sellVol, true);
      dv.setFloat64(statsPtr + 32, count, true);
    },
  };
}

/** Carrega o kernel WASM; cai para o gêmeo JS em qualquer falha (com o motivo). */
export async function loadMboKernel(): Promise<{
  kernel: MboKernel;
  wasm: boolean;
  err: string | null;
}> {
  try {
    return { kernel: await loadWasmKernel(), wasm: true, err: null };
  } catch (err) {
    console.warn('[mbo-worker] kernel WASM indisponível, usando fallback JS:', err);
    return { kernel: makeJsKernel(), wasm: false, err: String(err) };
  }
}
