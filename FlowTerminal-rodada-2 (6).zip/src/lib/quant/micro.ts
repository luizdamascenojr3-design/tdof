// ─────────────────────────────────────────────────────────────────────────────
// Microestrutura de mercado (Quant/Flow): Order Flow Imbalance (OFI),
// CVD tabular e métricas de exaustão — puro, sem React, O(1) amortizado por
// evento. Correlaciona-se com o GEX (lib/quant/quant.ts) no painel.
// ─────────────────────────────────────────────────────────────────────────────

import type { Candle, DomLevel, DomSnapshot } from '@/lib/market/types';
import type { FlowSignal } from '@/lib/market/flow';

// ── OFI (Order Flow Imbalance) ───────────────────────────────────────────────
// Adaptação multi-nível do OFI de Cont, Kukanov & Stoikov (2014): o OFI
// clássico mede a variação líquida de profundidade no best bid/ask entre
// snapshots consecutivos; aqui somamos a variação de profundidade de TODOS os
// níveis que persistem entre os dois snapshots (Δbid − Δask), o que captura
// acúmulo/retirada passiva no book como proxy de pressão.
//
//   OFI_t = Σ_k [ ΔBidVol_k − ΔAskVol_k ]  (k = níveis presentes em t e t−1)
//
// OFI > 0: profundidade de compra crescendo (suporte) · OFI < 0: oferta
// pesando (resistência). Janela móvel (ring buffer) p/ leitura suave.

interface OfiSide {
  /** tick index → quantidade */
  q: Map<number, number>;
}

interface OfiSample {
  /** ms do snapshot */
  t: number;
  /** ofi instantâneo deste snapshot */
  ofi: number;
}

const OFI_WINDOW_MS = 8_000;
/** nº máximo de amostras no ring (redundância de segurança) */
const OFI_MAX_SAMPLES = 64;

export class OfiTracker {
  private prevBid: OfiSide | null = null;
  private prevAsk: OfiSide | null = null;
  private ring: OfiSample[] = [];

  /** Processa um snapshot de DOM; retorna { ofi instantâneo, janela, histórico }. */
  push(dom: DomSnapshot, now: number): {
    ofi: number;
    windowMs: number;
    hist: number[];
  } {
    const ofi = this.instantOfi(dom.bids, dom.asks);
    this.ring.push({ t: now, ofi });
    while (this.ring.length > OFI_MAX_SAMPLES) this.ring.shift();
    const cutoff = now - OFI_WINDOW_MS;
    while (this.ring.length > 1 && (this.ring[0]?.t ?? 0) < cutoff) this.ring.shift();

    let sum = 0;
    for (const s of this.ring) sum += s.ofi;
    return { ofi, windowMs: OFI_WINDOW_MS, hist: this.ring.map((s) => s.ofi) };
  }

  /** Δ profundidade líquida entre o snapshot anterior e o atual. */
  private instantOfi(bids: DomLevel[], asks: DomLevel[]): number {
    const curBid = toMap(bids);
    const curAsk = toMap(asks);
    let ofi = 0;
    if (this.prevBid && this.prevAsk) {
      ofi += deltaOf(this.prevBid.q, curBid) - deltaOf(this.prevAsk.q, curAsk);
    }
    this.prevBid = { q: curBid };
    this.prevAsk = { q: curAsk };
    return ofi;
  }

  reset(): void {
    this.prevBid = null;
    this.prevAsk = null;
    this.ring = [];
  }
}

function toMap(levels: DomLevel[]): Map<number, number> {
  const m = new Map<number, number>();
  for (const l of levels) m.set(Math.round(l.p * 1e6), l.s);
  return m;
}

/** Soma das variações de quantidade dos níveis que persistem (prev → cur). */
function deltaOf(prev: Map<number, number>, cur: Map<number, number>): number {
  let d = 0;
  for (const [k, qPrev] of prev) {
    const qCur = cur.get(k);
    if (qCur !== undefined) d += qCur - qPrev;
  }
  return d;
}

// ── CVD tabular ──────────────────────────────────────────────────────────────

/** Linha da tabela CVD (uma por vela). */
export interface CvdRow {
  /** abertura da vela (ms) */
  t: number;
  volume: number;
  /** delta da vela (ask − bid) */
  delta: number;
  /** CVD acumulado até o fim da vela */
  cvd: number;
}

/**
 * Série CVD a partir das velas do timeframe: acumula `d` e devolve as
 * últimas `n` linhas (ordem cronológica) com o CVD absoluto da sessão.
 * Custo O(N) por chamada — memoizado pelo chamador (useMemo sobre candles).
 */
export function cvdSeries(candles: Candle[], n = 18): {
  rows: CvdRow[];
  /** CVD total da sessão (última linha) */
  total: number;
} {
  const rows: CvdRow[] = [];
  let cvd = 0;
  const start = Math.max(0, candles.length - n);
  for (let i = 0; i < candles.length; i++) {
    const c = candles[i];
    if (!c) continue;
    cvd += c.d;
    if (i >= start) rows.push({ t: c.t, volume: c.v, delta: c.d, cvd });
  }
  return { rows, total: cvd };
}

// ── Exaustão / absorção (sinais de fluxo vivos) ──────────────────────────────

export interface FlowPressure {
  /** nº de sinais de exaustão vivos */
  exhaustion: number;
  /** nº de sinais de absorção vivos */
  absorption: number;
  /** nº de icebergs vivos */
  iceberg: number;
  /** nº de spoofings vivos (cancelamento abrupto de liquidez-fantasma) */
  spoof: number;
  /** pressão líquida: Σ força (buy − sell), normalizada 0..1 por sinal */
  netPressure: number;
  /** força máxima entre os sinais vivos (0..1) */
  maxStrength: number;
  /** exaustão dominante: 'buy' | 'sell' | null */
  dominantSide: 'buy' | 'sell' | null;
}

/** Agrega os sinais vivos (TTL não expirado) em métricas de pressão. */
export function flowPressure(signals: FlowSignal[], now: number): FlowPressure {
  let exhaustion = 0;
  let absorption = 0;
  let iceberg = 0;
  let spoof = 0;
  let net = 0;
  let maxStrength = 0;
  let buyS = 0;
  let sellS = 0;
  for (const s of signals) {
    if (s.until <= now) continue;
    if (s.kind === 'exhaustion') exhaustion++;
    else if (s.kind === 'absorption') absorption++;
    else if (s.kind === 'iceberg') iceberg++;
    else spoof++;
    const signed = s.side === 'buy' ? s.strength : -s.strength;
    net += signed;
    if (s.side === 'buy') buyS += s.strength;
    else sellS += s.strength;
    if (s.strength > maxStrength) maxStrength = s.strength;
  }
  return {
    exhaustion,
    absorption,
    iceberg,
    spoof,
    netPressure: net,
    maxStrength,
    dominantSide:
      exhaustion === 0 ? null : buyS >= sellS ? 'buy' : 'sell',
  };
}

// ── Correlação OFI × GEX ─────────────────────────────────────────────────────

export type FlowGexRegime =
  | 'expansao'      // OFI+ · GEX+ — movimento tendencioso suportado por gamma
  | 'reversao'      // OFI+ · GEX− — agressão contra dealers (pin/flip risk)
  | 'distribuicao'  // OFI− · GEX+ — range apertado, dealers amortecem
  | 'aceleracao'    // OFI− · GEX− — vendedores contra gamma negativa (volatil)
  | 'neutro';

/**
 * Regime combinado OFI × GEX: o sinal do fluxo (profundidade) contra o
 * sinal do gamma líquido dos dealers define o regime esperado do preço.
 */
export function flowGexRegime(ofi: number, netGex: number, eps = 1e-6): FlowGexRegime {
  const ofiPos = ofi > eps;
  const ofiNeg = ofi < -eps;
  const gexPos = netGex > eps;
  const gexNeg = netGex < -eps;
  if (ofiPos && gexPos) return 'expansao';
  if (ofiPos && gexNeg) return 'reversao';
  if (ofiNeg && gexPos) return 'distribuicao';
  if (ofiNeg && gexNeg) return 'aceleracao';
  return 'neutro';
}

/** Rótulo/tooltip por regime (PT-BR, estilo terminal). */
export const FLOW_GEX_REGIME_META: Record<FlowGexRegime, { label: string; hint: string; cls: string }> = {
  expansao: {
    label: 'EXPANSÃO',
    hint: 'OFI+ · GEX+: pressão de compra com dealers gamma-long — tendência sustentável',
    cls: 'text-[#089981]',
  },
  reversao: {
    label: 'REVERSÃO',
    hint: 'OFI+ · GEX−: agressão contra dealers gamma-short — risco de repinço no flip',
    cls: 'text-[#e8a854]',
  },
  distribuicao: {
    label: 'DISTRIBUIÇÃO',
    hint: 'OFI− · GEX+: oferta sem perda de suporte — range apertado, dealers amortecem',
    cls: 'text-[#787b86]',
  },
  aceleracao: {
    label: 'ACELERAÇÃO',
    hint: 'OFI− · GEX−: vendedores contra gamma negativa — regime volátil',
    cls: 'text-[#f2385a]',
  },
  neutro: {
    label: 'NEUTRO',
    hint: 'OFI≈0 ou GEX≈0 — sem leitura de regime',
    cls: 'text-[#787b86]',
  },
};
