// ─────────────────────────────────────────────────────────────────────────────
// Motor quant puro (sem React): cadeia de opções SINTÉTICA e determinística
// (mesma seed → mesmos valores), GEX/vanna/charm por strike (dealer
// convention), paredes de gamma, flip point, max pain, ATR(14) e vol.
// realizada.
// Spot 0/NaN no boot → estrutura vazia válida, sem lançar exceção.
// ─────────────────────────────────────────────────────────────────────────────

import { symbolMeta } from '@/lib/market/types';
import type { Candle } from '@/lib/market/types';

// ── Parâmetros por símbolo ───────────────────────────────────────────────────

/** IV ATM base por símbolo (com variação lenta determinística no build). */
const BASE_IV: Record<string, number> = {
  WINFUT: 0.18,
  ES: 0.14,
  BTCUSDT: 0.45,
  PETR4: 0.28,
};
const DEFAULT_BASE_IV = 0.22;

/** Passo de strike "bonito" por símbolo. */
const STRIKE_STEP: Record<string, number> = {
  WINFUT: 250,
  ES: 25,
  BTCUSDT: 500,
  PETR4: 1,
};

/** OI base (nível ATM) por símbolo (~4000–40000). */
const OI_BASE: Record<string, number> = {
  WINFUT: 26000,
  ES: 40000,
  BTCUSDT: 12000,
  PETR4: 6500,
};
const DEFAULT_OI_BASE = 12000;

/** Smile de IV: base + m·ln(K/S) + s·ln(K/S)² (m/s normalizados pela meia-largura). */
interface SkewParams {
  m: number;
  s: number;
}
const SKEW: Record<string, SkewParams> = {
  WINFUT: { m: -0.018, s: 0.022 },
  ES: { m: -0.014, s: 0.016 },
  BTCUSDT: { m: -0.008, s: 0.045 },
  PETR4: { m: -0.03, s: 0.03 },
};
const DEFAULT_SKEW: SkewParams = { m: -0.02, s: 0.025 };

// ── Parâmetros do modelo ─────────────────────────────────────────────────────

const CHAIN_STRIKES = 21;
/** largura do sino de OI, em ln(K/S) */
const OI_SIGMA = 0.03;
/** viés de OI de puts abaixo do spot (1.15×), rampa suave até o topo (0.85×) */
const PUT_OI_BIAS = 0.15;
const IV_MIN = 0.12;
const IV_MAX = 0.55;
/** vencimento sintético: 14 dias corridos */
const EXPIRY_T = 14 / 252;

// ── Helpers numéricos ────────────────────────────────────────────────────────

function clamp(x: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, x));
}

function roundToTick(x: number, tick: number): number {
  if (!Number.isFinite(x) || !(tick > 0)) return x;
  return Math.round(x / tick) * tick;
}

/** Arredonda para o número "bonito" (1/2/2.5/5×10^n) mais próximo. */
function snapNice(x: number): number {
  if (!Number.isFinite(x) || x <= 0) return 1;
  const exp = Math.floor(Math.log10(x));
  const mant = x / 10 ** exp;
  const cands = [1, 2, 2.5, 5, 10];
  let best = 1;
  let bestD = Infinity;
  for (const c of cands) {
    const d = Math.abs(Math.log(mant / c));
    if (d < bestD) {
      bestD = d;
      best = c;
    }
  }
  return best * 10 ** exp;
}

// ── PRNG determinístico ──────────────────────────────────────────────────────

/** FNV-1a 32-bit → seed numérica a partir de string. */
function hashSeed(str: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}

/** mulberry32: PRNG rápido e determinístico. */
function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), a | 1);
    t = (t + Math.imul(t ^ (t >>> 7), t | 61)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ── Black-Scholes (gamma/vanna/charm fechados, r=0, q=0) ────────────────────

/** φ = pdf normal padrão. */
function normPdf(x: number): number {
  return Math.exp(-0.5 * x * x) / Math.sqrt(2 * Math.PI);
}

/**
 * d1/d2 BS compartilhados por gamma/vanna/charm:
 * d1 = (ln(S/K) + ½σ²T) / (σ√T); d2 = d1 − σ√T.
 * Mesma expressão/ordem de operações do cálculo inline anterior — resultados
 * bit-idênticos. S/K inválidos → {d1:0, d2:0} (greeks degeneram para 0).
 */
function bsD1D2(S: number, K: number, iv: number, T: number): { d1: number; d2: number } {
  if (!(S > 0) || !(K > 0)) return { d1: 0, d2: 0 };
  const sig = iv > 1e-6 ? iv : 1e-6;
  const sqT = Math.sqrt(T);
  const d1 = (Math.log(S / K) + 0.5 * sig * sig * T) / (sig * sqT);
  return { d1, d2: d1 - sig * sqT };
}

/** gamma BS fechado: φ(d1) / (S·σ·√T). */
function bsGamma(S: number, K: number, iv: number, T: number): number {
  if (!(S > 0) || !(K > 0)) return 0;
  const { d1 } = bsD1D2(S, K, iv, T);
  const sig = iv > 1e-6 ? iv : 1e-6;
  return normPdf(d1) / (S * sig * Math.sqrt(T));
}

/** vanna BS (∂²V/∂S∂σ): −φ(d1)·d2 / σ (igual para call e put). */
function bsVanna(S: number, K: number, iv: number, T: number): number {
  if (!(S > 0) || !(K > 0)) return 0;
  const { d1, d2 } = bsD1D2(S, K, iv, T);
  const sig = iv > 1e-6 ? iv : 1e-6;
  return (-normPdf(d1) * d2) / sig;
}

/** charm BS (∂Δ/∂t, decay do delta): φ(d1)·d2 / (2T), T em anos (igual call/put). */
function bsCharm(S: number, K: number, iv: number, T: number): number {
  if (!(S > 0) || !(K > 0)) return 0;
  const { d1, d2 } = bsD1D2(S, K, iv, T);
  return (normPdf(d1) * d2) / (2 * T);
}

// ── API pública ──────────────────────────────────────────────────────────────

/** Cadeia sintética de opções (strikes ascendentes, arrays paralelos). */
export interface QuantChain {
  strikes: number[];
  callOI: number[];
  putOI: number[];
  /** vol implícita sintética em decimal (0.12..0.55) */
  callIV: number[];
  putIV: number[];
  /** spot usado no cálculo */
  spot: number;
  /** IV ATM do símbolo */
  baseIV: number;
}

/** Linha de GEX por strike. Dealer convention: calls positivos, puts negativos. */
export interface GexRow {
  strike: number;
  callGex: number;
  putGex: number;
  net: number;
  /** vanna líquido (dealer convention: calls +, puts −), escala ~$ por 1% de vol */
  netVanna: number;
  /** charm líquido (dealer convention: calls +, puts −), escala ~$ por dia */
  netCharm: number;
}

/** Passo de strike do símbolo (fixo por símbolo; fallback tick*20 "bonito"). */
export function strikeStep(symbol: string, tick: number): number {
  const fixed = STRIKE_STEP[symbol];
  if (fixed && fixed > 0) return fixed;
  return snapNice(tick * 20);
}

/**
 * Constrói a cadeia sintética determinística (seed = seedKey + dia de sessão).
 * Spot 0/NaN → cadeia vazia válida (sem exceção).
 */
export function buildChain(symbol: string, spot: number, seedKey: string): QuantChain {
  const empty = (): QuantChain => ({
    strikes: [],
    callOI: [],
    putOI: [],
    callIV: [],
    putIV: [],
    spot: 0,
    baseIV: 0,
  });

  if (!Number.isFinite(spot) || spot <= 0) return empty();

  const tick = symbolMeta(symbol).tick;
  const step = strikeStep(symbol, tick);
  if (!(step > 0)) return empty();

  // seed: símbolo (via seedKey) + dia de sessão UTC → estável durante o dia
  const day = new Date().toISOString().slice(0, 10);
  const rng = mulberry32(hashSeed(`${seedKey || symbol}|${day}`));

  // IV ATM base com variação lenta determinística (±15%)
  const base0 = BASE_IV[symbol] ?? DEFAULT_BASE_IV;
  const baseIV = clamp(base0 * (1 + (rng() - 0.5) * 0.3), 0.08, 0.8);

  // ~21 strikes centrados no spot, espaçados pelo passo "bonito"
  const half = (CHAIN_STRIKES - 1) / 2;
  const center = Math.round(spot / step) * step;
  const strikes: number[] = [];
  for (let i = 0; i < CHAIN_STRIKES; i++) {
    strikes.push(roundToTick(center + (i - half) * step, tick));
  }
  const topK = strikes[strikes.length - 1] ?? spot;
  const halfLn = Math.max(1e-9, Math.log(topK / spot));

  const oiBase = OI_BASE[symbol] ?? DEFAULT_OI_BASE;
  const sk = SKEW[symbol] ?? DEFAULT_SKEW;
  const m = sk.m / halfLn;
  const s2 = sk.s / (halfLn * halfLn);

  const callOI: number[] = [];
  const putOI: number[] = [];
  const callIV: number[] = [];
  const putIV: number[] = [];

  for (const k of strikes) {
    const x = Math.log(k / spot);

    // OI: sino gaussiano SIMÉTRICO em ln(K/S) + ruído determinístico; puts com
    // viés 1.15× abaixo do spot (rampa suave até 0.85× no topo — realista).
    // O ruído é COMUM ao strike (demanda do nível), então a diferença call×put
    // é estrutural (viés), não aleatória — flip e max pain estáveis.
    const bellC = Math.exp(-0.5 * (x / OI_SIGMA) ** 2);
    const putBias = 1 + PUT_OI_BIAS * Math.tanh(-x / (halfLn * 0.25));
    const strikeNoise = 0.75 + rng() * 0.5;
    callOI.push(Math.max(1, Math.round(oiBase * bellC * strikeNoise)));
    putOI.push(Math.max(1, Math.round(oiBase * bellC * putBias * strikeNoise)));

    // smile: base + m·ln(K/S) + s·ln(K/S)² — IV SIMÉTRICA entre calls e puts
    // (prêmio de IV em puts reduziria o gamma deles e empurria o flip acima
    // do spot; com IV simétrica o flip cai logo abaixo do spot, realista)
    const smile = baseIV + m * x + s2 * x * x;
    callIV.push(clamp(smile + (rng() - 0.5) * 0.008, IV_MIN, IV_MAX));
    putIV.push(clamp(smile + (rng() - 0.5) * 0.008, IV_MIN, IV_MAX));
  }

  return { strikes, callOI, putOI, callIV, putIV, spot, baseIV };
}

/**
 * GEX por strike = gamma(BS) × OI × spot² × 0.01.
 * Dealer convention: callGex positivo, putGex negativo. T fixo = 14/252
 * (vencimento sintético de 14 dias corridos).
 * Também expõe vanna/charm líquidos por strike, com a mesma convenção de
 * sinal (calls +, puts −) e normalização p/ leitura em "dólar por unidade":
 * vanna × OI × S × 0.01 (≈$ por 1% de vol) e charm × OI × S × 0.01 (≈$/dia).
 */
export function gexPerStrike(chain: QuantChain, tick: number): GexRow[] {
  const { strikes, callOI, putOI, callIV, putIV, spot } = chain;
  if (strikes.length === 0 || !(spot > 0)) return [];

  const S2 = spot * spot;
  const rows: GexRow[] = [];
  for (let i = 0; i < strikes.length; i++) {
    const k = roundToTick(strikes[i] ?? 0, tick);
    const callGex = bsGamma(spot, k, callIV[i] ?? 0, EXPIRY_T) * (callOI[i] ?? 0) * S2 * 0.01;
    const putGex = -bsGamma(spot, k, putIV[i] ?? 0, EXPIRY_T) * (putOI[i] ?? 0) * S2 * 0.01;
    const callVanna = bsVanna(spot, k, callIV[i] ?? 0, EXPIRY_T) * (callOI[i] ?? 0) * spot * 0.01;
    const putVanna = -bsVanna(spot, k, putIV[i] ?? 0, EXPIRY_T) * (putOI[i] ?? 0) * spot * 0.01;
    const callCharm = bsCharm(spot, k, callIV[i] ?? 0, EXPIRY_T) * (callOI[i] ?? 0) * spot * 0.01;
    const putCharm = -bsCharm(spot, k, putIV[i] ?? 0, EXPIRY_T) * (putOI[i] ?? 0) * spot * 0.01;
    rows.push({
      strike: k,
      callGex,
      putGex,
      net: callGex + putGex,
      netVanna: callVanna + putVanna,
      netCharm: callCharm + putCharm,
    });
  }
  return rows;
}

/** Soma do GEX líquido (dealer convention). */
export function netGex(rows: { net: number }[]): number {
  let sum = 0;
  for (const r of rows) sum += r.net;
  return sum;
}

// ── Paredes de gamma + perfil agregado do DOM ───────────────────────────────

/** "Parede" de gamma: strike com net gamma relevante (dealer convention). */
export interface GreekWall {
  strike: number;
  netGamma: number;
}

/**
 * Maiores "paredes" de gamma institucional por |net gamma|, ordenadas desc.
 * Só entra strike com net ≠ 0; no máximo topN (default 3).
 */
export function gammaWalls(rows: GexRow[], topN = 3): GreekWall[] {
  const eligible = rows.filter((r) => r.net !== 0);
  eligible.sort((a, b) => Math.abs(b.net) - Math.abs(a.net));
  return eligible.slice(0, Math.max(0, topN)).map((r) => ({ strike: r.strike, netGamma: r.net }));
}

/** Perfil de derivativos agregado p/ o rail/chip do DOM (tudo pré-calculado). */
export interface DomGexProfile {
  rows: GexRow[];
  /** gamma flip (mesmo contrato de flipSpot); null se não cruzar zero */
  flip: number | null;
  /** maior |net gamma| por strike (p/ escala de cor/largura) */
  maxAbsGamma: number;
  /** maior |netVanna| por strike */
  maxAbsVanna: number;
  /** maior |netCharm| por strike */
  maxAbsCharm: number;
  walls: GreekWall[];
}

/** gexPerStrike + flipSpot + gammaWalls + máximos |.| de cada métrica. */
export function domGexProfile(chain: QuantChain, tick: number): DomGexProfile {
  const rows = gexPerStrike(chain, tick);
  let maxAbsGamma = 0;
  let maxAbsVanna = 0;
  let maxAbsCharm = 0;
  for (const r of rows) {
    maxAbsGamma = Math.max(maxAbsGamma, Math.abs(r.net));
    maxAbsVanna = Math.max(maxAbsVanna, Math.abs(r.netVanna));
    maxAbsCharm = Math.max(maxAbsCharm, Math.abs(r.netCharm));
  }
  return { rows, flip: flipSpot(chain, tick), maxAbsGamma, maxAbsVanna, maxAbsCharm, walls: gammaWalls(rows, 3) };
}

// ── Gamma heatmap (matriz strike × vencimento) ───────────────────────────────

/** Vencimentos sintéticos do heatmap de gamma (dias corridos). */
export const HEAT_EXPIRIES: { label: string; days: number }[] = [
  { label: '1D', days: 1 },
  { label: '1S', days: 7 },
  { label: '2S', days: 14 },
  { label: '1M', days: 30 },
];

/** Célula da matriz: net gamma (call − put, dealer convention) num vencimento. */
export interface GexHeatCell {
  /** índice do vencimento em HEAT_EXPIRIES */
  e: number;
  net: number;
  call: number;
  put: number;
}

export interface GexHeatRow {
  strike: number;
  cells: GexHeatCell[];
  /** net gamma somado sobre todos os vencimentos */
  total: number;
}

export interface GexHeatmap {
  rows: GexHeatRow[];
  /** maior |gamma| de célula (p/ escala de cor) */
  maxAbs: number;
  /** strike mais próximo do spot */
  atmIdx: number;
}

/**
 * Matriz de gamma por strike × vencimento: gamma(BS, T por vencimento) × OI ×
 * S² × 0.01, calls positivos e puts negativos (dealer convention). Vencimentos
 * curtos concentram gamma no ATM — o gradiente das colunas mostra isso.
 */
export function gammaHeatmap(chain: QuantChain, tick: number): GexHeatmap {
  const { strikes, callOI, putOI, callIV, putIV, spot } = chain;
  const empty: GexHeatmap = { rows: [], maxAbs: 0, atmIdx: 0 };
  if (strikes.length === 0 || !(spot > 0)) return empty;

  const S2 = spot * spot;
  const rows: GexHeatRow[] = [];
  let maxAbs = 0;
  let atmIdx = 0;
  let bestD = Infinity;

  for (let i = 0; i < strikes.length; i++) {
    const k = roundToTick(strikes[i] ?? 0, tick);
    const cells: GexHeatCell[] = [];
    let total = 0;
    for (let e = 0; e < HEAT_EXPIRIES.length; e++) {
      const T = HEAT_EXPIRIES[e].days / 252;
      const call = bsGamma(spot, k, callIV[i] ?? 0, T) * (callOI[i] ?? 0) * S2 * 0.01;
      const put = -bsGamma(spot, k, putIV[i] ?? 0, T) * (putOI[i] ?? 0) * S2 * 0.01;
      const net = call + put;
      cells.push({ e, net, call, put });
      total += net;
      maxAbs = Math.max(maxAbs, Math.abs(call), Math.abs(put), Math.abs(net));
    }
    rows.push({ strike: k, cells, total });
    const d = Math.abs(k - spot);
    if (d < bestD) {
      bestD = d;
      atmIdx = i;
    }
  }
  return { rows, maxAbs, atmIdx };
}

/**
 * Spot onde o GEX líquido TOTAL ≈ 0 (gamma flip): recalcula o GEX agregado da
 * cadeia assumindo spot hipotético = K (OI/IV fixos), suaviza o perfil
 * (média móvel 3 pts p/ matar ruído de strike único) e interpola linearmente
 * entre os strikes com troca de sinal. Retorna o cruzamento MAIS PRÓXIMO do
 * spot atual; null se o perfil não cruzar zero na cadeia. Consistente com
 * netGex() no spot atual (mesma fórmula, S = chain.spot).
 */
export function flipSpot(chain: QuantChain, tick: number): number | null {
  const { strikes, callOI, putOI, callIV, putIV, spot } = chain;
  if (strikes.length === 0) return null;

  const netAt = (S: number): number => {
    if (!(S > 0)) return 0;
    const S2 = S * S;
    let sum = 0;
    for (let i = 0; i < strikes.length; i++) {
      const k = strikes[i] ?? 0;
      sum += bsGamma(S, k, callIV[i] ?? 0, EXPIRY_T) * (callOI[i] ?? 0) * S2 * 0.01;
      sum -= bsGamma(S, k, putIV[i] ?? 0, EXPIRY_T) * (putOI[i] ?? 0) * S2 * 0.01;
    }
    return sum;
  };

  const nets = strikes.map((_, i) => netAt(strikes[i] ?? 0));
  const smooth = nets.map((_, i) => {
    const a = nets[Math.max(0, i - 1)] ?? 0;
    const b = nets[i] ?? 0;
    const c = nets[Math.min(nets.length - 1, i + 1)] ?? 0;
    return 0.25 * a + 0.5 * b + 0.25 * c;
  });

  let best: number | null = null;
  let bestD = Infinity;
  for (let i = 0; i + 1 < smooth.length; i++) {
    const na = smooth[i] ?? 0;
    const nb = smooth[i + 1] ?? 0;
    if (na > 0 !== nb > 0 && na !== nb) {
      const ka = strikes[i] ?? 0;
      const kb = strikes[i + 1] ?? 0;
      const denom = Math.abs(na) + Math.abs(nb);
      const t = denom > 0 ? Math.abs(na) / denom : 0.5;
      const p = roundToTick(ka + (kb - ka) * t, tick);
      const d = Math.abs(p - spot);
      if (d < bestD) {
        bestD = d;
        best = p;
      }
    }
  }
  return best;
}

/**
 * Strike de max pain: minimiza Σ callOI·max(0,K−Ki) + Σ putOI·max(0,Ki−K).
 * Cadeia vazia → 0.
 */
export function maxPain(chain: QuantChain, tick: number): number {
  const { strikes, callOI, putOI } = chain;
  if (strikes.length === 0) return 0;

  let best = strikes[0] ?? 0;
  let bestPain = Infinity;
  for (const k of strikes) {
    let pain = 0;
    for (let i = 0; i < strikes.length; i++) {
      const ki = strikes[i] ?? 0;
      pain += (callOI[i] ?? 0) * Math.max(0, k - ki);
      pain += (putOI[i] ?? 0) * Math.max(0, ki - k);
    }
    if (pain < bestPain) {
      bestPain = pain;
      best = k;
    }
  }
  return roundToTick(best, tick);
}

/** ATR(14): média dos TR das últimas 14 velas (TR usa o close anterior). */
export function atr14(candles: Candle[]): number {
  const n = candles.length;
  if (n < 2) return 0;

  let sum = 0;
  let count = 0;
  const start = Math.max(1, n - 14);
  for (let i = start; i < n; i++) {
    const c = candles[i];
    const p = candles[i - 1];
    if (!c || !p) continue;
    const tr = Math.max(c.h - c.l, Math.abs(c.h - p.c), Math.abs(c.l - p.c));
    if (!Number.isFinite(tr)) continue;
    sum += tr;
    count++;
  }
  return count > 0 ? sum / count : 0;
}

/**
 * Vol. realizada em %: desvio-padrão (amostral) dos retornos log dos closes
 * das velas × 100 (por unidade de tempo da série — rótulo no UI: "vol. realizada").
 */
export function realizedVolPct(candles: Candle[]): number {
  const arr = candles.length > 120 ? candles.slice(-120) : candles;

  const rets: number[] = [];
  for (let i = 1; i < arr.length; i++) {
    const c = arr[i];
    const p = arr[i - 1];
    if (!c || !p || !(c.c > 0) || !(p.c > 0)) continue;
    const r = Math.log(c.c / p.c);
    if (Number.isFinite(r)) rets.push(r);
  }
  if (rets.length < 2) return 0;

  const n = rets.length;
  let mean = 0;
  for (const r of rets) mean += r;
  mean /= n;

  let varSum = 0;
  for (const r of rets) varSum += (r - mean) ** 2;
  const std = Math.sqrt(varSum / (n - 1));
  return std * 100;
}
