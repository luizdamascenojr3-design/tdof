// ─────────────────────────────────────────────────────────────────────────────
// Renderer WebGL do motor de fluxo (rodada 5).
//
// Canvas transparente sobreposto ao Canvas2D do gráfico, desenhando:
//  1. Heatmap de liquidez (HeatMapRing do WebWorker) — textura de dados
//     RGBA8 (R = ask, G = bid) amostrada por fragment shader com rampa de
//     calor equivalente à do Canvas2D (raiz quadrada + realce de paredes);
//  2. Bolhas de volume (raio ∝ volume agregado por nível);
//  3. Sinais de fluxo (absorção/exaustão/iceberg/spoofing) com halo pulsante.
//
// Tudo em WebGL1 (compatibilidade máxima). Se o contexto não existir, `ok`
// fica false e o ClusterChart mantém o pipeline Canvas2D original.
// ─────────────────────────────────────────────────────────────────────────────

import type { FlowSignalKind, HeatRingPayload } from '@/lib/market/flow';

// ── cena (coordenadas em px lógicos do canvas 2D) ───────────────────────────
export interface GlBubble {
  x: number;
  y: number;
  r: number;
  /** rgb 0..1 */
  color: [number, number, number];
  alpha: number;
  /** 1 = aro (trade grande), 0 = disco com glow */
  hollow: number;
}

export interface HeatGlScene {
  ring: HeatRingPayload | null;
  /** px (lógico) da borda ESQUERDA da coluna 0 do anel */
  x0: number;
  /** largura da coluna em px */
  dx: number;
  /** px (lógico) do topo da faixa da row 0 (tick colBase) */
  y0: number;
  /** altura de cada row (tick) em px */
  dy: number;
  /** nº de colunas usadas (replay corta colunas futuras) */
  colsUsed: number;
  /**
   * px (lógico) onde o anel COMEÇA a pintar (borda viva). Colunas mais antigas
   * ficam por conta do caminho 2D — o anel cobre só ±160 ticks ao redor do
   * preço corrente, então deixá-lo pintar o histórico inteiro apagava o resto
   * do heatmap (comportamento "heatmap vazio" da rodada 5).
   * Undefined = pinta o rect de plot inteiro (comportamento antigo).
   */
  ringFromX?: number;
  /** alpha global do heatmap */
  heatAlpha: number;
  bubbles: GlBubble[];
  /** px do rect de plot (recorte do heatmap) */
  plotX: number;
  plotY: number;
  plotW: number;
  plotH: number;
}

// ── cores (mesma paleta ATAS do terminal) ───────────────────────────────────
const TEAL: [number, number, number] = [0.031, 0.6, 0.506]; // #089981
const RED: [number, number, number] = [0.949, 0.22, 0.353]; // #f2385a
const AMBER: [number, number, number] = [0.91, 0.659, 0.329]; // #e8a854
const STEEL: [number, number, number] = [0.275, 0.510, 0.706]; // #4682b4
const CYAN: [number, number, number] = [0.161, 0.714, 0.965]; // #29b6f6
const ORANGE: [number, number, number] = [1.0, 0.427, 0.227]; // #ff6d3a

export function signalColor(kind: FlowSignalKind): [number, number, number] {
  if (kind === 'absorption') return AMBER;
  if (kind === 'exhaustion') return STEEL;
  if (kind === 'spoof') return ORANGE;
  return CYAN; // iceberg
}

// ── shaders ──────────────────────────────────────────────────────────────────
const HEAT_VS = `
attribute vec2 a_pos;
uniform vec2 u_res;
varying vec2 v_px;
void main() {
  v_px = a_pos;
  vec2 ndc = vec2(a_pos.x / u_res.x * 2.0 - 1.0, 1.0 - a_pos.y / u_res.y * 2.0);
  gl_Position = vec4(ndc, 0.0, 1.0);
}
`;

const HEAT_FS = `
precision mediump float;
varying vec2 v_px;
uniform float u_x0;
uniform float u_dx;
uniform float u_cols;
uniform float u_colsUsed;
uniform float u_y0;
uniform float u_dy;
uniform float u_rows;
uniform sampler2D u_tex;
uniform float u_maxQ;
uniform float u_alpha;
uniform vec4 u_clip; // x, y, w, h (device px)
void main() {
  if (v_px.x < u_clip.x || v_px.x > u_clip.x + u_clip.z) discard;
  if (v_px.y < u_clip.y || v_px.y > u_clip.y + u_clip.w) discard;
  float col = floor((v_px.x - u_x0) / u_dx);
  float row = floor((v_px.y - u_y0) / u_dy);
  if (col < 0.0 || col >= u_colsUsed || row < 0.0 || row >= u_rows) discard;
  vec2 uv = vec2((col + 0.5) / u_cols, (row + 0.5) / u_rows);
  vec4 t = texture2D(u_tex, uv);
  float bid = t.g;
  float ask = t.r;
  float q = max(bid, ask);
  if (q <= 0.004) discard;
  float frac = clamp(q, 0.0, 1.0);
  float heat = 0.05 + 0.75 * sqrt(frac);
  if (frac > 0.72) heat = min(0.95, heat + 0.12); // paredes esquentam
  vec3 c = bid >= ask ? vec3(0.031, 0.6, 0.506) : vec3(0.949, 0.22, 0.353);
  gl_FragColor = vec4(c, heat * u_alpha);
}
`;

const PTS_VS = `
attribute vec2 a_corner;
attribute vec2 a_center;
attribute float a_radius;
attribute vec3 a_color;
attribute float a_alpha;
attribute float a_hollow;
uniform vec2 u_res;
varying vec2 v_corner;
varying vec3 v_color;
varying float v_alpha;
varying float v_hollow;
void main() {
  v_corner = a_corner;
  v_color = a_color;
  v_alpha = a_alpha;
  v_hollow = a_hollow;
  vec2 pos = a_center + a_corner * a_radius;
  vec2 ndc = vec2(pos.x / u_res.x * 2.0 - 1.0, 1.0 - pos.y / u_res.y * 2.0);
  gl_Position = vec4(ndc, 0.0, 1.0);
}
`;

const PTS_FS = `
precision mediump float;
varying vec2 v_corner;
varying vec3 v_color;
varying float v_alpha;
varying float v_hollow;
void main() {
  float d = length(v_corner);
  float a;
  if (v_hollow > 0.5) {
    a = smoothstep(0.72, 0.9, d) * (1.0 - smoothstep(0.9, 1.0, d));
  } else {
    a = pow(max(0.0, 1.0 - d), 1.6) * 0.7;
    a += smoothstep(0.82, 0.94, d) * (1.0 - smoothstep(0.94, 1.0, d)) * 0.9;
  }
  gl_FragColor = vec4(v_color, a * v_alpha);
}
`;

function compile(gl: WebGLRenderingContext, vs: string, fs: string): WebGLProgram | null {
  const mk = (type: number, src: string): WebGLShader | null => {
    const sh = gl.createShader(type);
    if (!sh) return null;
    gl.shaderSource(sh, src);
    gl.compileShader(sh);
    if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) {
      console.warn('[heat-gl] shader:', gl.getShaderInfoLog(sh));
      gl.deleteShader(sh);
      return null;
    }
    return sh;
  };
  const v = mk(gl.VERTEX_SHADER, vs);
  const f = mk(gl.FRAGMENT_SHADER, fs);
  if (!v || !f) return null;
  const p = gl.createProgram();
  if (!p) return null;
  gl.attachShader(p, v);
  gl.attachShader(p, f);
  gl.linkProgram(p);
  if (!gl.getProgramParameter(p, gl.LINK_STATUS)) {
    console.warn('[heat-gl] link:', gl.getProgramInfoLog(p));
    return null;
  }
  return p;
}

export class HeatGl {
  ok = false;
  private gl: WebGLRenderingContext | null = null;
  private canvas: HTMLCanvasElement;
  private heatProg: WebGLProgram | null = null;
  private ptsProg: WebGLProgram | null = null;
  private quadBuf: WebGLBuffer | null = null;
  private ptsBuf: WebGLBuffer | null = null;
  private tex: WebGLTexture | null = null;
  private texCols = 0;
  private texRows = 0;
  private texFilter: number = 0;
  private dpr = 1;
  private unHeat: Record<string, WebGLUniformLocation | null> = {};
  private unPts: Record<string, WebGLUniformLocation | null> = {};
  private aHeat: number = -1;
  private aPts: Record<string, number> = {};

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const gl = (canvas.getContext('webgl', {
      alpha: true,
      premultipliedAlpha: false,
      antialias: false,
      depth: false,
      stencil: false,
      // preserva o buffer p/ composição no screenshot da toolbar
      preserveDrawingBuffer: true,
    }) ?? canvas.getContext('experimental-webgl')) as WebGLRenderingContext | null;
    if (!gl) return;
    this.gl = gl;

    this.heatProg = compile(gl, HEAT_VS, HEAT_FS);
    this.ptsProg = compile(gl, PTS_VS, PTS_FS);
    if (!this.heatProg || !this.ptsProg) return;

    // quad do plot (dois triângulos, y crescendo p/ baixo)
    this.quadBuf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.quadBuf);
    gl.bufferData(
      gl.ARRAY_BUFFER,
      new Float32Array([0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1]),
      gl.STATIC_DRAW,
    );
    this.ptsBuf = gl.createBuffer();
    this.tex = gl.createTexture();

    this.unHeat = {
      res: gl.getUniformLocation(this.heatProg, 'u_res'),
      x0: gl.getUniformLocation(this.heatProg, 'u_x0'),
      dx: gl.getUniformLocation(this.heatProg, 'u_dx'),
      cols: gl.getUniformLocation(this.heatProg, 'u_cols'),
      colsUsed: gl.getUniformLocation(this.heatProg, 'u_colsUsed'),
      y0: gl.getUniformLocation(this.heatProg, 'u_y0'),
      dy: gl.getUniformLocation(this.heatProg, 'u_dy'),
      rows: gl.getUniformLocation(this.heatProg, 'u_rows'),
      tex: gl.getUniformLocation(this.heatProg, 'u_tex'),
      maxQ: gl.getUniformLocation(this.heatProg, 'u_maxQ'),
      alpha: gl.getUniformLocation(this.heatProg, 'u_alpha'),
      clip: gl.getUniformLocation(this.heatProg, 'u_clip'),
    };
    this.aHeat = gl.getAttribLocation(this.heatProg, 'a_pos');
    this.unPts = {
      res: gl.getUniformLocation(this.ptsProg, 'u_res'),
    };
    for (const n of ['a_corner', 'a_center', 'a_radius', 'a_color', 'a_alpha', 'a_hollow']) {
      this.aPts[n] = gl.getAttribLocation(this.ptsProg, n);
    }

    gl.disable(gl.DEPTH_TEST);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    canvas.addEventListener('webglcontextlost', this.onLost);
    this.ok = true;
  }

  private onLost = (e: Event) => {
    e.preventDefault();
    this.ok = false;
  };

  resize(w: number, h: number, dpr: number): void {
    if (!this.ok || !this.gl) return;
    this.dpr = dpr;
    const cw = Math.max(1, Math.round(w * dpr));
    const ch = Math.max(1, Math.round(h * dpr));
    if (this.canvas.width !== cw || this.canvas.height !== ch) {
      this.canvas.width = cw;
      this.canvas.height = ch;
    }
    this.gl.viewport(0, 0, cw, ch);
  }

  render(scene: HeatGlScene): void {
    const gl = this.gl;
    if (!this.ok || !gl) return;
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);

    // ── heatmap ─────────────────────────────────────────────────────────────
    const ring = scene.ring;
    if (ring && ring.cols > 0 && ring.rows > 0 && ring.data.length === ring.cols * ring.rows * 4) {
      this.uploadTex(ring);
      const dpr = this.dpr;
      const clip = [scene.plotX * dpr, scene.plotY * dpr, scene.plotW * dpr, scene.plotH * dpr];
      gl.useProgram(this.heatProg);
      gl.bindBuffer(gl.ARRAY_BUFFER, this.quadBuf);
      gl.enableVertexAttribArray(this.aHeat);
      gl.vertexAttribPointer(this.aHeat, 2, gl.FLOAT, false, 0, 0);
      // posições do quad em device px cobrindo o rect de plot
      gl.uniform2f(this.unHeat.res, this.canvas.width, this.canvas.height);
      // quad dinâmico cobrindo o rect de plot (6 vértices, custo desprezível).
      // Com ringFromX, o anel pinta só a borda viva (colunas recentes).
      const edgeX =
        scene.ringFromX !== undefined ? Math.max(clip[0], scene.ringFromX * dpr) : clip[0];
      const qx = edgeX;
      const qy = clip[1];
      const qw = Math.max(1, clip[0] + clip[2] - edgeX);
      const qh = clip[3];
      gl.bufferData(
        gl.ARRAY_BUFFER,
        new Float32Array([
          qx, qy, qx + qw, qy, qx + qw, qy + qh,
          qx, qy, qx + qw, qy + qh, qx, qy + qh,
        ]),
        gl.DYNAMIC_DRAW,
      );
      gl.vertexAttribPointer(this.aHeat, 2, gl.FLOAT, false, 0, 0);
      gl.uniform1f(this.unHeat.x0, scene.x0 * dpr);
      gl.uniform1f(this.unHeat.dx, Math.max(0.01, scene.dx * dpr));
      gl.uniform1f(this.unHeat.cols, ring.cols);
      gl.uniform1f(this.unHeat.colsUsed, Math.min(ring.cols, Math.max(0, scene.colsUsed)));
      gl.uniform1f(this.unHeat.y0, scene.y0 * dpr);
      gl.uniform1f(this.unHeat.dy, Math.max(0.001, scene.dy * dpr));
      gl.uniform1f(this.unHeat.rows, ring.rows);
      gl.uniform1f(this.unHeat.maxQ, ring.maxQ > 0 ? ring.maxQ : 1);
      gl.uniform1f(this.unHeat.alpha, scene.heatAlpha);
      gl.uniform4f(this.unHeat.clip, clip[0], clip[1], clip[2], clip[3]);
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, this.tex);
      gl.uniform1i(this.unHeat.tex, 0);
      gl.drawArrays(gl.TRIANGLES, 0, 6);
    }

    // ── bolhas + sinais ─────────────────────────────────────────────────────
    const pts = scene.bubbles;
    if (pts.length > 0) {
      const dpr = this.dpr;
      const f = new Float32Array(pts.length * 6 * 10);
      const CORNERS = [
        [-1, -1], [1, -1], [1, 1],
        [-1, -1], [1, 1], [-1, 1],
      ];
      let o = 0;
      for (const p of pts) {
        const cx = p.x * dpr;
        const cy = p.y * dpr;
        const r = Math.max(0.5, p.r * dpr);
        for (const [cu, cv] of CORNERS) {
          f[o] = cu;
          f[o + 1] = cv;
          f[o + 2] = cx;
          f[o + 3] = cy;
          f[o + 4] = r;
          f[o + 5] = p.color[0];
          f[o + 6] = p.color[1];
          f[o + 7] = p.color[2];
          f[o + 8] = p.alpha;
          f[o + 9] = p.hollow;
          o += 10;
        }
      }
      gl.useProgram(this.ptsProg);
      gl.bindBuffer(gl.ARRAY_BUFFER, this.ptsBuf);
      gl.bufferData(gl.ARRAY_BUFFER, f, gl.DYNAMIC_DRAW);
      const stride = 40;
      gl.enableVertexAttribArray(this.aPts.a_corner);
      gl.vertexAttribPointer(this.aPts.a_corner, 2, gl.FLOAT, false, stride, 0);
      gl.enableVertexAttribArray(this.aPts.a_center);
      gl.vertexAttribPointer(this.aPts.a_center, 2, gl.FLOAT, false, stride, 8);
      gl.enableVertexAttribArray(this.aPts.a_radius);
      gl.vertexAttribPointer(this.aPts.a_radius, 1, gl.FLOAT, false, stride, 16);
      gl.enableVertexAttribArray(this.aPts.a_color);
      gl.vertexAttribPointer(this.aPts.a_color, 3, gl.FLOAT, false, stride, 20);
      gl.enableVertexAttribArray(this.aPts.a_alpha);
      gl.vertexAttribPointer(this.aPts.a_alpha, 1, gl.FLOAT, false, stride, 32);
      gl.enableVertexAttribArray(this.aPts.a_hollow);
      gl.vertexAttribPointer(this.aPts.a_hollow, 1, gl.FLOAT, false, stride, 36);
      gl.uniform2f(this.unPts.res, this.canvas.width, this.canvas.height);
      gl.drawArrays(gl.TRIANGLES, 0, pts.length * 6);
    }
  }

  /** Sobe o anel como textura RGBA8 (re-aloca quando as dimensões mudam). */
  private uploadTex(ring: HeatRingPayload): void {
    const gl = this.gl;
    if (!gl || !this.tex) return;
    const needAlloc =
      !this.texAllocated || this.texCols !== ring.cols || this.texRows !== ring.rows;
    gl.bindTexture(gl.TEXTURE_2D, this.tex);
    const filter = this.pickFilter();
    if (needAlloc || filter !== this.texFilter) {
      if (needAlloc) {
        gl.texImage2D(
          gl.TEXTURE_2D, 0, gl.RGBA, ring.cols, ring.rows, 0,
          gl.RGBA, gl.UNSIGNED_BYTE, null,
        );
        this.texCols = ring.cols;
        this.texRows = ring.rows;
        this.texAllocated = true;
      }
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, filter);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, filter);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      this.texFilter = filter;
    }
    gl.texSubImage2D(
      gl.TEXTURE_2D, 0, 0, 0, ring.cols, ring.rows,
      gl.RGBA, gl.UNSIGNED_BYTE, ring.data,
    );
  }

  /** NEAREST quando as linhas têm ≥1.2px (células nítidas); LINEAR contra moiré. */
  private pickFilter(): number {
    const gl = this.gl;
    if (!gl) return 9728; // gl.NEAREST
    return this._lastRowHpx >= 1.2 ? gl.NEAREST : gl.LINEAR;
  }

  private _lastRowHpx = 4;
  private texAllocated = false;

  /** Informado pelo chart a cada frame (p/ anti-moiré). */
  setRowHpx(h: number): void {
    this._lastRowHpx = h;
  }

  dispose(): void {
    const gl = this.gl;
    if (!gl) return;
    this.canvas.removeEventListener('webglcontextlost', this.onLost);
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    this.ok = false;
    this.gl = null;
  }
}
