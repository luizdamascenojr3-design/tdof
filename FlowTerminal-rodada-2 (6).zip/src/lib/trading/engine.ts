'use client';

// ─────────────────────────────────────────────────────────────────────────────
// Motor de trading SIMULADO (client-side): ordens MKT/LMT, estratégia ATM
// (bracket alvo/stop em ticks com OCO), posição, PnL e log de execuções.
// Nenhum dado real de corretora — os fills são simulados com o fluxo do tape.
// ─────────────────────────────────────────────────────────────────────────────

import { create } from 'zustand';
import { toast } from '@/hooks/use-toast';
import { useTerminalStore } from '@/store/terminal';
import { fmtPrice } from '@/lib/market/format';
import { symbolMeta, type Trade } from '@/lib/market/types';

export type OrderSide = 'buy' | 'sell';
export type OrderRole = 'manual' | 'target' | 'stop';

export interface Order {
  id: number;
  side: OrderSide;
  /** manual = ordem do operador; target/stop = pernas da estratégia ATM */
  role: OrderRole;
  /** preço limite (LMT); null para gatilho puro */
  price: number | null;
  /** preço de disparo do stop (somente role === 'stop') */
  trigger: number | null;
  qty: number;
  t: number;
  /** par OCO (alvo↔stop compartilham o id) */
  ocoId?: number;
  /** ordem manual que gerou o bracket */
  parent?: number;
}

export interface Fill {
  id: number;
  t: number;
  side: OrderSide;
  qty: number;
  price: number;
  role: OrderRole;
  /** PnL realizado neste fill (quando reduz/inverte posição) */
  pnl: number;
}

interface Position {
  /** positivo = comprado, negativo = vendido */
  qty: number;
  avg: number;
}

interface TradingState {
  /** lote selecionado (contratos por ordem) */
  qty: number;
  /** alvo da ATM em ticks (0 = desligado) */
  atmTarget: number;
  /** stop da ATM em ticks (0 = desligado) */
  atmStop: number;

  orders: Order[];
  fills: Fill[];
  position: Position;
  realizedPnl: number;

  setQty: (q: number) => void;
  setAtm: (p: Partial<{ atmTarget: number; atmStop: number }>) => void;

  /** arma (ou cancela, se já existir) uma LMT no preço */
  armLmt: (side: OrderSide, price: number) => void;
  /** ordem a mercado usando o book atual */
  placeMkt: (side: OrderSide) => void;
  cancelOrder: (id: number) => void;
  cancelAll: () => void;
  /** zera posição a mercado + cancela todas as ordens */
  flatten: () => void;
  /** chamado a cada trade do tape p/ simular fills */
  onTrade: (t: Trade) => void;
  /** troca de instrumento: zera ordens/posição */
  resetForSymbol: () => void;
}

let nextOrderId = 1;
let nextFillId = 1;

function tickOf(): number {
  return symbolMeta(useTerminalStore.getState().symbol).tick;
}

/** Aplica um fill à posição e devolve posição nova + PnL realizado. */
function applyFill(
  pos: Position,
  side: OrderSide,
  qty: number,
  price: number,
): { position: Position; realized: number } {
  const signed = side === 'buy' ? qty : -qty;
  const newQty = pos.qty + signed;
  let realized = 0;

  const opposite = pos.qty !== 0 && Math.sign(signed) !== Math.sign(pos.qty);
  if (opposite) {
    const closing = Math.min(Math.abs(pos.qty), Math.abs(signed));
    realized = (price - pos.avg) * closing * Math.sign(pos.qty);
  }

  let newAvg = pos.avg;
  if (newQty === 0) {
    newAvg = 0;
  } else if (pos.qty === 0 || !opposite) {
    newAvg = (pos.avg * Math.abs(pos.qty) + price * qty) / Math.abs(newQty);
  } else if (Math.abs(newQty) < Math.abs(signed)) {
    // posição virou (flip): saldo restante abre ao preço do fill
    newAvg = price;
  }
  // se apenas reduziu sem fechar, mantém o preço médio

  return { position: { qty: newQty, avg: newAvg }, realized };
}

/** PnL aberto em pontos × contrato (sinal = lado da posição). */
export function unrealizedPnl(pos: Position, last: number | null | undefined): number {
  if (!pos.qty || !last) return 0;
  return (last - pos.avg) * pos.qty;
}

export const useTradingStore = create<TradingState>((set, get) => {
  /** Executa uma ordem a um preço conhecido e atualiza estado + toasts. */
  const execFill = (o: Order, price: number) => {
    const st = get();
    const { position, realized } = applyFill(st.position, o.side, o.qty, price);
    const fill: Fill = {
      id: nextFillId++,
      t: Date.now(),
      side: o.side,
      qty: o.qty,
      price,
      role: o.role,
      pnl: realized,
    };

    let orders = st.orders.filter((x) => x.id !== o.id);

    // OCO: preencheu alvo ou stop → cancela a perna irmã
    if (o.ocoId !== undefined) {
      orders = orders.filter((x) => x.ocoId !== o.ocoId);
    }

    // spawn do bracket ATM quando a ordem manual abre/engorda posição
    if (
      o.role === 'manual' &&
      position.qty !== 0 &&
      Math.sign(o.side === 'buy' ? o.qty : -o.qty) === Math.sign(position.qty) &&
      st.atmTarget > 0 &&
      st.atmStop > 0
    ) {
      const tick = tickOf();
      const dir = position.qty > 0 ? 1 : -1;
      const ocoId = nextOrderId++;
      const brQty = Math.abs(position.qty);
      orders = orders.concat(
        {
          id: nextOrderId++,
          side: position.qty > 0 ? 'sell' : 'buy',
          role: 'target',
          price: position.avg + dir * st.atmTarget * tick,
          trigger: null,
          qty: brQty,
          t: Date.now(),
          ocoId,
          parent: o.id,
        },
        {
          id: nextOrderId++,
          side: position.qty > 0 ? 'sell' : 'buy',
          role: 'stop',
          price: null,
          trigger: position.avg - dir * st.atmStop * tick,
          qty: brQty,
          t: Date.now(),
          ocoId,
          parent: o.id,
        },
      );
    }

    set({
      orders,
      fills: [fill, ...st.fills].slice(0, 120),
      position,
      realizedPnl: st.realizedPnl + realized,
    });

    const p = fmtPrice(price, tickOf());
    if (o.role === 'manual') {
      toast({
        title: `${o.side === 'buy' ? 'Compra' : 'Venda'} executada`,
        description: `${o.qty} @ ${p}${
          realized !== 0 ? ` · realizado ${realized > 0 ? '+' : ''}${Math.round(realized)} pts` : ''
        }`,
      });
    } else if (o.role === 'target') {
      toast({
        title: 'Alvo atingido',
        description: `${realized >= 0 ? '+' : ''}${Math.round(realized)} pts @ ${p}`,
      });
    } else {
      toast({
        title: 'Stop acionado',
        description: `${realized >= 0 ? '+' : ''}${Math.round(realized)} pts @ ${p}`,
      });
    }
  };

  /** preço de execução a mercado a partir do book (ou último). */
  const mktPrice = (side: OrderSide): number | null => {
    const m = useTerminalStore.getState();
    if (side === 'buy') {
      // menor ask (array DESC → último elemento)
      if (m.dom && m.dom.asks.length) return m.dom.asks[m.dom.asks.length - 1].p;
    } else if (m.dom && m.dom.bids.length) {
      return m.dom.bids[0].p;
    }
    return m.session?.last ?? null;
  };

  return {
    qty: 1,
    atmTarget: 100,
    atmStop: 100,
    orders: [],
    fills: [],
    position: { qty: 0, avg: 0 },
    realizedPnl: 0,

    setQty: (q) => set({ qty: Math.max(1, Math.min(999, Math.round(q) || 1)) }),
    setAtm: (p) =>
      set({
        atmTarget:
          p.atmTarget !== undefined ? Math.max(0, Math.round(p.atmTarget) || 0) : get().atmTarget,
        atmStop:
          p.atmStop !== undefined ? Math.max(0, Math.round(p.atmStop) || 0) : get().atmStop,
      }),

    armLmt: (side, price) => {
      // replay: operar exige mercado ao vivo
      if (useTerminalStore.getState().replay.active) {
        toast({
          title: 'Replay ativo',
          description: 'Volte ao vivo para operar (sair do replay).',
        });
        return;
      }
      const st = get();
      const existing = st.orders.find(
        (o) => o.role === 'manual' && o.side === side && o.price === price,
      );
      if (existing) {
        set({ orders: st.orders.filter((o) => o.id !== existing.id) });
        return;
      }
      const order: Order = {
        id: nextOrderId++,
        side,
        role: 'manual',
        price,
        trigger: null,
        qty: st.qty,
        t: Date.now(),
      };
      set({ orders: st.orders.concat(order) });
    },

    placeMkt: (side) => {
      // replay: operar exige mercado ao vivo
      if (useTerminalStore.getState().replay.active) {
        toast({
          title: 'Replay ativo',
          description: 'Volte ao vivo para operar (sair do replay).',
        });
        return;
      }
      const price = mktPrice(side);
      if (price === null) return;
      execFill(
        {
          id: nextOrderId++,
          side,
          role: 'manual',
          price: null,
          trigger: null,
          qty: get().qty,
          t: Date.now(),
        },
        price,
      );
    },

    cancelOrder: (id) => set((st) => ({ orders: st.orders.filter((o) => o.id !== id) })),

    cancelAll: () => {
      const n = get().orders.length;
      if (!n) return;
      set({ orders: [] });
      toast({ title: 'Ordens canceladas', description: `${n} ordem(ns) removida(s) da escada.` });
    },

    flatten: () => {
      const st = get();
      const open = st.position.qty;
      if (open) {
        const side = open > 0 ? 'sell' : 'buy';
        const price = mktPrice(side);
        if (price !== null) {
          execFill(
            {
              id: nextOrderId++,
              side,
              role: 'manual',
              price: null,
              trigger: null,
              qty: Math.abs(open),
              t: Date.now(),
            },
            price,
          );
        }
      }
      if (get().orders.length) set({ orders: [] });
    },

    onTrade: (t) => {
      // replay: o mercado exibido é o passado — fills congelados até voltar ao vivo
      if (useTerminalStore.getState().replay.active) return;
      const st = get();
      if (!st.orders.length) return;
      for (const o of st.orders) {
        if (o.role === 'stop') {
          if (o.trigger === null) continue;
          const hit = o.side === 'sell' ? t.p <= o.trigger : t.p >= o.trigger;
          if (hit) execFill(o, o.trigger);
        } else if (o.price !== null) {
          const hit = o.side === 'buy' ? t.p <= o.price : t.p >= o.price;
          if (hit) execFill(o, o.price);
        }
      }
    },

    resetForSymbol: () => {
      if (get().orders.length || get().position.qty !== 0) {
        set({ orders: [], position: { qty: 0, avg: 0 } });
        toast({
          title: 'Posição zerada',
          description: 'Troca de instrumento — ordens e posição limpas.',
        });
      }
    },
  };
});

// ── integração com o fluxo de mercado ───────────────────────────────────────

let started = false;

/**
 * Liga o motor ao store de mercado: cada trade do tape passa a testar fills
 * e a troca de símbolo reseta ordens/posição. Idempotente.
 */
export function initTradingEngine() {
  if (started || typeof window === 'undefined') return;
  started = true;
  useTerminalStore.subscribe((st, prev) => {
    if (st.lastTrade && st.lastTrade !== prev.lastTrade) {
      useTradingStore.getState().onTrade(st.lastTrade);
    }
    if (st.symbol !== prev.symbol) {
      useTradingStore.getState().resetForSymbol();
    }
  });
  // debug temporário (verificação no browser)
  if (process.env.NODE_ENV !== 'production') {
    (window as unknown as Record<string, unknown>).__trading = useTradingStore;
    (window as unknown as Record<string, unknown>).__market = useTerminalStore;
  }
}
