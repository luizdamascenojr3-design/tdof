import { create } from 'zustand';
import type { BarType } from '@/lib/market/bars';
import type { DomL3Snapshot, FlowSignal, MboStats } from '@/lib/market/flow';
import type {
  Candle,
  DomSnapshot,
  HeatmapBucket,
  MboOp,
  SessionStats,
  SnapshotPayload,
  Timeframe,
  Trade,
} from '@/lib/market/types';

const MAX_CANDLES = 800;
const MAX_TAPE = 500;
const MAX_HEATMAP = 420;
/** sinais de fluxo mantidos no store (janela viva) */
const MAX_SIGNALS = 80;

/** parâmetro default de cada barra não-temporal (por tipo) */
export const DEFAULT_BAR_PARAMS: Record<Exclude<BarType, 'time'>, number> = {
  range: 10,
  reversal: 8,
  tick: 50,
  volume: 1000,
};

export type DisplayMode = 'bidask' | 'delta' | 'volume';
export type ProfileMode = 'visible' | 'session';
export type ConnStatus = 'connecting' | 'live' | 'offline';
/** tipo de gráfico (estilo ATAS: Cluster, Heatmap, Candles, Linha) */
export type ChartMode = 'clusters' | 'heatmap' | 'candles' | 'line';
export type DialogKind = 'none' | 'symbol' | 'indicators' | 'download' | 'sessions' | 'settings';

/** estado do replay de JOURNAL (sessão gravada, stream de eventos) */
export interface JournalUiState {
  active: boolean;
  /** snapshot inicial em trânsito */
  loading: boolean;
  sessionId: number | null;
  playing: boolean;
  speed: number;
  /** playhead em ms (tempo do mercado) */
  ts: number;
  startT: number;
  endT: number;
  /** 0..100 */
  pct: number;
  ended: boolean;
}
export const JOURNAL_SPEEDS = [0.5, 1, 2, 4, 8, 16] as const;
/** limite do log de operações de book (worker MBO) */
const MAX_MBO_LOG = 220;
/** métrica de derivativos projetada no rail do DOM (base DeepCharts) */
export type DomGexMode = 'gamma' | 'vanna' | 'charm';

/** estado do replay de mercado (barras reveladas progressivamente) */
export interface ReplayState {
  active: boolean;
  /** índice da última barra visível (inclusive) */
  idx: number;
  playing: boolean;
  /** barras por segundo */
  speed: number;
}
export const REPLAY_SPEEDS = [1, 2, 4, 8] as const;

/** entrada de patchSettings: qualquer setting + tipo/parâmetro de barra */
export type PatchSettingsInput = Omit<Partial<TerminalSettings>, 'barParams'> & {
  chartMode?: ChartMode;
  barType?: BarType;
  barParams?: Partial<Record<Exclude<BarType, 'time'>, number>>;
};

export interface TerminalSettings {
  /** conteúdo exibido nas células do cluster */
  displayMode: DisplayMode;
  showProfile: boolean;
  profileMode: ProfileMode;
  showImbalances: boolean;
  /** razão mínima p/ desequilíbrio diagonal (3 = 300%) */
  imbalanceRatio: number;
  showMaxLevels: boolean;
  /** volume mínimo para pintar a célula (0 = todos) */
  minCellVolume: number;
  /** tamanho mínimo para destacar trade grande no tape (0 = usar flag do servidor) */
  bigTradeSize: number;
  showDeltaPane: boolean;
  /** linha de VWAP da sessão sobreposta ao gráfico */
  showVwap: boolean;
  /** bolhas de trades (raio ∝ volume, agregadas por nível) — todos os modos */
  showHeatBubbles: boolean;
  /** volume mínimo p/ desenhar uma bolha (0 = todas) */
  bubbleMinVolume: number;
  /** ladder de profundidade (barras bid/ask do book atual) na borda direita */
  showDepthLadder: boolean;
  /** médias móveis sobrepostas */
  showEma9: boolean;
  showEma21: boolean;
  showSma50: boolean;
  /** painel de RSI (14) abaixo do painel de delta */
  showRSI: boolean;
  /** bandas de desvio-padrão da VWAP (±1σ e ±2σ) */
  showVwapBands: boolean;
  /** heatmap de GEX: bandas de gamma líquido por strike sobre o gráfico */
  showGexHeatmap: boolean;
  /** linha do gamma flip (spot onde o GEX líquido cruza zero) */
  showGexFlip: boolean;
  /** stream binário MBO (FlatBuffers) + WebWorker + WASM ligados */
  useMbo: boolean;
  /** renderização WebGL do heatmap/bolhas (fallback: Canvas2D) */
  useWebgl: boolean;
  /** bolhas de absorção/exaustão/iceberg sobre as fatias do footprint */
  showFlowSignals: boolean;
  /** rail de derivativos (gamma/vanna/charm) acoplado à escada do DOM */
  showDomGex: boolean;
  /** métrica exibida no rail do DOM */
  domGexMode: DomGexMode;
  /** strip de fluxo (absorção recente por nível) na escada do DOM */
  showDomFlowStrip: boolean;
  /** colunas MBO L3 na escada do DOM (Pulling/Stacking + Order Queue) */
  showDomMbo: boolean;
  /** tipo de barra do gráfico (tempo ou não-temporal) */
  barType: BarType;
  /** parâmetro por tipo de barra não-temporal (ticks, negócios, volume) */
  barParams: Record<Exclude<BarType, 'time'>, number>;
  /** bolhas de PROFUNDIDADE sobre o heatmap (raio ∝ book restante no bucket) */
  showDepthBubbles: boolean;
  /** % do máximo de profundidade p/ desenhar a bolha (30–90) */
  depthBubbleMinPct: number;
  /** strip de sessão (rodapé do widget de gráfico) */
  showSessionStrip: boolean;
  /** barra de status global (rodapé do terminal) */
  showStatusBar: boolean;
  /** barra de ferramentas de desenho (lateral esquerda do gráfico) */
  showDrawingToolbar: boolean;
  /** nº de gráficos anexados na área principal (1–2) */
  chartCount: 1 | 2;
}

interface TerminalState extends TerminalSettings {
  /** ids dos painéis abertos no workspace dockado (dockview) — espelho p/ menus */
  dockPanelIds: string[];
  status: ConnStatus;
  symbol: string;
  tf: Timeframe;
  /** modo de renderização do gráfico principal */
  chartMode: ChartMode;
  /**
   * MODO FOCO: oculta os painéis de dados (DOM/Tape/Quant) do workspace
   * dockado e dá 100% da área útil ao gráfico. Os painéis permanecem
   * MONTADOS (dockview setVisible) — retorno ao layout com um clique/tecla.
   */
  focusMode: boolean;
  setFocusMode: (on: boolean) => void;
  /** diálogo modal aberto (busca de símbolo / indicadores) */
  dialog: DialogKind;
  setDialog: (d: DialogKind) => void;

  // dados
  candles: Candle[];
  tape: Trade[];
  dom: DomSnapshot | null;
  session: SessionStats | null;
  lastTrade: Trade | null;
  /** buckets de heatmap de liquidez (alinhados ao tf, ordem crescente) */
  heatmap: HeatmapBucket[];
  /** sinais de fluxo recentes (absorção/exaustão/iceberg/spoof, ordem crescente de t) */
  flowSignals: FlowSignal[];
  /** estatísticas do stream MBO binário (worker → main) */
  mboStats: MboStats | null;
  /** pulling/stacking por nível (worker MBO → DOM L3, publicação 2Hz) */
  domL3: DomL3Snapshot | null;
  /** incrementado a cada mudança de dados; usado p/ redraw do canvas via rAF */
  dataVersion: number;

  // replay de mercado
  replay: ReplayState;
  enterReplay: () => void;
  exitReplay: () => void;
  patchReplay: (p: Partial<ReplayState>) => void;

  // journal (gravação + replay de sessões)
  /** gravação de journal em andamento (motor REC) */
  recording: boolean;
  journal: JournalUiState;
  /** log de operações de book (mais novas primeiro) */
  mboLog: MboOp[];
  setRecording: (on: boolean) => void;
  patchJournal: (p: Partial<JournalUiState>) => void;
  /** limpa o estado local do journal (sem tocar no serviço) */
  clearJournal: () => void;
  applyMboOps: (ops: MboOp[]) => void;

  // conexão / subscrição
  setStatus: (s: ConnStatus) => void;
  setSymbol: (s: string) => void;
  setTf: (t: Timeframe) => void;
  resetData: () => void;

  // aplicação de dados
  applySnapshot: (p: SnapshotPayload) => void;
  applyTrade: (t: Trade) => void;
  applyCandle: (c: Candle) => void;
  applyDom: (d: DomSnapshot) => void;
  applySession: (s: SessionStats) => void;
  applyHeatBucket: (b: HeatmapBucket) => void;
  /** adiciona sinais de fluxo emitidos pelo worker MBO */
  applyFlowSignals: (signals: FlowSignal[]) => void;
  /** atualiza estatísticas do stream MBO */
  setMboStats: (s: MboStats) => void;
  /** aplica o snapshot pulling/stacking do worker MBO (DOM L3) */
  setDomL3: (s: DomL3Snapshot) => void;
  setDockPanelIds: (ids: string[]) => void;

  // settings
  patchSettings: (p: PatchSettingsInput) => void;
}

export const useTerminalStore = create<TerminalState>((set, get) => ({
  status: 'connecting',
  symbol: 'WINFUT',
  tf: '1m',
  chartMode: 'clusters',
  focusMode: false,
  dialog: 'none',

  candles: [],
  tape: [],
  dom: null,
  session: null,
  lastTrade: null,
  heatmap: [],
  flowSignals: [],
  mboStats: null,
  domL3: null,
  dataVersion: 0,

  displayMode: 'bidask',
  showProfile: true,
  profileMode: 'session',
  showImbalances: true,
  imbalanceRatio: 3,
  showMaxLevels: true,
  minCellVolume: 0,
  bigTradeSize: 0,
  showDeltaPane: true,
  showVwap: true,
  showHeatBubbles: true,
  bubbleMinVolume: 0,
  showDepthLadder: true,
  showEma9: true,
  showEma21: false,
  showSma50: false,
  showRSI: false,
  showVwapBands: true,
  showGexHeatmap: true,
  showGexFlip: true,
  useMbo: true,
  useWebgl: true,
  showFlowSignals: true,
  showDomGex: true,
  domGexMode: 'gamma',
  showDomFlowStrip: true,
  showDomMbo: true,
  barType: 'time',
  barParams: { ...DEFAULT_BAR_PARAMS },
  showDepthBubbles: true,
  depthBubbleMinPct: 55,
  showSessionStrip: true,
  showStatusBar: true,
  showDrawingToolbar: true,
  chartCount: 1,

  dockPanelIds: ['chart-1', 'dom', 'tape', 'quant'],

  replay: { active: false, idx: 0, playing: false, speed: 2 },
  recording: false,
  journal: {
    active: false,
    loading: false,
    sessionId: null,
    playing: false,
    speed: 1,
    ts: 0,
    startT: 0,
    endT: 0,
    pct: 0,
    ended: false,
  },
  mboLog: [],

  setRecording: (recording) => set({ recording }),
  patchJournal: (p) => set((st) => ({ journal: { ...st.journal, ...p } })),
  clearJournal: () =>
    set((st) => ({
      journal: {
        active: false,
        loading: false,
        sessionId: null,
        playing: false,
        speed: st.journal.speed,
        ts: 0,
        startT: 0,
        endT: 0,
        pct: 0,
        ended: false,
      },
    })),
  applyMboOps: (ops) =>
    set((st) => {
      if (ops.length === 0) return {};
      // mais novas primeiro; dedup por seq de chegada não é necessário (ring)
      return { mboLog: [...ops.reverse(), ...st.mboLog].slice(0, MAX_MBO_LOG) };
    }),

  enterReplay: () =>
    set((st) => ({
      replay: {
        active: true,
        // começa em ~70% do histórico (mín. 10 barras visíveis)
        idx: Math.max(9, Math.floor(st.candles.length * 0.7)),
        playing: false,
        speed: st.replay.speed,
      },
    })),
  exitReplay: () =>
    set((st) => ({ replay: { ...st.replay, active: false, idx: 0, playing: false } })),
  patchReplay: (p) => set((st) => ({ replay: { ...st.replay, ...p } })),

  setDialog: (dialog) => set({ dialog }),
  setFocusMode: (focusMode) => set({ focusMode }),
  setStatus: (status) => set({ status }),
  setSymbol: (symbol) => {
    if (symbol === get().symbol) return;
    set({ symbol });
  },
  setTf: (tf) => {
    if (tf === get().tf) return;
    set({ tf });
  },
  resetData: () =>
    set({
      candles: [],
      tape: [],
      dom: null,
      session: null,
      lastTrade: null,
      heatmap: [],
      flowSignals: [],
      mboLog: [],
      domL3: null,
      dataVersion: get().dataVersion + 1,
    }),

  applySnapshot: (p) =>
    set((st) => ({
      candles: p.candles,
      tape: p.tape,
      dom: p.dom,
      session: p.session,
      heatmap: p.heatmap ?? [],
      lastTrade: p.tape[0] ?? null,
      dataVersion: st.dataVersion + 1,
    })),

  applyTrade: (t) =>
    set((st) => {
      // dedup: o snapshot pode conter o mesmo negócio que chega pelo EV_TRADE
      // (corrida entre entrar na sala e montar o snapshot)
      if (st.tape.some((x) => x.id === t.id)) return {};
      return {
        tape: [t, ...st.tape].slice(0, MAX_TAPE),
        lastTrade: t,
        dataVersion: st.dataVersion + 1,
      };
    }),

  applyCandle: (c) => {
    const st = get();
    const arr = st.candles;
    const last = arr.length ? arr[arr.length - 1] : null;
    let next: Candle[];
    if (last && c.t === last.t) {
      next = arr.slice(0, -1).concat(c);
    } else if (!last || c.t > last.t) {
      next = arr.concat(c);
      if (next.length > MAX_CANDLES) next = next.slice(next.length - MAX_CANDLES);
    } else {
      return; // vela antiga/fora de ordem — ignora
    }
    set({ candles: next, dataVersion: st.dataVersion + 1 });
  },

  applyDom: (dom) => set((st) => ({ dom, dataVersion: st.dataVersion + 1 })),
  applySession: (session) => set((st) => ({ session, dataVersion: st.dataVersion + 1 })),

  applyHeatBucket: (b) =>
    set((st) => {
      const arr = st.heatmap;
      const last = arr[arr.length - 1];
      let next: HeatmapBucket[];
      const idx = arr.findIndex((x) => x.t === b.t);
      if (idx >= 0) {
        next = arr.slice();
        next[idx] = b;
      } else if (!last || b.t > last.t) {
        next = arr.concat(b);
        if (next.length > MAX_HEATMAP) next = next.slice(next.length - MAX_HEATMAP);
      } else {
        return {}; // bucket antigo/fora de ordem — ignora
      }
      return { heatmap: next, dataVersion: st.dataVersion + 1 };
    }),

  applyFlowSignals: (signals) =>
    set((st) => {
      if (signals.length === 0) return {};
      const now = Date.now();
      const merged = [...st.flowSignals, ...signals]
        .filter((s) => s.until > now) // descarta expirados (TTL)
        .slice(-MAX_SIGNALS);
      return { flowSignals: merged, dataVersion: st.dataVersion + 1 };
    }),

  setMboStats: (mboStats) => set({ mboStats }),

  setDomL3: (domL3) => set({ domL3 }),

  /** espelho do estado do dock (dockview) para menus/habilitações da topbar */
  setDockPanelIds: (ids) => set({ dockPanelIds: ids }),

  patchSettings: (p) =>
    set((st) => {
      const { barParams, ...rest } = p;
      return {
        ...rest,
        ...(barParams ? { barParams: { ...st.barParams, ...barParams } } : null),
      } as Partial<TerminalState>;
    }),
}));

// ── Seletores auxiliares ─────────────────────────────────────────────────────
export const selectCandles = (s: TerminalState) => s.candles;
export const selectTape = (s: TerminalState) => s.tape;
export const selectDom = (s: TerminalState) => s.dom;
export const selectSession = (s: TerminalState) => s.session;

// probe de desenvolvimento: acesso ao store pelo console (não entra em prod)
if (typeof window !== 'undefined' && process.env.NODE_ENV !== 'production') {
  (window as unknown as Record<string, unknown>).__terminalStore = useTerminalStore;
}
