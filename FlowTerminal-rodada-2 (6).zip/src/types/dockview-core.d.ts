/**
 * Declarações do dockview-core v7.0.2 (bundle UMD vendored em
 * `public/vendor/dockview-core.min.noStyle.js`, carregado via <script> e
 * exposto em `window.dockviewCore`). Subtipagem deliberada: apenas o que o
 * terminal consome (createComponent factory, addPanel/remoção, serialização
 * e eventos de layout).
 */

interface DockviewThemeDef {
  name: string;
  className: string;
  colorScheme: string;
  tabGroupIndicator?: string;
}

/** Parâmetros recebidos por IContentRenderer.init (v7). */
interface DockviewPartInitParams {
  api: {
    setActive(): void;
    close(): void;
    setTitle(title: string): void;
  };
  containerApi: unknown;
  params: Record<string, unknown> | undefined;
  title?: string;
}

/**
 * Renderizador de conteúdo vanilla: dockview anexa `element` ao container e
 * chama `init` uma vez (re-executado se o painel for movido para popout).
 */
interface DockviewContentRenderer {
  readonly element: HTMLElement;
  init(parameters: DockviewPartInitParams): void;
  layout?(width: number, height: number): void;
  update?(event: unknown): void;
  focus?(): void;
  dispose?(): void;
}

interface DockviewPanelLike {
  readonly id: string;
  readonly api: {
    setActive(): void;
    close(): void;
    setTitle(title: string): void;
    /**
     * MODO FOCO: maximiza o grupo do painel — o gráfico ocupa 100% da área
     * e os painéis de dados permanecem MONTADOS (ocultos atrás do grupo
     * maximizado). Restaura instantaneamente com exitMaximized.
     */
    maximize(): void;
    exitMaximized(): void;
    isMaximized(): boolean;
  };
}

interface DockviewAddPanelOptions {
  id: string;
  component: string;
  title?: string;
  params?: Record<string, unknown>;
  position?:
    | { referencePanel?: string; direction?: 'left' | 'right' | 'above' | 'below' | 'within'; index?: number }
    | { floating?: boolean };
  initialWidth?: number;
  initialHeight?: number;
  floating?: boolean | Record<string, unknown>;
  tabComponent?: string;
}

interface DockviewDisposable {
  dispose(): void;
}

interface DockviewContainerApiLike {
  addPanel(options: DockviewAddPanelOptions): DockviewPanelLike;
  removePanel(panel: DockviewPanelLike): void;
  getPanel(id: string): DockviewPanelLike | undefined;
  readonly panels: readonly DockviewPanelLike[];
  fromJSON(data: unknown): void;
  toJSON(): unknown;
  clear(): void;
  dispose(): void;
  onDidAddPanel(sub: (e: { panel: DockviewPanelLike }) => void): DockviewDisposable;
  onDidRemovePanel(sub: (e: { panel: DockviewPanelLike }) => void): DockviewDisposable;
  onDidLayoutChange(sub: () => void): DockviewDisposable;
}

interface DockviewComponentOptions {
  /** fábrica de conteúdo v7: ({ id, name }) => IContentRenderer */
  createComponent(args: { id: string; name: string }): DockviewContentRenderer | undefined;
  theme?: DockviewThemeDef;
  noPanelsOverlay?: string;
  floatingGroupBounds?: 'boundedWithinContainer' | Record<string, number>;
  disableDnd?: boolean;
  className?: string;
}

interface DockviewCoreGlobal {
  DockviewComponent: new (
    element: HTMLElement,
    options: DockviewComponentOptions,
  ) => {
    api: DockviewContainerApiLike;
    dispose(): void;
    /** reestrutura o grid em árvore canônica (chamado pós build/reset) */
    orthogonalize?(): void;
  };
  themeDark: DockviewThemeDef;
}

interface Window {
  dockviewCore?: DockviewCoreGlobal;
}
