// ─────────────────────────────────────────────────────────────────────────────
// WebWorker do motor MBO (rodada 5 · base TapeDelta).
//
// Responsabilidades:
//  1. Receber os frames binários (FlatBuffers-style) do order book e aplicar
//     o DELTA no espelho local do book (zero desserialização de objetos).
//  2. Manter o HeatMapRing: matriz COLS×ROWS×2 (colunas temporais × linhas de
//     preço × lados) empacotada em RGBA8 pronta para textura WebGL, com
//     hot-path numérico no kernel WASM (fallback JS automático).
//  3. Rastrear divergências de fluxo (base ATAS X / MMT):
//     - absorção: agressão volumosa travada com BBO inerte;
//     - exaustão: aceleração do CVD sem progresso de preço;
//     - iceberg: nível que se auto-reabastece sob fogo contínuo.
//  4. Publicar estatísticas do stream (latência µs, trades/s, CVD...).
// ─────────────────────────────────────────────────────────────────────────────

import { MboFrameView } from '@/lib/market/flatbuf';
import type { DomL3Row, FlowSignal } from '@/lib/market/flow';
import { loadMboKernel, type MboKernel } from '@/lib/mbo/kernel';
import { TF_MS, type HeatmapBucket, type MboOp, type Timeframe } from '@/lib/market/types';

// ── geometria do anel ────────────────────────────────────────────────────────
const RING_COLS = 300; // colunas temporais mantidas
const RING_ROWS = 320; // linhas de preço (ticks) — ±160 ao redor do best bid
/** linha do âncora (best bid fica nesta row) */
const ANCHOR_ROW = 160;
/** re-ancora quando o best bid sai da faixa central */
const ANCHOR_MARGIN = 56;

// ── layout da memória WASM (página 0) ───────────────────────────────────────
const OFF_STATS = 0; // 40 B (5 × f64)
const OFF_COL = 64; // RING_ROWS*8 B — coluna de book (bid/ask máx.)
const OFF_EXEC = OFF_COL + RING_ROWS * 8; // RING_ROWS*8 B — coluna executada
const OFF_TRADES = OFF_EXEC + RING_ROWS * 8; // 420 × 24 B
const MAX_TRADES = 420;
const OFF_DELTAS = OFF_TRADES + MAX_TRADES * 24; // 600 × 12 B
const MAX_DELTAS = 600;

const SIGNAL_TTL_MS = 6000;
const COOLDOWN_MS = 2800;
const MAX_SIGNALS_PER_SEC = 6;

interface WorkerInitMsg {
  type: 'init';
  symbol: string;
  tf: Timeframe;
  /** buckets JSON do snapshot (prefill do anel) */
  heatmap?: HeatmapBucket[];
  /** tick index do melhor bid no snapshot (âncora inicial) */
  bestBidTick?: number;
}
interface WorkerFrameMsg {
  type: 'frame';
  buf: ArrayBuffer;
  /** performance.now() do main thread no recebimento do socket (latência µs) */
  clientT?: number;
}
interface WorkerResetMsg {
  type: 'reset';
}
type WorkerInMsg = WorkerInitMsg | WorkerFrameMsg | WorkerResetMsg;

// ── estado ───────────────────────────────────────────────────────────────────
let kernel: MboKernel | null = null;
let kernelWasm = false;

let symbol = '';
let tf: Timeframe = '1m';
let tfMs = TF_MS['1m'];

/** espelho local do book: tick idx → [bidQ, askQ] */
const book = new Map<number, [number, number]>();
/** quantidade típica de um nível (normalização de força dos sinais) */
let typicalQty = 1;

// anel
const ringData = new Uint8Array(RING_COLS * RING_ROWS * 4);
let ringColBase = 0; // tick index da row 0
let ringFirstT = 0; // ms da coluna 0
let ringCurCol = 0; // coluna do bucket corrente
let ringVersion = 0;
let ringMaxQ = 1;
let lastRingPost = 0;

// fluxo / sinais
let cvd = 0;
let lastPriceIdx = 0;
let bestBidIdx = 0;
let bestAskIdx = 0;
let prevBestBidIdx = 0;
let prevBestAskIdx = 0;
/** volume agressor acumulado contra o BBO atual (janela de inércia) */
let volIntoAsk = 0;
let volIntoBid = 0;
let tradesIntoBbo = 0;
let bboChangedAt = 0;
/** janela deslizante p/ CVD e ritmo ({t, cvd, lastIdx, vol}) */
const cvdHist: { t: number; cvd: number; lastIdx: number; vol: number }[] = [];
/** volume executado por nível (janela 3s, p/ iceberg/absorção) */
const levelVol = new Map<number, { b: number; a: number; t: number }>();
/** recargas detectadas por nível na janela 2s (iceberg) */
const refills = new Map<number, { n: number; t: number; side: 0 | 1 }>();
const cooldown = new Map<string, number>();
let signalId = 1;
let signalsThisSec = 0;
let signalsSecStart = 0;

// pulling/stacking (DOM L3): EMA por nível das variações de quantidade do book
const l3 = new Map<number, { pull: number; stack: number; pulls: number; stacks: number }>();
let lastDomL3Post = 0;
// níveis-fantasma (spoofing): liquidez grande perto do BBO cancelada sem execução
const SPOOF_WINDOW_MS = 6500;
const ghost = new Map<number, { t0: number; side: 0 | 1; peak: number; exec: number }>();

// stats
let frames = 0;
let frameBytes = 0;
let lastClientT = 0;
let lastStatsPost = 0;
let kernelErr: string | null = null;
let tradesWin: number[] = []; // timestamps (ms) p/ trades/s

// log de operações de book (ring p/ o painel MBO LOG do terminal)
const OPS_RING_CAP = 64;
const opsRing: MboOp[] = [];
let lastOpsPost = 0;

// ── utilitários do anel ──────────────────────────────────────────────────────

function ringIdx(col: number, row: number): number {
  return (col * RING_ROWS + row) * 4;
}

/** (Re)ancora o anel em novoColBase deslocando o conteúdo quando possível. */
function reanchor(newColBase: number): void {
  const delta = newColBase - ringColBase;
  ringColBase = newColBase;
  if (delta === 0) return;
  if (Math.abs(delta) >= RING_ROWS) {
    ringData.fill(0);
    refillCurrentColFromBook();
    return;
  }
  const scratch = new Uint8Array(RING_ROWS * 4);
  for (let c = 0; c < RING_COLS; c++) {
    const base = c * RING_ROWS * 4;
    scratch.set(ringData.subarray(base, base + RING_ROWS * 4));
    for (let r = 0; r < RING_ROWS; r++) {
      const src = r + delta; // row antiga que mapeia nesta
      const dst = base + r * 4;
      if (src >= 0 && src < RING_ROWS) {
        const s = src * 4;
        ringData[dst] = scratch[s];
        ringData[dst + 1] = scratch[s + 1];
        ringData[dst + 2] = 0;
        ringData[dst + 3] = 0;
      } else {
        ringData[dst] = 0;
        ringData[dst + 1] = 0;
        ringData[dst + 2] = 0;
        ringData[dst + 3] = 0;
      }
    }
  }
  refillCurrentColFromBook();
}

/** Reescreve a coluna corrente a partir do espelho do book (pós-ancoragem). */
function refillCurrentColFromBook(): void {
  const base = ringCurCol * RING_ROWS * 4;
  for (let r = 0; r < RING_ROWS; r++) {
    ringData[base + r * 4] = 0;
    ringData[base + r * 4 + 1] = 0;
  }
  for (const [idx, pair] of book) {
    const r = idx - ringColBase;
    if (r < 0 || r >= RING_ROWS) continue;
    const o = base + r * 4;
    if (pair[0] > 0) ringData[o + 1] = toByte(pair[0]);
    if (pair[1] > 0) ringData[o] = toByte(pair[1]);
  }
}

function toByte(q: number): number {
  return Math.max(1, Math.min(255, Math.round((q / ringMaxQ) * 255)));
}

/** Avança as colunas até o bucket de `t` (zerando as novas). */
function advanceToBucket(t: number): void {
  const bt = Math.floor(t / tfMs) * tfMs;
  if (ringFirstT === 0) {
    ringFirstT = bt - (RING_COLS - 1) * tfMs;
    ringCurCol = RING_COLS - 1;
    return;
  }
  let k = Math.floor((bt - ringFirstT) / tfMs) - ringCurCol;
  if (k <= 0) return;
  if (k >= RING_COLS) {
    ringData.fill(0);
    ringCurCol = RING_COLS - 1;
    ringFirstT = bt - (RING_COLS - 1) * tfMs;
    refillCurrentColFromBook();
    return;
  }
  const stride = RING_ROWS * 4;
  ringData.copyWithin(0, k * stride, RING_COLS * stride);
  ringData.fill(0, (RING_COLS - k) * stride);
  ringCurCol = RING_COLS - 1;
  ringFirstT += k * tfMs;
}

// ── inicialização ────────────────────────────────────────────────────────────

function doInit(msg: WorkerInitMsg): void {
  const sameSymbol = msg.symbol === symbol;
  symbol = msg.symbol;
  tf = msg.tf;
  tfMs = TF_MS[tf];
  // preserva o espelho do book quando é só re-subscrição do mesmo símbolo:
  // o frame full pode ter chegado ANTES deste init e perderíamos o estado
  // (os frames seguintes são só DELTAS)
  if (!sameSymbol) {
    book.clear();
    levelVol.clear();
    refills.clear();
    l3.clear();
    ghost.clear();
  }
  cvdHist.length = 0;
  cooldown.clear();
  volIntoAsk = 0;
  volIntoBid = 0;
  tradesIntoBbo = 0;
  tradesWin = [];

  ringData.fill(0);
  ringVersion++;
  const anchor = msg.bestBidTick ?? 0;
  ringColBase = anchor - ANCHOR_ROW;
  const now = Date.now();
  ringFirstT = Math.floor(now / tfMs) * tfMs - (RING_COLS - 1) * tfMs;
  ringCurCol = RING_COLS - 1;

  // normalização: maior quantidade vista no snapshot (evita saturar os bytes)
  let qMax = 1;
  if (msg.heatmap) {
    for (const b of msg.heatmap) {
      for (const key in b.lv) {
        const pair = b.lv[key];
        if (pair[0] > qMax) qMax = pair[0];
        if (pair[1] > qMax) qMax = pair[1];
      }
    }
  }
  ringMaxQ = qMax;

  // prefill a partir do snapshot JSON (histórico do heatmap)
  if (msg.heatmap && msg.heatmap.length) {
    for (const b of msg.heatmap) {
      const t = Math.floor(b.t / tfMs) * tfMs;
      const c = Math.floor((t - ringFirstT) / tfMs);
      if (c < 0 || c >= RING_COLS) continue;
      for (const key in b.lv) {
        const idx = Number(key);
        const r = idx - ringColBase;
        if (r < 0 || r >= RING_ROWS) continue;
        const pair = b.lv[key];
        const o = ringIdx(c, r);
        if (pair[0] > 0) ringData[o + 1] = Math.max(ringData[o + 1], toByte(pair[0]));
        if (pair[1] > 0) ringData[o] = Math.max(ringData[o], toByte(pair[1]));
      }
    }
  }
  postRing(true);
}

// ── processamento de frame ───────────────────────────────────────────────────

function packDeltas(dv: DataView, view: MboFrameView, n: number): number {
  const u8 = new Uint8Array(dv.buffer);
  let count = 0;
  for (let i = 0; i < n && count < MAX_DELTAS; i++) {
    const o = OFF_DELTAS + count * 12;
    dv.setInt32(o, view.deltaIdx(i), true);
    u8[o + 4] = view.deltaSide(i);
    u8[o + 5] = view.deltaOp(i);
    dv.setFloat32(o + 8, view.deltaQty(i), true);
    count++;
  }
  return count;
}

function packTrades(dv: DataView, view: MboFrameView, n: number): number {
  const u8 = new Uint8Array(dv.buffer);
  let count = 0;
  for (let i = 0; i < n && count < MAX_TRADES; i++) {
    const o = OFF_TRADES + count * 24;
    dv.setFloat64(o, view.tradeT(i), true);
    dv.setInt32(o + 8, view.tradeP(i), true);
    dv.setFloat32(o + 12, view.tradeS(i), true);
    u8[o + 16] = view.tradeSide(i);
    u8[o + 17] = view.tradeBig(i) ? 1 : 0;
    count++;
  }
  return count;
}

function doFrame(msg: WorkerFrameMsg): void {
  const view = new MboFrameView(msg.buf);
  if (!view.valid) return;
  const now = Date.now();
  lastClientT = msg.clientT ?? 0;

  advanceToBucket(view.serverTime || now);
  bestBidIdx = view.bestBidIdx;
  bestAskIdx = view.bestAskIdx;
  cvd = view.cvd;
  lastPriceIdx = view.lastPriceIdx;

  // âncora do anel segue o best bid
  if (
    ringColBase === 0 ||
    bestBidIdx < ringColBase + ANCHOR_MARGIN ||
    bestBidIdx > ringColBase + RING_ROWS - ANCHOR_MARGIN
  ) {
    reanchor(bestBidIdx - ANCHOR_ROW);
  }

  // ── trades: sinais primeiro (lê direto do view, sem cópia) ────────────────
  const nT = view.nTrades;
  let frameVol = 0;
  const newSignals: FlowSignal[] = [];
  for (let i = 0; i < nT; i++) {
    const p = view.tradeP(i);
    const s = view.tradeS(i);
    const side = view.tradeSide(i); // 0 = venda, 1 = compra
    frameVol += s;

    // execução contra níveis-fantasma (spoof): volume que de fato atingiu o nível
    const gh = ghost.get(p);
    if (gh) gh.exec += s;

    // volume por nível (janela 3s)
    let lv = levelVol.get(p);
    if (!lv || now - lv.t > 3000) {
      lv = { b: 0, a: 0, t: now };
      levelVol.set(p, lv);
    }
    if (side === 1) lv.a += s;
    else lv.b += s;
    lv.t = now;

    // agressão contra o BBO corrente (testa o BBO do frame ANTERIOR)
    if (side === 1 && p === prevBestAskIdx) {
      volIntoAsk += s;
      tradesIntoBbo++;
    } else if (side === 0 && p === prevBestBidIdx) {
      volIntoBid += s;
      tradesIntoBbo++;
    }
  }
  // poda do mapa de volume por nível (evita crescimento sem limite)
  if (levelVol.size > 2400) {
    for (const [k, lv] of levelVol) {
      if (now - lv.t > 3000) levelVol.delete(k);
    }
  }
  for (let i = 0; i < nT; i++) tradesWin.push(view.serverTime || now);
  if (tradesWin.length > 600) tradesWin.splice(0, tradesWin.length - 600);

  // ── aplica o delta no espelho do book ─────────────────────────────────────
  const nD = view.nDeltas;
  const isDeltaFrame = (view.flags & 1) === 0; // full = resincronização, não entra no log
  for (let i = 0; i < nD; i++) {
    const idx = view.deltaIdx(i);
    const op = view.deltaOp(i);
    if (op === 1) {
      const gone = book.get(idx);
      if (gone && isDeltaFrame && opsRing.length < OPS_RING_CAP) {
        const prevQ = Math.max(gone[0], gone[1]);
        opsRing.push({
          t: view.serverTime || now,
          side: gone[0] > 0 ? 0 : 1,
          op: 1,
          idx,
          qty: 0,
          dq: -prevQ,
        });
      }
      // L3: remoção do nível inteiro = pulling; testa spoofing antes de apagar
      if (gone) {
        const goneSide: 0 | 1 = gone[0] > 0 ? 0 : 1;
        const goneQ = gone[goneSide];
        if (isDeltaFrame) {
          trackPullStack(idx, -goneQ);
          checkSpoofCancel(idx, goneQ, now, newSignals);
        }
        ghost.delete(idx);
      }
      book.delete(idx);
      continue;
    }
    const side = view.deltaSide(i);
    const qty = view.deltaQty(i);
    let cell = book.get(idx);
    if (!cell) {
      cell = [0, 0];
      book.set(idx, cell);
    }
    // recarga de iceberg: nível consumido se reabastece (q sobe de perto de 0)
    const prev = side === 0 ? cell[0] : cell[1];
    if (isDeltaFrame && opsRing.length < OPS_RING_CAP) {
      opsRing.push({
        t: view.serverTime || now,
        side: side as 0 | 1,
        op: 0,
        idx,
        qty,
        dq: qty - prev,
      });
    }
    if (qty > prev * 1.5 && prev <= typicalQty * 0.35 && qty >= typicalQty * 0.6) {
      let rf = refills.get(idx);
      if (!rf || now - rf.t > 2000 || rf.side !== side) {
        rf = { n: 0, t: now, side: side as 0 | 1 };
        refills.set(idx, rf);
      }
      rf.n++;
    }
    if (isDeltaFrame) {
      // L3: pulling/stacking do nível (variação de quantidade)
      trackPullStack(idx, qty - prev);
      // spoofing: grande liquidez nova perto do BBO → registra nível-fantasma;
      // queda brusca parcial (≥50%) já testa cancelamento
      const nearBbo = idx >= bestBidIdx - 8 && idx <= bestAskIdx + 8;
      if (nearBbo && qty >= typicalQty * 2.2) {
        const gh = ghost.get(idx);
        if (gh && gh.side === side) {
          if (qty > gh.peak) gh.peak = qty;
        } else {
          ghost.set(idx, { t0: now, side: side as 0 | 1, peak: qty, exec: 0 });
        }
      }
      if (prev > 0 && qty <= prev * 0.5) checkSpoofCancel(idx, prev - qty, now, newSignals);
    }
    if (side === 0) cell[0] = qty;
    else cell[1] = qty;
  }

  // quantidade típica (recomputa a cada 2s)
  refreshTypicalQty(now);

  // ── kernel WASM: coluna de book (máx./bucket) + coluna executada + stats ──
  if (kernel) {
    const dv = new DataView(kernel.memory.buffer);
    const u8 = new Uint8Array(kernel.memory.buffer);
    // zera áreas de trabalho do kernel (colunas + stats) antes do hot-path
    u8.fill(0, OFF_COL, OFF_EXEC + RING_ROWS * 8);
    u8.fill(0, OFF_STATS, OFF_STATS + 40);
    const nPacked = packDeltas(dv, view, nD);
    kernel.applyBook(OFF_COL, RING_ROWS, ringColBase, OFF_DELTAS, nPacked);
    const nTPacked = packTrades(dv, view, nT);
    kernel.accTrades(OFF_EXEC, RING_ROWS, ringColBase, OFF_TRADES, nTPacked, OFF_STATS);
  }

  // ── anel: coluna corrente ← espelho do book (máx. visto no bucket) ────────
  const colBase = ringCurCol * RING_ROWS * 4;
  ringMaxQ = Math.max(ringMaxQ * 0.9995, 1);
  for (const [idx, pair] of book) {
    const r = idx - ringColBase;
    if (r < 0 || r >= RING_ROWS) continue;
    const o = colBase + r * 4;
    if (pair[0] > ringMaxQ) ringMaxQ = pair[0];
    if (pair[1] > ringMaxQ) ringMaxQ = pair[1];
    if (pair[0] > 0) ringData[o + 1] = toByte(pair[0]);
    if (pair[1] > 0) ringData[o] = toByte(pair[1]);
  }
  ringVersion++;
  frames++;
  frameBytes += msg.buf.byteLength;

  // ── BBO: inércia + absorção ────────────────────────────────────────────────
  if (bestBidIdx !== prevBestBidIdx || bestAskIdx !== prevBestAskIdx) {
    // BBO mudou: fecha a janela de inércia anterior (emite se houver absorção)
    emitAbsorptionIfAny(now, newSignals);
    volIntoAsk = 0;
    volIntoBid = 0;
    tradesIntoBbo = 0;
    bboChangedAt = now;
  } else if (now - bboChangedAt >= 500) {
    emitAbsorptionIfAny(now, newSignals);
  }
  prevBestBidIdx = bestBidIdx;
  prevBestAskIdx = bestAskIdx;

  // ── icebergs: recargas suficientes sob fogo ────────────────────────────────
  detectIcebergs(now, newSignals);

  // ── exaustão: aceleração do CVD sem progresso de preço ────────────────────
  cvdHist.push({ t: now, cvd, lastIdx: lastPriceIdx, vol: frameVol });
  if (cvdHist.length > 40) cvdHist.shift();
  detectExhaustion(now, newSignals);

  // ── publica ────────────────────────────────────────────────────────────────
  if (newSignals.length) {
    (self as unknown as Worker).postMessage({ type: 'signals', signals: newSignals });
  }
  if (opsRing.length > 0 && now - lastOpsPost >= 600) {
    (self as unknown as Worker).postMessage({ type: 'ops', ops: opsRing.slice() });
    opsRing.length = 0;
    lastOpsPost = now;
  }
  if (now - lastRingPost >= 110) postRing(false);
  if (now - lastStatsPost >= 500) postStats(now);
  if (now - lastDomL3Post >= 500) postDomL3(now);
}

/** Acumula pulling (dq<0) / stacking (dq>0) de um nível p/ o painel DOM L3. */
function trackPullStack(idx: number, dq: number): void {
  if (dq === 0) return;
  let row = l3.get(idx);
  if (!row) {
    row = { pull: 0, stack: 0, pulls: 0, stacks: 0 };
    l3.set(idx, row);
  }
  if (dq > 0) {
    row.stack += dq;
    row.stacks++;
  } else {
    row.pull -= dq;
    row.pulls++;
  }
  if (l3.size > 640) {
    // poda: decai tudo pela metade e remove níveis frios
    for (const [k, r] of l3) {
      r.pull *= 0.5;
      r.stack *= 0.5;
      if (r.pull < 0.01 && r.stack < 0.01) l3.delete(k);
    }
  }
}

/**
 * Spoofing: liquidez grande registrada perto do BBO e cancelada (total ou
 * parcialmente ≥50%) dentro da janela, com pouca execução contra ela —
 * assinatura de ordem-fantasma (trap de book).
 */
function checkSpoofCancel(
  idx: number,
  pulledQty: number,
  now: number,
  out: FlowSignal[],
): void {
  const gh = ghost.get(idx);
  if (!gh) return;
  const held = now - gh.t0;
  const execFrac = gh.exec / Math.max(1, gh.peak);
  if (
    held <= SPOOF_WINDOW_MS &&
    gh.peak >= typicalQty * 2.2 &&
    pulledQty >= gh.peak * 0.5 &&
    execFrac <= 0.25
  ) {
    pushSignal(out, {
      kind: 'spoof',
      side: gh.side === 0 ? 'buy' : 'sell', // lado da liquidez-fantasma
      priceIdx: idx,
      vol: pulledQty,
      strength: Math.min(1, gh.peak / (typicalQty * 4)),
      t: now,
    });
  }
  ghost.delete(idx);
}

/**
 * Publica o snapshot pulling/stacking ±16 ticks do BBO (a cada 500ms) e aplica
 * o decaimento exponencial (meia-vida ~1.9s → janela efetiva ~3s).
 */
function postDomL3(now: number): void {
  lastDomL3Post = now;
  for (const [k, row] of l3) {
    row.pull *= 0.84;
    row.stack *= 0.84;
    if (row.pull < 0.01 && row.stack < 0.01) l3.delete(k);
  }
  const lo = bestBidIdx - 16;
  const hi = bestAskIdx + 16;
  const rows: DomL3Row[] = [];
  for (const [idx, row] of l3) {
    if (idx < lo || idx > hi) continue;
    if (row.pull < 0.5 && row.stack < 0.5) continue;
    rows.push({
      idx,
      pull: Math.round(row.pull),
      stack: Math.round(row.stack),
      pulls: row.pulls,
      stacks: row.stacks,
    });
  }
  rows.sort((a, b) => a.idx - b.idx);
  (self as unknown as Worker).postMessage({ type: 'doml3', snapshot: { t: now, rows } });
}

function refreshTypicalQty(now: number): void {
  if (now % 2000 > 120) return; // ~0.5Hz basta
  let sum = 0;
  let n = 0;
  for (let d = 2; d <= 12; d++) {
    const b = book.get(bestBidIdx - d + 1);
    const a = book.get(bestAskIdx + d - 1);
    if (b && b[0] > 0) {
      sum += b[0];
      n++;
    }
    if (a && a[1] > 0) {
      sum += a[1];
      n++;
    }
  }
  if (n >= 6) typicalQty = Math.max(1, sum / n);
}

/** Absorção: volume agressor travado contra um BBO inerte (inércia do book). */
function emitAbsorptionIfAny(now: number, out: FlowSignal[]): void {
  const holdMs = now - bboChangedAt;
  const tA = typicalQty * 1.6;
  if (volIntoAsk >= tA && tradesIntoBbo >= 5 && holdMs >= 500) {
    pushSignal(out, {
      kind: 'absorption',
      side: 'buy', // compras agressoras sendo absorvidas no ask
      priceIdx: prevBestAskIdx,
      vol: volIntoAsk,
      strength: Math.min(1, volIntoAsk / (typicalQty * 3.2)),
      t: now,
    });
    volIntoAsk = 0;
    tradesIntoBbo = 0;
  }
  if (volIntoBid >= tA && tradesIntoBbo >= 5 && holdMs >= 500) {
    pushSignal(out, {
      kind: 'absorption',
      side: 'sell', // vendas agressoras sendo absorvidas no bid
      priceIdx: prevBestBidIdx,
      vol: volIntoBid,
      strength: Math.min(1, volIntoBid / (typicalQty * 3.2)),
      t: now,
    });
    volIntoBid = 0;
    tradesIntoBbo = 0;
  }
}

/** Iceberg: ≥2 recargas em 2s num nível que está sendo executado. */
function detectIcebergs(now: number, out: FlowSignal[]): void {
  for (const [idx, rf] of refills) {
    if (now - rf.t > 2000) {
      refills.delete(idx);
      continue;
    }
    if (rf.n < 2) continue;
    const lv = levelVol.get(idx);
    const vol = lv ? lv.a + lv.b : 0;
    if (vol <= 0) continue;
    pushSignal(out, {
      kind: 'iceberg',
      side: rf.side === 1 ? 'buy' : 'sell', // lado do agressor que revela o iceberg
      priceIdx: idx,
      vol,
      strength: Math.min(1, rf.n / 4 + vol / (typicalQty * 6)),
      t: now,
    });
    refills.delete(idx);
  }
}

/**
 * Exaustão (MMT): |inclinação do CVD| alta com preço estacionário — a
 * agressão está sendo absorvida sem gerar progresso.
 */
function detectExhaustion(now: number, out: FlowSignal[]): void {
  if (cvdHist.length < 12) return;
  const first = cvdHist[0];
  const spanSec = (now - first.t) / 1000;
  if (spanSec < 1.2) return;
  const dCvd = cvd - first.cvd;
  const dPx = lastPriceIdx - first.lastIdx;
  let volSum = 0;
  for (const h of cvdHist) volSum += h.vol;
  const volPerSec = volSum / spanSec;
  if (volPerSec <= 0) return;
  const slope = Math.abs(dCvd) / spanSec;
  if (slope < volPerSec * 1.1) return;
  if (Math.abs(dPx) > 1) return; // preço andou: não é exaustão
  pushSignal(out, {
    kind: 'exhaustion',
    side: dCvd > 0 ? 'buy' : 'sell',
    priceIdx: lastPriceIdx,
    vol: Math.abs(dCvd),
    strength: Math.min(1, slope / (volPerSec * 2.4)),
    t: now,
  });
}

function pushSignal(
  out: FlowSignal[],
  s: Omit<FlowSignal, 'id' | 'until'>,
): void {
  const now = Date.now();
  if (now - signalsSecStart >= 1000) {
    signalsSecStart = now;
    signalsThisSec = 0;
  }
  if (signalsThisSec >= MAX_SIGNALS_PER_SEC) return;
  const key = `${s.kind}:${s.priceIdx}`;
  const lastT = cooldown.get(key);
  if (lastT !== undefined && now - lastT < COOLDOWN_MS) return;
  cooldown.set(key, now);
  if (cooldown.size > 256) {
    // limpa entradas antigas
    for (const [k, t] of cooldown) {
      if (now - t > COOLDOWN_MS * 2) cooldown.delete(k);
    }
  }
  signalsThisSec++;
  out.push({ ...s, id: signalId++, until: now + SIGNAL_TTL_MS });
}

// ── publicações ──────────────────────────────────────────────────────────────

function postRing(force: boolean): void {
  const now = Date.now();
  if (!force && now - lastRingPost < 110) return;
  lastRingPost = now;
  const copy = ringData.slice();
  (self as unknown as Worker).postMessage(
    {
      type: 'ring',
      ring: {
        cols: RING_COLS,
        rows: RING_ROWS,
        colBase: ringColBase,
        firstT: ringFirstT,
        tfMs,
        maxQ: ringMaxQ,
        data: copy,
        version: ringVersion,
      },
    },
    [copy.buffer],
  );
}

function postStats(now: number): void {
  lastStatsPost = now;
  const span = Math.min(5, Math.max(1, (now - (tradesWin[0] ?? now)) / 1000)) || 1;
  const tradesPerSec = tradesWin.length / span;
  // inclinação do CVD na janela do cvdHist
  let slope = 0;
  if (cvdHist.length >= 2) {
    const first = cvdHist[0];
    const sec = Math.max(0.5, (now - first.t) / 1000);
    slope = (cvd - first.cvd) / sec;
  }
  let latencyUs = 0;
  if (lastClientT > 0) {
    // performance.timeOrigin + performance.now() alinha worker e main no epoch.
    // Replay do journal: o clientT é o tempo do MERCADO (frames antigos) —
    // latências absurdas (>5s) significam replay e são reportadas como 0.
    const nowEpoch = performance.timeOrigin + performance.now();
    const rawUs = Math.round((nowEpoch - lastClientT) * 1000);
    latencyUs = rawUs >= 0 && rawUs <= 5_000_000 ? rawUs : 0;
  }
  (self as unknown as Worker).postMessage({
    type: 'stats',
    stats: {
      cvd,
      cvdSlope: slope,
      bboInertiaMs: now - bboChangedAt,
      tradesPerSec: Math.round(tradesPerSec * 10) / 10,
      frames,
      frameBytes,
      lastLatencyUs: latencyUs,
      wasm: kernelWasm,
      kernelErr,
    },
  });
}

// ── boot ─────────────────────────────────────────────────────────────────────

loadMboKernel().then((r) => {
  kernel = r.kernel;
  kernelWasm = r.wasm;
  kernelErr = r.err;
});

self.onmessage = (e: MessageEvent<WorkerInMsg>) => {
  const msg = e.data;
  try {
    if (msg.type === 'init') doInit(msg);
    else if (msg.type === 'frame') doFrame(msg);
    else if (msg.type === 'reset') {
      ringData.fill(0);
      book.clear();
      l3.clear();
      ghost.clear();
      ringVersion++;
      postRing(true);
    }
  } catch (err) {
    console.error('[mbo-worker] erro:', err);
  }
};
