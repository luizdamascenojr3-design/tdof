;; -----------------------------------------------------------------------------
;; mbo-kernel.wat — Kernel WASM MBO (Market By Order) do FlowTerminal
;; -----------------------------------------------------------------------------
;; Hot-path numérico do processamento MBO no navegador:
;;
;;   applyBook : aplica deltas de book (upsert = máximo visto no bucket,
;;               delete = zera) numa coluna do heatmap (rows × 2 lados × f32).
;;   accTrades : acumula trades na mesma coluna (col += s) e atualiza as
;;               estatísticas de fluxo (cvd, volume, buyVol, sellVol, count).
;;
;; Convenções:
;;   - Memória linear little-endian, 4 páginas iniciais, crescível via
;;     memory.grow (o host JS anexa suas Float32Array/DataView nela).
;;   - Endereços chegam como i32 absolutos e DEVEM estar alinhados:
;;     colPtr/outPtr/deltasPtr com alinhamento de 4 bytes; tradesPtr e
;;     statsPtr com alinhamento de 8 bytes (por causa dos f64 de t e dos
;;     acumuladores).
;;   - Row 0 da coluna = tick index colBase; row r = colBase + r.
;;     Elemento (row, side): addr = colPtr + row*8 + side*4.
;;   - MVP puro: sem SIMD, sem imports — máximo de compatibilidade.
;; -----------------------------------------------------------------------------

(module
  ;; Memória linear exportada (index 0) — 4 páginas = 256 KiB.
  (memory 4)
  (export "memory" (memory 0))

  ;; ---------------------------------------------------------------------------
  ;; applyBook(colPtr:i32, rows:i32, colBase:i32, deltasPtr:i32, nDeltas:i32)
  ;;
  ;; Delta (stride 12 bytes):
  ;;   +0: i32 idx | +4: u8 side (0=bid, 1=ask) | +5: u8 op (0=upsert, 1=delete)
  ;;   +6: u16 padding | +8: f32 qty (ignorado se op=1)
  ;;
  ;; Para cada delta: row = idx − colBase; fora de [0, rows) → ignora.
  ;;   op=0 (upsert): mem[addr] = max(mem[addr], qty)  — máximo visto no bucket
  ;;   op=1 (delete): mem[addr] = 0
  ;; ---------------------------------------------------------------------------
  (func $applyBook (export "applyBook")
    (param $colPtr i32) (param $rows i32) (param $colBase i32)
    (param $deltasPtr i32) (param $nDeltas i32)
    (local $i i32)     ;; índice do delta corrente
    (local $ptr i32)   ;; endereço base do delta corrente
    (local $row i32)   ;; linha na coluna (idx − colBase)
    (local $addr i32)  ;; endereço do elemento (row, side)

    (local.set $i (i32.const 0))
    (block $fim
      (loop $laco
        ;; i >= nDeltas → acabou
        (br_if $fim (i32.ge_s (local.get $i) (local.get $nDeltas)))

        (local.set $ptr
          (i32.add (local.get $deltasPtr)
                   (i32.mul (local.get $i) (i32.const 12))))

        ;; row = idx − colBase
        (local.set $row
          (i32.sub (i32.load (local.get $ptr)) (local.get $colBase)))

        ;; dentro da janela [0, rows)?
        (if
          (i32.and (i32.ge_s (local.get $row) (i32.const 0))
                   (i32.lt_s (local.get $row) (local.get $rows)))
          (then
            ;; addr = colPtr + row*8 + side*4
            (local.set $addr
              (i32.add (local.get $colPtr)
                (i32.add (i32.mul (local.get $row) (i32.const 8))
                         (i32.mul (i32.load8_u offset=4 (local.get $ptr))
                                  (i32.const 4)))))
            ;; op em +5: 0 = upsert, 1 = delete
            (if (i32.eqz (i32.load8_u offset=5 (local.get $ptr)))
              (then
                ;; upsert: novo = max(atual, qty)
                (f32.store (local.get $addr)
                  (f32.max (f32.load (local.get $addr))
                           (f32.load offset=8 (local.get $ptr)))))
              (else
                ;; delete: zera o nível
                (f32.store (local.get $addr) (f32.const 0))))))

        (local.set $i (i32.add (local.get $i) (i32.const 1)))
        (br $laco))))

  ;; ---------------------------------------------------------------------------
  ;; accTrades(outPtr:i32, rows:i32, colBase:i32, tradesPtr:i32,
  ;;           nTrades:i32, statsPtr:i32)
  ;;
  ;; Trade (stride 24 bytes):
  ;;   +0: f64 t (ms) | +8: i32 p (tick do preço) | +12: f32 s (quantidade)
  ;;   +16: u8 side (0=venda/agressão no bid, 1=compra/agressão no ask)
  ;;   +17..23: padding (zero)
  ;;
  ;; Coluna (outPtr, mesmo layout de colPtr): para row = p − colBase dentro de
  ;; [0, rows): mem[addr] += s (f32, leitura-modificação-escrita).
  ;; Estatísticas (statsPtr, 40 bytes de f64, pré-inicializadas pelo chamador):
  ;;   +0 f64 cvd | +8 f64 volume | +16 f64 buyVol | +24 f64 sellVol
  ;;   +32 f64 tradeCount
  ;; Atualizadas SEMPRE — inclusive para trades fora da janela.
  ;; ---------------------------------------------------------------------------
  (func $accTrades (export "accTrades")
    (param $outPtr i32) (param $rows i32) (param $colBase i32)
    (param $tradesPtr i32) (param $nTrades i32) (param $statsPtr i32)
    (local $j i32)     ;; índice do trade corrente
    (local $ptr i32)   ;; endereço base do trade corrente
    (local $row i32)   ;; linha na coluna (p − colBase)
    (local $side i32)  ;; 0 = venda (agressão no bid), 1 = compra (no ask)
    (local $addr i32)  ;; endereço do elemento (row, side)
    (local $s f32)     ;; quantidade (f32, como veio do feed)
    (local $sf f64)    ;; quantidade promovida p/ f64 (acumuladores)
    (local $cvd f64)   ;; cvd acumulado
    (local $vol f64)   ;; volume total
    (local $buy f64)   ;; volume comprador
    (local $sell f64)  ;; volume vendedor
    (local $cnt f64)   ;; contagem de negócios

    ;; carrega os acumuladores inicializados pelo chamador
    (local.set $cvd  (f64.load            (local.get $statsPtr)))
    (local.set $vol  (f64.load offset=8   (local.get $statsPtr)))
    (local.set $buy  (f64.load offset=16  (local.get $statsPtr)))
    (local.set $sell (f64.load offset=24  (local.get $statsPtr)))
    (local.set $cnt  (f64.load offset=32  (local.get $statsPtr)))

    (local.set $j (i32.const 0))
    (block $fim
      (loop $laco
        ;; j >= nTrades → acabou
        (br_if $fim (i32.ge_s (local.get $j) (local.get $nTrades)))

        (local.set $ptr
          (i32.add (local.get $tradesPtr)
                   (i32.mul (local.get $j) (i32.const 24))))
        (local.set $s    (f32.load    offset=12 (local.get $ptr)))
        (local.set $side (i32.load8_u offset=16 (local.get $ptr)))
        (local.set $sf   (f64.promote_f32 (local.get $s)))

        ;; row = p − colBase; dentro da janela → col[side][row] += s
        (local.set $row
          (i32.sub (i32.load offset=8 (local.get $ptr)) (local.get $colBase)))
        (if
          (i32.and (i32.ge_s (local.get $row) (i32.const 0))
                   (i32.lt_s (local.get $row) (local.get $rows)))
          (then
            (local.set $addr
              (i32.add (local.get $outPtr)
                (i32.add (i32.mul (local.get $row) (i32.const 8))
                         (i32.mul (local.get $side) (i32.const 4)))))
            (f32.store (local.get $addr)
              (f32.add (f32.load (local.get $addr)) (local.get $s)))))

        ;; estatísticas sempre atualizadas (mesmo para trade fora da janela)
        (local.set $vol (f64.add (local.get $vol) (local.get $sf)))
        (if (i32.ne (local.get $side) (i32.const 0))
          (then
            ;; side=1 (compra): cvd += s, buyVol += s
            (local.set $cvd  (f64.add (local.get $cvd)  (local.get $sf)))
            (local.set $buy  (f64.add (local.get $buy)  (local.get $sf))))
          (else
            ;; side=0 (venda): cvd −= s, sellVol += s
            (local.set $cvd  (f64.sub (local.get $cvd)  (local.get $sf)))
            (local.set $sell (f64.add (local.get $sell) (local.get $sf)))))
        (local.set $cnt (f64.add (local.get $cnt) (f64.const 1)))

        (local.set $j (i32.add (local.get $j) (i32.const 1)))
        (br $laco)))

    ;; grava os acumuladores de volta em statsPtr
    (f64.store           (local.get $statsPtr) (local.get $cvd))
    (f64.store offset=8  (local.get $statsPtr) (local.get $vol))
    (f64.store offset=16 (local.get $statsPtr) (local.get $buy))
    (f64.store offset=24 (local.get $statsPtr) (local.get $sell))
    (f64.store offset=32 (local.get $statsPtr) (local.get $cnt)))
)
